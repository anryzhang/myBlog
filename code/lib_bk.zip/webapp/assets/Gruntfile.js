/**
 * Created by ruizhang on 2014/9/24.
 */

module.exports = function(grunt){
    'use strict';
    //项目配置
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        srcPath:"ide",        
        distPath:"build",
        clean:{
            //清理build 文件夹下的所有文件(一般不用修改)
            main:{
                options:{
                    force:true
                },
                src:[
                    '<%= distPath%>'
                /*'<%= distPath%>/css*//*',
                    '<%= distPath%>/js*//*'*/
                ]
            },
            dist:{
                options:{
                    force:true
                },
                src:['<%= distPath%>/dist',
                    '<%= srcPath%>/js/bootstrap.js'
                ]
            },
            cleanWatch:{
                options:{
                    force:true
                },
                src:[
                    '<%= distPath%>/css/**',
                    '<%= distPath%>/js/function_module/**',
                    '<%= distPath%>/js/module/**',
                    '<%= distPath%>/js/*.js',
                ]
            }
        },
        copy: {
            //copy 相关的文件到build下(一般不用修改)
            fonts:{
                expand: true,
                cwd: '<%= srcPath%>/css/bootstrap/fonts/',
                src: ['**'],
                flatten: true,
                filter: 'isFile',
                dest: '<%= distPath%>/fonts/'
            },
            fontsLib:{
                expand: true,
                cwd: '<%= srcPath%>/fonts/',
                src: ['**'],
                flatten: true,
                filter: 'isFile',
                dest: '<%= distPath%>/fonts/'
            },
            img:{
                expand: true,
                cwd:'<%= srcPath%>/img/',
                src:['**'],
                dest:'<%= distPath%>/img/'
            },
            css:{
                expand:true,
                cwd: '<%= srcPath%>/css/',
                src:['*.css'],
                dest:'<%=distPath%>/dist/'
            },
            js:{
                expand:true,
                cwd:'<%= srcPath%>/js',
                src:[
                    'jquery.min.js',
                    'require.js',
                    'mainConfig.js',
                    'signin.js',
                    'function_module/**',
                    'module/**',
                    'lib/ide/**',
                    'lib/ace/**'
                ],
                dest:'<%= distPath%>/js'
            }
        },
        less:{
            //less 转 css (可以修改)
            build:{
                files:[
                    //bootstrap基础样式
                    {
                        src:['<%= srcPath%>/css/bootstrap/less/bootstrap.less'],
                        dest:'<%= distPath%>/dist/bootstrap/bootstrap.css'
                    },
                    //bootstrap theme
                    {
                        src:['<%= srcPath%>/css/bootstrap/less/theme.less'],
                        dest:'<%= distPath %>/dist/bootstrap/bootstrap-theme.css'
                    },
                    {
                        src:['<%= srcPath%>/css/editor.theme.less'],
                        dest:'<%= distPath%>/dist/editor.theme.css'
                    },
                    {
                        src:['<%= srcPath%>/css/layout.less'],
                        dest:'<%= distPath%>/dist/layout.css'
                    },
                    {
                        src:['<%= srcPath%>/css/component.less'],
                        dest:'<%= distPath%>/dist/component.css'
                    },
                    /*皮肤*/
                    {
                        src:['<%= srcPath%>/css/themes/skin/default/theme.less'],
                        dest:'<%= distPath%>/css/themes/default/theme.css'
                    },
                    {
                        src:['<%= srcPath%>/css/themes/skin/white/theme.less'],
                        dest:'<%= distPath%>/css/themes/white/theme.css'
                    }
                    // eg: 只需要复制上面的一个{}对像,修改一下相应的文件路径即可
                ]
            }
        },
        cssmin:{
            //压缩build下css文件(不用修改)
            build:{
                expand:true,
                cwd: '<%= distPath %>',
                src:['css/**/*.css',
                    '!*.min.css'],
                dest: '<%= distPath %>',
                ext: '.min.css'
            }
        },
        concat:{
            //合并文件
            js:{
                options:{
                    //插入合并输出文件之间的字符
                    separator:";\n"
                },
                files:[
                    //bootstrap组件
                    {
                        src: [
                            '<%= srcPath%>/js/lib/bootstrap/js/transition.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/alert.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/button.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/carousel.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/collapse.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/dropdown.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/modal.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/tooltip.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/popover.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/scrollspy.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/tab.js',
                            '<%= srcPath%>/js/lib/bootstrap/js/affix.js'
                        ],
                        dest: '<%= srcPath%>/js/bootstrap.js'
                    }
                    // eg: 只需要复制上面的一个{}对像,修改一下相应的文件路径即可

                ]
            },
            css:{
                files:[
                    //特殊处理,合并 signin.css
                    {
                        src:['<%= distPath%>/dist/signin.css'],
                        dest:'<%= distPath%>/css/signin.css'
                    },
                    //合并bootstrap.css
                    {
                        src:['<%= distPath%>/dist/bootstrap/bootstrap.css'/*,
                            '<%= distPath%>/dist/bootstrap/bootstrap-theme.css'*/
                        ],
                        dest:'<%= distPath%>/css/bootstrap.css'
                    },
                    //合并lib.css
                    {
                        src:['<%= srcPath%>/css/lib/cg.css',
                            '<%= srcPath%>/css/lib/validationEngine.jquery.css',
                            '<%= srcPath%>/css/lib/font-awesome.css',
                            '<%= srcPath%>/css/lib/zTreeStyle.css',
                            '<%= srcPath%>/css/lib/bootstrap-datetimepicker.css',
                            '<%= srcPath%>/css/lib/miniUploadForm.css',
                        ],
                        dest:'<%= distPath%>/css/lib/lib.css'
                    },
                    //合并ide.css
                    {
                        src:['<%= distPath%>/dist/common.css',
                            '<%= distPath%>/dist/component.css',
                            '<%= distPath%>/dist/layout.css',
                            '<%= distPath%>/dist/editor.theme.css',

                        ],
                        dest:'<%= distPath%>/css/ide.css'

                    }
                    // eg: 只需要复制上面的一个{}对像,修改一下相应的文件路径即可
                ]
            }

        },
        uglify:{
            //压缩所有js (一般不需要修改)
            build:{
                files:[
                    //压缩所有js
                    //{
                        //expand:true,
                        //cwd: '<%= distPath %>',
                        //src:['**/**/*.js','!*.min.js'],
                        //dest:'<%= distPath %>',
                        //ext:'.min.js'
                    //}
                    //压缩bootstrap.js
                    {
                        expand:true,
                        cwd:'<%= distPath%>',
                        src:['js/bootstrap.js'],
                        dest:'<%= distPath%>',
                        ext:'.min.js'
                    }
                    // eg: 只需要复制上面的一个{}对像,修改一下相应的文件路径即可
                ]
            }
        },
        requirejs:{
            compile_lib:{
                options:{
                    baseUrl: 'ide/js',
                    mainConfigFile:'ide/js/mainConfig.js',
                    removeCombined:true,
                    //optimize:"uglify",
                    optimize:"none",//不压缩
                    preserveLicenseComments:false,
                    include:[
                        'ace/ace','comet4j','template','uiwidget','knob','upload','treetable','cg','underscore','bootstrap','datetimepicker','jqueryValidationEngineEn','jqueryValidationEngine','ztreeCore','ztreeExedit','cronGentleSelect','cron'
                    ],
                    out:'build/js/lib.js'
                }
            }
        },
        watch:{
            //监听ide下js css 修改
            all:{
                files:['<%= srcPath %>/**/**/*.less',
                    '<%= srcPath %>/**/**/*.js',
                    '!<%= srcPath %>/js/bootstrap.js',
                ],
                tasks:['build:cssWatch']
            }
        }

    });


    //加载插件
    require("load-grunt-tasks")(grunt);

    //任务执行(不需要修改,直接执行即可)
    grunt.registerTask('build:copy',['copy']);
    grunt.registerTask('build:css',['build:copy','less','concat:css','cssmin',/*,'uglify'*/]);
    grunt.registerTask('build:js',['concat:js','requirejs'/*,'uglify'*/]);

    grunt.registerTask('build:cssWatch',['clean:cleanWatch','copy:css','copy:js','less','concat','cssmin','requirejs'/*,'uglify'*/,'clean:dist']);

    //为方便我们这次ui css开发,第一次运行请先运行一次grunt ,后面可以使用dev模式开发

    grunt.registerTask('dist',['build:css','build:js'])
    grunt.registerTask('default',['clean:main','dist','clean:dist']);// eg: grunt 手动执行grunt
    grunt.registerTask('dev',['watch']); // eg: grunt dev  前端开发模式,会自动执行grunt
}