!(function($,config){
	$(document).ready(function(){
	    window.HashChangeHandler = function(){
	        var hash = window.location.hash;
	        $("#login").hide();
            $("#forgotPassword").hide();
            $("#resetPassword").hide();
            $("#register").hide();
            $("#license").hide();
	        if(hash=="#login" || hash==""){
	            $("#login").show();
	            $("#username").focus();
	        }else if(hash=="#register"){
	            $("#register").show();
	            $("#register-username").focus();
	        }else if(hash=="#forgotPassword"){
	            $("#forgotPassword").show();
	            $("#forgot-email").focus();
	        }else if(hash.indexOf("#resetPassword")==0){
	            $("#resetPassword").show();
	            $("#reset-password").focus();
	        }
	        else if(hash=="#license"){
	        	$("#license").show();
	        	$("#txt-license").focus();
	        }
	        else{
	        	//404 or (default login) ?
	            $("#login").show();
	            $("#username").focus();
	        }
	    };
	    
	    /*function BrowserAlert() {
	        if ($.browser.msie){
	        	if(parseInt($.browser.version)<8){
	        		alert("Your current browser is IE " + $.browser.version + 
	        				", this site is best viewed with browsers of version IE 8.0 or above,"+
	        				" if you continue to browse, some page will showed abnormally.");
	        	}
	        }
	    }*/
	    HashChangeHandler();
	  	//BrowserAlert();
	    /*window.onpopstate=function(){
	    	console.log("aa");
	        HashChangeHandler();
	    }*/
	    function validateSimpleName(value){
	    	if(value==""){
	    		return "Username can not be empty.";
	    	}
	    	else{
	    		return true;
	    	}
	    }
		function validateSimplePassword(value){
			if(value==""){
	    		return "Password can not be empty.";
	    	}
			else{
	    		return true;
	    	}
	    }
		function validateLicense(value){
			if(value==""){
	    		return "License can not be empty.";
	    	}
			else{
	    		return true;
	    	}
		}
	    function validateName(name){
			var reg = /^[a-zA-Z0-9_][a-zA-Z0-9_]{5,19}$/;
			if(name==""){
				return "Username is required.";
			}
			if(name.indexOf(" ")>-1){
				return "Username should not contain blank.";
			}
			if((name.length>0 && name.length<6) || name.length>20){
				return "The length of username must between 6 and 20.";
			}
			if(name.length>5 && name.length<21 && !reg.test(name)) {
				return "Username should contains only letters, digits and underscore.";
	 		}
			else{
				return true;
			}
	    }
	    function validatePassword(password){
	    	if(password==""){
	    		return "Password is required.";
	    	}
			if(password.indexOf(" ")>-1){
				return "Password should not contain blank.";
			}
			if((password.length>0 && password.length<6) || password.length>20){
				return "The length of password must between 6 and 20.";
			}
			else{
				return true;
			}
	    }
	    function confirmPassword(password,rePassword){
	    	if(password==rePassword){
	    		return true;
	    	}else{
	    		return "Passwords do not match.";
	    	}
	    }
	    function validateEmail(email){
	    	var reg = /^\s*\w+(?:\.{0,1}[\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\.[a-zA-Z]+\s*$/;
	    	if(email==""){
	    		return "Email address is required.";
	    	}
			if(!reg.test(email)){
				return "Email address is invalid.";
			}else{
				return true;
			}
		}
	    $("#form-login .field input").on("keypress",function(e){
	    	if(e.which == 13){
	    		$('#form-login #btn-login').trigger("click");
	    	}
	    });
	    $('#form-login #btn-login').click(function() {
	    	var userName = $("#form-login input#username").val();
	    	var password = $("#form-login input#password").val();
	    	var $errorArea = $("#form-login .notes-error");
	    	if(validateSimpleName(userName)!=true || validateSimplePassword(password)!=true){
	    		$errorArea.show();
	    		$errorArea.find("p").remove();
	    		var html = "";
	    		if(validateSimpleName(userName)!=true){
	    			html+="<p>"+validateSimpleName(userName)+"</p>";
	    		}
	    		if(validateSimplePassword(password)!=true){
	    			html+="<p>"+validateSimplePassword(password)+"</p>";
	    		}
	    		$errorArea.append(html);
	    	}else{
	        	var postData={};
	        	postData.userName=$("#form-login input#username").val();
	        	postData.password=$("#form-login input#password").val();
	        	postData.rememberMe=$('#form-login input[type="checkbox"]').is(':checked');
	        	$.ajax({
					url:config.loginUrl,
					type:'POST',
					dataType : 'json',
					async : true,
					contentType : 'application/json;charset=UTF-8',
					data:JSON.stringify(postData),
					beforeSend:function(){
						$errorArea.find("p").remove();
						/*$errorArea.hide();*/
					},
					error:function(){},	
					success:function(data){
						if(data && data!=null){
							if(data.status!="200"){
								if(data.status=="1001"){
									window.location.href="#license";
									HashChangeHandler();
								}else{
									$errorArea.show();
									$errorArea.append("<p>"+data.message+"</p>");
								}
							}
							else{
								$errorArea.hide();
								window.location.href= config.homaPageUrl;
							}
						}
					},
					complete:function(){} 
				});
	    	}
		});
	    $("#form-register .field input").on("keypress",function(e){
	    	if(e.which == 13){
	    		$('#form-register #btn-register-signUp').trigger("click");
	    	}
	    });

	    self.registerDelayLogin = null;
	    $('#form-register #btn-register-signUp').click(function() {
	    	var name = $('#form-register #register-username').val();
	    	var psw = $('#form-register #register-password').val();
	    	var rePsw = $('#form-register #register-confirm-password').val();
	    	var email = $('#form-register #register-email').val();
	    	var $errorArea = $("#form-register .notes-error");
	    	var $successArea = $("#form-register .notes-success");
	    	if(validateName(name)!=true || validatePassword(psw)!=true || confirmPassword(psw,rePsw)!=true || validateEmail(email)!=true){
	    		$errorArea.show();
	    		$errorArea.find("p").remove();
	    		var html = "";
	    		if(validateName(name)!=true){
	    			html+="<p>"+validateName(name)+"</p>";
	    		}
	    		if(validatePassword(psw)!=true){
	    			html+="<p>"+validatePassword(psw)+"</p>";
	    		}
	    		if(confirmPassword(psw,rePsw)!=true){
	    			html+="<p>"+confirmPassword(psw,rePsw)+"</p>";
	    		}
	    		if(validateEmail(email)!=true){
	    			html+="<p>"+validateEmail(email)+"</p>";
	    		}
	    		$errorArea.append(html);
	    	}else{
	    		var postData={};
	        	postData.userName=name;
	        	postData.password=psw;
	        	postData.confirmPassword=rePsw;
	        	postData.mailAddress=email;
	    		$.ajax({
					url:config.registerUrl,
					type:'POST',
					dataType : 'json',
					async : true,
					contentType : 'application/json;charset=UTF-8',
					data:JSON.stringify(postData),
					beforeSend:function(){
						$errorArea.find("p").remove();
						/*$successArea.hide();*/
						/*$errorArea.hide();*/
					},
					error:function(){},	
					success:function(data){
						if(data && data!=null){
							if(data.status!="200"){
								$successArea.hide();
								$errorArea.show();
								$errorArea.append("<p>"+data.message+"</p>");
							}
							else{
								$errorArea.hide();
								$successArea.show();
								if(self.registerDelayLogin){
									window.clearTimeout(self.registerDelayLogin);
								}
								self.registerDelayLogin = window.setTimeout(function(){
									window.location.hash = "#login";
    								HashChangeHandler();
    								$('#form-register #register-username').val("");
							    	$('#form-register #register-password').val("");
							    	$('#form-register #register-confirm-password').val("");
							    	$('#form-register #register-email').val("");
						    		$successArea.hide();
								},3000);
							}
						}
					},
					complete:function(){} 
				});
	    	}
		});
	    $("#form-forgotPassword .field input").on("keypress",function(e){
	    	if(e.which == 13){
	    		$('#form-forgotPassword #btn-forgotPassword-submit').trigger("click");
	    		e.preventDefault();
	    	}
	    });
	    $('#form-forgotPassword #btn-forgotPassword-submit').click(function() {
	    	var email = $('#form-forgotPassword #forgot-email').val();
	    	var $errorArea = $("#form-forgotPassword .notes-error");
	    	var $sucessArea = $("#form-forgotPassword .notes-success");
	    	var $btnSubmit = $("#form-forgotPassword #btn-forgotPassword-submit");
	    	if ($btnSubmit.hasClass("disabled")){
	    		return;
	    	}
	    	$btnSubmit.text("Submit");
	    	var validateResult = validateEmail(email);
	    	if (validateResult==true){
	    		var postData={};
	        	postData.email=email;
	    		$.ajax({
					url:config.forgotPasswordUrl,
					type:'POST',
					dataType : 'json',
					async : true,
					/*contentType : 'application/json;charset=UTF-8',*/
					data:{
						"email":email
					},//JSON.stringify(postData),
					beforeSend:function(){
						$errorArea.find("p").remove();
						$sucessArea.hide();
						/*$errorArea.hide();*/
					},
					error:function(){},	
					success:function(data){
						if(data && data!=null){
							if(data.status!="200"){
								$sucessArea.hide();
								$errorArea.show();
								$errorArea.append("<p>"+data.message+"</p>");
							}
							else{
								$errorArea.hide();
								$btnSubmit.addClass("disabled");
								window.setTimeout(function () {
									$sucessArea.show();
									$btnSubmit.removeClass("disabled");
									$btnSubmit.text("Not receive? Sent again");
						        }, 2000);
							}
						}
					},
					complete:function(){} 
				});
	    	}else{
	    		$sucessArea.hide();
	    		$errorArea.show();
	    		$errorArea.find("p").remove();
	    		$errorArea.append("<p>"+validateResult+"</p>");
	    	}
		});
	    $("#form-resetPassword .field input").on("keypress",function(e){
	    	if(e.which == 13){
	    		$('#form-resetPassword #btn-resetPassword-submit').trigger("click");
	    	}
	    });
	    $('#form-resetPassword #btn-resetPassword-submit').click(function() {
	    	var password = $('#form-resetPassword #reset-password').val();
	    	var rePassword = $('#form-resetPassword #reset-confirm-password').val();
	    	var $errorArea = $("#form-resetPassword .notes-error");
	    	var $sucessArea = $("#form-resetPassword .notes-success");
	    	var validateResult1 = validatePassword(password);
	    	var validateResult2 = confirmPassword(password,rePassword);
	    	if(validateResult1!=true || validateResult2!=true){
	    		$errorArea.show();
	    		$errorArea.find("p").remove();
	    		var html = "";
	    		if(validateResult1!=true){
	    			html+="<p>"+validateResult1+"</p>";
	    		}
				if(validateResult2!=true){
					html+="<p>"+validateResult2+"</p>";
	    		}
				$errorArea.append(html);
	    	}else{
	    		$.ajax({
					url:config.resetPasswordUrl,
					type:'POST',
					dataType : 'json',
					async : true,
					/*contentType : 'application/json;charset=UTF-8',*/
					data:{
						"password":password,
						"id":window.location.hash.substring(window.location.hash.indexOf("?uid=")+5)
					},//JSON.stringify(postData),
					beforeSend:function(){
						$errorArea.find("p").remove();
						/*$sucessArea.hide();*/
						/*$errorArea.hide();*/
					},
					error:function(){},	
					success:function(data){
						if(data && data!=null){
							if(data.status!="200"){
								$sucessArea.hide();
								$errorArea.show();
								$errorArea.append("<p>"+data.message+"</p>");
							}
							else{
								$errorArea.hide();
								$sucessArea.show();
							}
						}
					},
					complete:function(){} 
				});
	    	}
		});
	    $("#license .field input").on("keypress",function(e){
	    	if(e.which == 13){
	    		$('#license #btn-license-submit').trigger("click");
	    	}
	    });
	    self.licenseDelayLogin = null;
	    $('#license #btn-license-submit').click(function() {
	    	var license = $('#license #txt-license').val();
	    	var $errorArea = $("#license .notes-error");
	    	var $sucessArea = $("#license .notes-success");
	    	var validateResult = validateLicense(license);
	    	if(validateResult!=true){
	    		$errorArea.show();
	    		$errorArea.find("p").remove();
	    		var html = "";
    			html+="<p>"+validateResult+"</p>";
				$errorArea.append(html);
	    	}else{
	    		postData={};
	    		postData.cdKey= license;
	    		$.ajax({
					url:config.activateUrl,
					type:'POST',
					dataType : 'json',
					async : true,
					contentType : 'application/json;charset=UTF-8',
					data:JSON.stringify(postData),
					beforeSend:function(){
						$errorArea.find("p").remove();
						$sucessArea.find("p").remove();
						/*$sucessArea.hide();*/
						/*$errorArea.hide();*/
					},
					error:function(){},	
					success:function(data){
						if(data && data!=null){
							if(!data.result){
								$sucessArea.hide();
								$errorArea.show();
								$errorArea.append("<p>"+data.msg+"</p>");
							}
							else{
								$errorArea.hide();
								$sucessArea.show();
								$sucessArea.append("<p>"+data.msg+"</p>");
								if(self.licenseDelayLogin){
									window.clearTimeout(self.licenseDelayLogin);
								}
								self.licenseDelayLogin = window.setTimeout(function(){
									window.location.hash = "#login";
    								HashChangeHandler();
    								$('#license #txt-license').val("");
									$sucessArea.hide();
								},3000);
							}
						}
					},
					complete:function(){} 
				});
	    	}
		});
	    $('.ie7 #link-forgotPassword').on('click',function(){
    		window.location.hash = "#forgotPassword";
    		HashChangeHandler();
	    });
	    $('.ie7 #link-register').on('click',function(){
    		window.location.hash = "#register";
    		HashChangeHandler();
	    });
	    $('.ie7 .link-login').on('click',function(){
    		window.location.hash = "#login";
    		HashChangeHandler();
	    });
	});
	
})(jQuery,config);
