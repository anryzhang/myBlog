/**
 * Created by ruizhang on 2014/10/27.
 */
define(['jquery','ide','moduleCommon','main'],function($,ide,common,main){
    var module = {
        init:function(){
            repositoryService.runAnalysis.submit = function(){
                var formBean = {};
                var selectedItems = repositoryService.getSourceCode().getSelectedItem();
                if(selectedItems.length <= 0){
                    ide.util.alert(ide.i18n.analysis.itemed,null,3);
                    return ;
                }
                formBean.projectId = selectedItems[0].projectId;
                formBean.checkId = '';
                $('#checkboxList input[type="checkbox"]:checked').each(function(){
                   formBean.checkId += $(this).attr('id') + ',';
                });
                var progress = ide.util.progress('Analyzing',{
                    type:1,
                    complete:function(){
                        setTimeout(function(){
                            repositoryService.updateProjectStatus(selectedItems[0].projectId);
                        },4000);
                    }
                });

                var analysisUrl = common.config.rootUrl + 'analysis/start?progressId=' + progress.getId();
                repositoryService.runAnalysis.dialog.disableButton(0);
                var progressId = progress.getId();
                $.ajax({
                    type:'post',
                    url: analysisUrl,
                    dataType:'json',
                    contentType: 'application/json',
                    data: JSON.stringify(formBean),
                    success:function(data){
                        if(data && data.status == 200){
                            main.showProgress();
                            repositoryService.runAnalysis.dialog.close();
                        }else if(data && data.status == 1002){
                            //current task is working
                            var progress = ide.util.getProgress(progressId);
                            progress && progress.remove();
                            repositoryService.runAnalysis.dialog.close();
                            ide.util.alert(ide.i18n.analysis.analyzed,null,3);
                        }
                    },
                    error:function(){
                        repositoryService.runAnalysis.dialog.enableButton(0);
                        ide.util.alert('request error',null,3);
                        repositoryService.runAnalysis.dialog.close();
                    }

                });

            }
        }
    };
    return module;
});