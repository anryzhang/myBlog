/**
 * Created by ruizhang on 2014/9/26.
 */
define(['jquery', 'moduleCommon', 'ide'], function ($, common, ide) {
    var module = {
        init: function () {
            var container = $('.main-container');

            //获取选中的节点数据
            var node = repositoryService.getSelectedItems();

            var share_project_save = common.config.rootUrl + 'ide/project/projectShare';
            var share_project_search = common.config.rootUrl + 'ide/getWorkspaceShareUsersByProjectId';
            //'assets/data/repository/share_project_search.json';

            function _shareProject() {
                ide.util.ajax({
                    type: 'get',
                    dataType: 'json',
                    url: share_project_search + '/' + node[0].projectId,
                    success: function (rs) {
                        if (rs.status == 200) {
                            var data = rs.data.json;

                            //渲染 project type
                            var proData = data.usersRight.shareGroup;

                            var shareHtml = '';
                            var listHead = '<li class="J_usersGroup">';
                            var usersGroupName = '<div class="users-group-box>test</div>'
                            var usersItemsStart = '<div class="users-item-box">'
                            var proOption = '';
                            var usersItemsEnd = '</div>';
                            var listEnd = '</li>';

                            for (var i = 0; i < proData.length; i++) {
                                usersGroupName = '';
                                usersGroupName += '<div class="users-group-box"><span class="pull-left">' + proData[i].groupName + '</span>' +
                                    '<span class="J_clearItems pull-right btn btn-default btn-success btn-xs">clear selected</span>' +
                                    '<span class="J_allItems pull-right btn btn-default btn-success btn-xs">all selected</span>' +
                                    '</div>';
                                proOption = '';
                                for (var j = 0; j < proData[i].usersInfo.length; j++) {
                                    var checked = 'checked',
                                        clazz = "admin";
                                    if (proData[i].usersInfo[j].checked != true) {
                                        checked = '';
                                    }
                                    if (proData[i].usersInfo[j].role != 1) {
                                        clazz = "";
                                    }
                                    proOption += '<div class="checkbox-item"><input type="checkbox" ' + checked + ' id="PT_' + proData[i].groupName + j + '" value="' + proData[i].usersInfo[j].key + '"/><label class="' + clazz + ' checkbox-inline" for="PT_' + proData[i].groupName + j + '" title="' + proData[i].usersInfo[j].value + '">' + proData[i].usersInfo[j].value + '</label></div>';

                                }
                                shareHtml += listHead + usersGroupName + usersItemsStart + proOption + usersItemsEnd + listEnd;
                            }


                            $('#J_projectType').append(shareHtml);

                        }
                    }
                });

            }

            repositoryService.shareProject.initShareProject = function () {
                _shareProject();
            };

            repositoryService.shareProject.submit = function () {
                //提交commit数据
                var data = repositoryService.shareProject.getSubmitData();
                if (!data) {
                    return false;
                }
                repositoryService.shareProject.dialog.disableButton(0);
                ide.util.ajax({
                    type: 'post',
                    url: share_project_save,
                    data: JSON.stringify(data),
                    success: function (rs) {
                        if (rs.status == 200) {
                            repositoryService.shareProject.dialog.close();
                            var sourceCode = repositoryService.getSourceCode();
                            var nodes = sourceCode.getSelectedItem();
                            var projectName = rs.data.json.usersRight;
                            //前端通过是否分享项目给用户来判断项目节点是否显示share标识
                            var aObj = $('#' + nodes[0].tId + '_a');
                            var shareTarget = ide.config.icon.share;
                            if (data.usersRight.length) {
                                if (!aObj.has('.J_shareIcon').length) {
                                    aObj.append(shareTarget);
                                }

                            } else {
                                aObj.find('.J_shareIcon').remove();
                            }
                            sourceCode.updateItem(nodes[0]);
                            //main.init();

                        } else {
                            repositoryService.shareProject.dialog.enableButton(0);
                            ide.util.alert(rs.message, null, 2);
                        }
                    },
                    error: function (rs) {
                        if (rs.status) {
                            repositoryService.shareProject.dialog.enableButton(0);
                            ide.util.alert(rs.message, null, 2);
                        }
                    }
                });


                return false;
            }

            repositoryService.shareProject.getSubmitData = function () {
                //返回提交需要的参数
                var postData = {};

                var user_checkedId = [];
                var selectedInput = container.find('#J_projectType input:checked');
                for (var i = 0; i < selectedInput.length; i++) {
                    user_checkedId.push(selectedInput.eq(i).val());
                }

                postData = {
                    projectId: node[0].projectId,
                    usersRight: user_checkedId
                }
                return postData;
            }
            //全选 反选
            container.on('click', '.J_clearItems', function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).closest('.J_usersGroup').find('input').attr('checked', false).trigger('change');


            });
            container.on('click', '.J_allItems', function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).closest('.J_usersGroup').find('input').attr('checked', true).trigger('change');
            });

            container.on("change", '#J_projectType input', function (e) {
                var idVal = $(this).val();
                container.find('#J_projectType input[value="' + idVal + '"]').attr('checked', $(this).is(':checked'));
            });
        }
    };
    return module;
})