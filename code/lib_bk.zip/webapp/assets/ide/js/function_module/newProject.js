/**
 * Created by ruizhang on 2014/9/26.
 */
define(['jquery', 'ide', 'moduleCommon', 'cron'], function ($, ide, common, cron) {
    var module = {
        init: function () {
            var container = $('.main-container'),
                projectName = container.find('#new_project_p_name'),
                J_MfTab = container.find('.J_MfTab'),
                J_mappingBox = container.find('.J_mappingBox'),
                J_mapping = J_mappingBox.find('.J_mapping'),
                J_delBranch = J_mappingBox.find('.J_delBranch'),

                J_serverTime = container.find('.J_serverTime');
            var clearLocalTime;

            var href = common.config.rootUrl + 'ide/create_project';
            var mappingFileType = common.config.rootUrl + 'ide/project/getProjectFormData';//'assets/data/repository/newProject/file_type.json';
            var FtpUrl = common.config.rootUrl + 'ide/testFtpConnection';

            function _newProject() {
                projectName.focus();
                repositoryService.tabSelect(container.find('.J_MfTab'));
                //绑定数据到mf radio

                ide.util.ajax({
                    type: 'post',
                    dataType: 'json',
                    url: mappingFileType,
                    data: JSON.stringify({}),
                    success: function (rs) {
                        if (rs.status == 200) {
                            var data = rs.data.json.fileType;
                            container.find('.J_type input[id="Mf"]').data('mfdata', data);

                            var localTime = new Date();
                            var serverTime = rs.data.json.serverTimeLong || localTime.getTime();
                            countDown(serverTime);

                            //渲染一条mapping数据
                            if (J_mapping.find('.tab-body li').length < 1) {
                                var html = rendMapping(data);
                                J_mapping.find('.tab-body').append(html);
                            }

                            //渲染project type
//                        var proData = rs.data.json.projectType;
//                        var proOption = '';
//                        for(var i = 0; i < proData.length; i++){
//                            proOption += '<div class="checkbox-item"><input type="checkbox" id="projectType'+ i +'" value="'+ proData[i].key + '"/><label class="checkbox-inline" for="projectType'+ i +'">'+ proData[i].value +'</label></div>';
//                        }
//                        $('#J_projectType').append(proOption);
                        }
                    }
                });

                container.find('#J_schedual').cron({
                    initial: "0 0 1 * *",
                    onChange: function () {
                        $('#J_schedual-val').val($(this).cron("value"));
                        //alert($(this).cron("value"));
                    },
                    useGentleSelect: true
                });

            }

            repositoryService.newProject.initProject = function () {
                _newProject();
            };

            function countDown(time) {
                // 创建两个变量，一个数组中的月和日的名称
                var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug ", "Sep ", "Oct ", "Nov", "Dec" ];
                var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri ", "Sat"]


                var _time = parseInt(time);
                // 创建一个对象newDate（）
                var newDate = new Date(_time);
                //输出的日子，日期，月和年
                setInterval(function () {
                    _time += 1000;
                    newDate = new Date(_time);

                    clearLocalTime = J_serverTime.find('#Date').html(dayNames[newDate.getDay()] + ',  ' + monthNames[newDate.getMonth()] + ' ' + newDate.getDate() + ',  ' + newDate.getFullYear() + '<span style="display: inline; padding-left: 15px;"></span>' + ((newDate.getHours() < 10 ? "0" : "") + newDate.getHours()) + ':' + ((newDate.getMinutes() < 10 ? "0" : "") + newDate.getMinutes()) + ':' + (newDate.getSeconds() < 10 ? "0" : "") + newDate.getSeconds());
                }, 1000);

            }

            repositoryService.newProject.submit = function () {
                //提交commit数据
                var data = repositoryService.newProject.getSubmitData();
                if (!data) {
                    return false;
                }
//            if(data.projectType.length < 1){
//                ide.util.tips('Select at least one project type!',1500,3);
//                return false;
//            }

                //ftp时 提示用户自动更新时间
                if (data.serverType == 'FTP' && data.scheduleJob.cronExpression == '0 0 0 1 * ?') {
                    ide.util.confirm('Default run time is the 1st day of every month, press OK to continue', function (ev) {
                        submitProject();
                        clearInterval(clearLocalTime);
                        ev.data.dialog.close();
                    });
                } else {
                    submitProject();
                }

                function submitProject() {
                    repositoryService.newProject.dialog.disableButton(0);
                    ide.util.ajax({
                        type: 'POST',
                        url: href,
                        data: JSON.stringify(data),
                        success: function (rs) {
                            if (rs.status == 200) {
                                //radio  upload
                                if (container.find('.J_upload').closest('.J_tables').hasClass('active')) {
                                    repositoryService.addProject(rs.data.json);
                                    repositoryService.newProject.dialog.close();
                                    repositoryService.uploadSourceCode(rs.data.json.nodes[0].id);

                                } else {
                                    repositoryService.addProject(rs.data.json);
                                    repositoryService.newProject.dialog.close();
                                    //更新a,b操作
                                    var sourceCode = repositoryService.getSourceCode();
                                    var nodes = sourceCode.getItemById(rs.data.json.nodes[0].projectId,null);
                                    sourceCode.updateItem(nodes[0]);
                                    ide.util.tips(rs.message, 1500);
                                }

                            } else {
                                repositoryService.newProject.dialog.enableButton(0);
                                ide.util.alert(rs.message, null, 2);
                            }
                        },
                        error: function (rs) {
                            if (rs.status) {
                                ide.util.alert(rs.message, null, 2);
                                repositoryService.newProject.dialog.enableButton(0);
                            }
                        }
                    });

                }

                return false;
            }

            repositoryService.newProject.getSubmitData = function () {
                //返回提交需要的参数
                var postData = {};
                var scheduleJob = {};
                var branchData = _getBranchData();

//            var project_types = [];
//            var selectedInput = container.find('#J_projectType input:checked');
//            for(var i = 0; i < selectedInput.length; i++ ){
//                project_types.push(selectedInput.eq(i).val());
//            }

                if (J_MfTab.closest('.J_tables').hasClass('active')) {
                    scheduleJob = {
                        cronExpression: container.find('#J_schedual-val').val(),
                        isRunNow: (container.find('#J_isBegin').attr('checked') == 'checked') ? true : false
                    };

                    postData = {
                        serverType: container.find('.J_type input:checked').attr('data-key'),
                        projectName: $.trim(container.find('#new_project_p_name').val()),
                        //projectType: project_types,
                        projectDesc: $.trim(container.find('#projectDesc').val()),
                        remoteAddress: $.trim(container.find('#urlAddress').val()),
                        remotePort: $.trim(container.find('#port').val()),
                        remoteUsername: $.trim(container.find('#Username').val()),
                        remotePassword: container.find('#Password').val(),
                        branchData: branchData,
                        scheduleJob: scheduleJob,
                        clientTime: $.now()
                    }

                    if (!postData.projectName) {
                        ide.util.tips(ide.i18n.projectTipInfo.noEmpty, 1500, 3);
                        container.find('#new_project_p_name').focus();
                        return false;
                    }
//                if(postData.projectType.length < 1){
//                    ide.util.tips('Select at least one project type!',1500,3);
//                    return false;
//                }
                    if (!postData.remoteAddress) {
                        ide.util.tips(ide.i18n.projectTipInfo.ip, 1500, 3);
                        container.find('#urlAddress').focus();
                        return false;
                    }
                    if (!postData.remotePort) {
                        ide.util.tips(ide.i18n.projectTipInfo.port, 1500, 3);
                        container.find('#port').focus();
                        return false;
                    }
                    if (!postData.remoteUsername) {
                        ide.util.tips(ide.i18n.projectTipInfo.ftpusername, 1500, 3);
                        container.find('#Username').focus();
                        return false;
                    }
                    if (!postData.remotePassword) {
                        ide.util.tips(ide.i18n.projectTipInfo.ftpPassword, 1500, 3);
                        container.find('#Password').focus();
                        return false;
                    }
                    if (postData.branchData[0].dataMapping.length < 1) {
                        ide.util.tips(ide.i18n.projectTipInfo.mapping, 1500, 3);
                        J_MfTab.find('#J_mp').closest('li').addClass('active').siblings().removeClass('active');
                        J_mapping.closest('.tab-pane').addClass('active').siblings().removeClass('active');
                        return false;
                    }

                    //验证ftp下载
                    for (var i = 0; i < postData.branchData.length; i++) {
                        if (postData.branchData[i].dataMapping.length) {
                            if (common.role != 1) {
                                //common.role != 1时,是一般用户,为1时是admin 用户
                                for (var k = 0, l = postData.branchData[i].dataMapping.length; k < l; k++) {

                                    if (postData.branchData[i].dataMapping[k].address.toUpperCase().indexOf(postData.remoteUsername.toUpperCase() + ".") == 0 && postData.branchData[i].dataMapping[k].address.length > (postData.remoteUsername + "." ).length) {

                                    } else {

                                        ide.util.alert("PDS name: " + postData.branchData[i].dataMapping[k].address + " is error.<br> Only FTP username's dataset can be downloaded.", null, 3);
                                        J_MfTab.find('#J_mp').closest('li').addClass('active').siblings().removeClass('active');
                                        J_mappingBox.closest('.tab-pane').addClass('active').siblings().removeClass('active');

                                        J_mapping.closest('.tab-pane').find("input").eq(k).focus();
                                        return false;
                                    }
                                }
                            }

                        }
                    }

                } else {
                    postData = {
                        serverType: container.find('.J_type input:checked').attr('data-key'),
                        projectName: container.find('#new_project_p_name').val(),
                        //projectType: project_types,
                        projectDesc: container.find('#projectDesc').val()
                    }
                }

                if (!promtMessage(postData.projectName, "Project Name cannot be empty !")) {
                    container.find('#new_project_p_name').focus();
                    return false;
                }

                if (postData.projectName.length > 40) {
                    ide.util.alert('Max length for Project Name is 40 characters !', null, 3);
                    return false;
                }

                if (postData.projectName.length > 400) {
                    ide.util.alert('Max length for Description is 400 characters !', null, 3);
                    return false;
                }
                return postData;
            }

            //branch data
            function _getBranchData() {
                var branchData = [];
                var branchItem = {};
                var len = J_mappingBox.find('.J_mapping').length;
                for (var i = 0; i < len; i++) {
                    branchItem = {
                        "branchName": $.trim(J_mappingBox.find('.J_mapping').eq(i).find('.J_branchTitle').text()),
                        "isMaster": J_mappingBox.find('.J_mapping').eq(i).find('.J_delBranch:hidden').length ? true : false,
                        "dataMapping": (function () {
                            var arrMap = [];
                            for (var j = 0; j < J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').length; j++) {
                                var ft = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('select option:selected').val();
                                var as = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('.file-add input').val();
                                var fn = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('.fold-name input').val();
                                if (!as) {
                                    continue;
                                } else {
                                    var mapItem = {
                                        "fileType": ft,
                                        "address": $.trim(as),
                                        "folderName":$.trim(fn)
                                    }
                                    arrMap.push(mapItem);
                                }
                            }
                            return arrMap;
                        })()
                    }

                    branchData.push(branchItem);
                }

                return branchData;
            }

            //验证不为空的form
            function promtMessage(checkVal, msg) {
                if (checkVal == null || $.trim(checkVal) == '') {
                    ide.util.alert(msg, null, 3);
                    return false;
                }
                return true;
            }

            //仓库类型切换
            var typeBtn = container.find('.J_type input');
            $.each(typeBtn, function (idx, ele) {
                $(this).on('click', function () {
                    $('.J_tables').eq(idx).addClass('active').siblings('.J_tables').removeClass('active');
                })
            })

            //渲染mapping
            function rendMapping(data) {
                var _data = {
                    list:data
                }
                var html = template('J_tempBranchItem',_data);
                return html;
            }

            //添加mapping 项
            container.on('click', '.J_addBranch', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var html = '<div class="J_mapping mapping-item" data-branch="1">' + J_mapping.html() + '</div>';
                J_mappingBox.append(html);
                container.find('[data-branch="1"]').find('.J_branchTitle').text('New branch').attr('contenteditable', 'true');
                container.find('[data-branch="1"]').find('.J_delBranch').show();

            });
            //删除mapping 项
            J_mappingBox.on('click', '.J_delBranch', function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).closest('.J_mapping').remove();
            });

            J_mappingBox.on('click', '.J_addMapp', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var data = container.find('.J_type input[id="Mf"]').data('mfdata');
                var html = rendMapping(data);
                $(this).closest('.J_mapping').find('.tab-body li:first').before($(html));
            });
            //前端判断表单字段
            J_mappingBox.on('click', '.J_delMapp', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var len = $(this).closest('.J_mapping').find('.tab-body li').length;
                if (len < 2) {
                    ide.util.tips("Can't delete all, keep at least one!", 1500, 3);
                    return false
                } else {
                    $(this).closest('li').remove();
                }

            });

            //test fit 连接
            container.on('click', '.J_testFtp ', function (e) {
                e.preventDefault();
                var data = {
                    remoteAddress: $('#urlAddress').val(),
                    remotePort: $('#port').val(),
                    remoteUsername: container.find('#Username').val(),
                    remotePassword: container.find('#Password').val()
                };
                //前端判断表单字段
                if (!data.remoteAddress) {
                    ide.util.tips(ide.i18n.projectTipInfo.ip, 1500, 3);
                    container.find('#urlAddress').focus();
                    return false;
                }
                if (!data.remotePort) {
                    ide.util.tips(ide.i18n.projectTipInfo.port, 1500, 3);
                    container.find('#port').focus();
                    return false;
                }
                if (!data.remoteUsername) {
                    ide.util.tips(ide.i18n.projectTipInfo.ftpusername, 1500, 3);
                    container.find('#Username').focus();
                    return false;
                }
                if (!data.remotePassword) {
                    ide.util.tips(ide.i18n.projectTipInfo.ftpPassword, 1500, 3);
                    container.find('#Password').focus();
                    return false;
                }

                ide.util.ajax({
                    type: 'post',
                    dataType: 'json',
                    url: FtpUrl,
                    data: JSON.stringify(data),
                    success: function (rs) {
                        if (rs.status == 200) {
                            ide.util.tips(rs.message, 1500);
                        } else {
                            ide.util.alert(rs.message, null, 2);
                        }
                    }
                });

            });
            //是否立即执行标识
            container.on('click', '#J_isBegin', function (e) {
                if ($(this).attr('checked')) {
                    $(this).attr('checked', true);
                } else {
                    $(this).attr('checked', false);
                }
            });
        }
    };
    return module;
})