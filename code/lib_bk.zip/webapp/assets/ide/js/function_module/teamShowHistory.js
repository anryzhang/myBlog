/**
 * Created by ruizhang on 2014/9/25.
 */
define(['jquery','ide','moduleCommon'],function($,ide,common){
   var module = {
        init:function(){
            var sourceCode = repositoryService.getSourceCode();
            var container = $('.team-container'),
                datatable;

            //var href = common.config.rootUrl + 'assets/data/repository/team/team_showHistory.json';
            var href = common.config.rootUrl + 'git/getFileVersionHistory';

            function _showHistoryEvent(node){

                datatable = new ide.util.Datatable(container.find('#team-showHistory-table'),{
                    type:'POST',
                    url: href,
                    columns:[{
                        width:'35%',
                        title:'Comment',
                        data:'remark'
                    },{
                        width:"20%",
                        title:'Date',
                        data:'date'

                    },{
                        width:'15%',
                        title:'Author',
                        data:'username'
                    },{
                    	width:'10',
                    	title:'Action',
                    	render:function(full){
        					return '<div class="btn btn-xs resume" title="resume" data-id="' + full.fileId +'" data-version="' + full.version + '" ><span  class="J_progress-remove glyphicon glyphicon-play"></span></div>';
        				}
                    }],
                    data:{
                        //t: $.now(),
                        //node:JSON.stringify(node)
                        id:node[0].id,
                        projectId:node[0].projectId
                    },
                    currentPage:1,
                    pageSize:10000,
                    pageable:false,
                    headerable:true,
                    rowClick:function(e,data){
                        $(this).toggleClass('selected-tr').siblings().removeClass('selected-tr');

                    }
                });
            }

            container.on("click",".resume",function(){
            	var id=$(this).attr("data-id");
            	var version = $(this).attr("data-version"),
                    codeObj = main.getCodeById(id);
                var node = sourceCode.getSelectedItem();

                if(codeObj && codeObj.isModified()){
                    codeObj.saveModifiedFile();
                    return;
                }

            	ide.util.prompt(ide.i18n.repository.revertCommit,function(e){
                    var val = e.data.dialog.ui.content.find('input').val();
                    if(!val){
                        ide.util.tips(ide.i18n.repository.commit,1500,3);
                        return false;
                    }else{
                        var _data = {
                            id:id,
                            version:version,
                            remark:val
                        }
                        ide.util.ajax({
                            type:'post',
                            dataType:'json',
                            data:JSON.stringify(_data),
                            url:common.config.rootUrl+"git/gitRevetFileByVersion",
                            success:function(rs){
                                if(rs.status === 200){
                                    //没有写完,成功后刷新节点与tab
                                    var _tab = main.getCodeTabById(id);
                                    if(_tab){
                                        main.refreshCodeTab(_tab);
                                    }
                                    e.data.dialog.close();
                                    ide.util.tips(rs.message,1500);
                                }
                            }
                        });

                    }

        		});
        	});
            
            repositoryService.teamShowHistory.initShowHistory = function(nodes){
                _showHistoryEvent(nodes);
            };
        }
   };
   return module;
   
   
   
});