/**
 * Created by ruizhang on 2014/9/10.
 */
define(['jquery', 'treetable'], function ($, treetable) {
    var module = {
        init: function (opt, callback) {
            var node = repositoryService.getSelectedItems();
            repositoryService.editProjectTypeMapping.submit = function () {
                submit();
            }

            var projectId = opt.projectId;
            var fileId = opt.fileId;
            var options = {
                expandable: true,
                clickableNodeNames: true,
                onNodeExpand: function () {
                }
            }
            var tree = $("#repository-tree").treetable(options);

            init();

            function init() {
                var title = "<thead><th style='width:50%'>Filename</th><th style='width:30%'>File Type</th></thead>";
                $("#repository-tree").treetable("loadBranch", null, title);
                var href = parent.common.config.rootUrl + "getProjectFileType/" + projectId;
                ide.util.ajax({
                    url: href,
                    type: 'GET',
                    success: function (data) {
                        var data = data.data.json;
                        callback(data);
                    }
                })

            }

            function submit() {

                var data = $('#repository-tree tbody tr');
                if (data.length > 0) {
                    var post = {
                        nodes: []
                    };

                    for (var i = 0; i < data.length; i++) {
                        var nodes = {}
                        nodes.id = $(data[i]).attr("data-tt-id");
                        var pid = $(data[i]).attr("data-tt-parent-id");
                        if (pid) {
                            nodes.pId = pid;
                        } else {
                            nodes.pId = "";
                        }
                        nodes.fileType = $(data[i]).find("select").find("option:selected").val();
                        nodes.projectId = $(data[i]).attr("data-projectId");
                        post.nodes.push(nodes);
                    }

                    repositoryService.editProjectTypeMapping.dialog.disableButton(0);
                    var href = parent.common.config.rootUrl + "updateFileType";
                    //console.log(post);
                    ide.util.ajax({
                        url: href,
                        type: 'POST',
                        data: JSON.stringify(post),
                        error: function () {
                            repositoryService.editProjectTypeMapping.dialog.enableButton(0);
                            repositoryService.editProjectTypeMapping.dialog.close();
                        },
                        success: function (data) {
                            var id = data.data.json.id;
                            var sourceCode = repositoryService.getSourceCode();
                            var pnode = sourceCode.getSelectedItem();
                            var node = sourceCode.getItemsByParam("name", data.data.json.name, pnode[0]);
                            if (node && node.length > 0) {
                                sourceCode.deleteItem(node[0]);
                                sourceCode.addItem(pnode[0], data.data.json);
                            } else {
                                sourceCode.addItem(pnode[0], data.data.json);
                            }
                            var openItem = sourceCode.getItemById(id);

                            pnode[0].isExpanded = true;
                            if (node && node.length > 0) {
                                //console.log(openItem[0]);
                                //openItem[0].isExpanded=true;
                                sourceCode.expand(openItem[0]);
                            }

                            repositoryService.editProjectTypeMapping.dialog.close();
                        }
                    })

                }


            }
        }
    };
    return module;
});