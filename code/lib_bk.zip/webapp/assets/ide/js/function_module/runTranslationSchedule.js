/**
 * Created by ruizhang on 2014/9/11.
 */
define(['jquery', 'datetimepicker'], function ($, datetimepicker) {
    var module = {
        init: function () {
            repositoryService.runTranslationSchedule.submit = function () {
                if (checkTime()) {
                    parent.ide.util.alert(ide.i18n.analysis.nowTime, null, 2);
                    return;
                }
                repositoryService.runTranslationSchedule.dialog && repositoryService.runTranslationSchedule.dialog.disableButton(0);
                var data = {};
                data.scheduleDate = $('#scheduleDate').val();
                data.scheduleTime = $('#scheduleTime').val();
                data.projectId = $('#projectId').val();
                $.ajax({
                    dataType: 'json',
                    contentType: "application/json;charset=UTF-8",
                    type: 'POST',
                    url: common.config.rootUrl + 'schedule/addTranslationJob/',
                    data: JSON.stringify(data),
                    error: function () {
                        parent.ide.util.alert("reuqest error ", null, 3);
                        repositoryService.runTranslationSchedule.dialog && repositoryService.runTranslationSchedule.dialog.enableButton(0);
                        repositoryService.runTranslationSchedule.dialog.close();
                    }
                }).done(function (result) {
                    if (result.status != '200') {
                        parent.ide.util.alert(result.message, null, 3);
                        repositoryService.runTranslationSchedule.dialog && repositoryService.runTranslationSchedule.dialog.enableButton(0);
                    } else {
                        var msg = "JobName:" + result.data.jobName + ", <br/>JobGroup:<em>" + result.data.jobGroup + ",</em><br/>StartTime:" + result.data.time;
                        parent.common.getMainWindow().main.progress(msg, {
                            defaultProgress: 0,
                            defaultTimes: 0
                        });
                        repositoryService.runTranslationSchedule.dialog.close();
                    }

                });

            };


            $('#datetimepicker3').datetimepicker({
                pickDate: false
            });

            $('#datetimepicker4').datetimepicker({
                pickTime: false,
                startDate: new Date()
            });


            //      $('.btn-primary').click(function(){
            //      	if(checkTime()){
            //      		parent.ide.util.alert("Date is Empty or Time can not be less than now ！",null,2);
            //      		return;
            //      	}

            //      	var data = {};
            //      	data.scheduleDate = $('#scheduleDate').val();
            //      	data.scheduleTime = $('#scheduleTime').val();
            //      	data.projectId = $('#projectId').val();
            //      	$.ajax({
            // 	dataType : 'json',
            // 	contentType : "application/json;charset=UTF-8",
            // 	type : 'POST',
            // 	url : '<c:url value="/schedule/addTranslationJob/" />',
            // 	data : JSON.stringify(data)
            // }).done(function(result){
            // 	//console.log(data);
            // 	var msg = "JobName:"+result.data.jobName+", <br/>JobGroup:<em>"+result.data.jobGroup+",</em><br/>StartTime:"+result.data.time;
            //   		parent.common.getMainWindow().main.progress(msg,{
            //   			defaultProgress:0,
            //   			defaultTimes:0
            //   		});

            //   		parent.ide.util.closePopupDialog();
            //   	}).complete(function(result){
            //   	});
            //      });


            function checkTime() {
                if ($.browser.mozilla) {
                    return ($('#scheduleDate').val() == '' || Date.parse($('#scheduleDate').val() + "T" + $('#scheduleTime').val()) < new Date().getTime());
                }
                return ($('#scheduleDate').val() == '' || Date.parse($('#scheduleDate').val() + " " + $('#scheduleTime').val()) < new Date().getTime());
            }
        }
    }
    return module;
});