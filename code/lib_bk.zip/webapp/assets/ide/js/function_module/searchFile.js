/**
 * Created by ruizhang on 2014/10/29.
 */
define(['jquery','moduleCommon','ide'],function($,common,ide){
    var module = {},
        container,searchInput,
        datatable,
        pid,
        max;
    function searchFile(value){
        if(datatable){
            //如果datatable已经初始化完成,则搜索文件
            datatable.search(null,{
                pId: typeof pid == undefined ? '': pid,
                name: value
            });
        }else{
            //初始化datatable
            datatable = new ide.util.Datatable(container.find('#search-result-table'),{
                i18n:{
                    noData: ide.i18n.repository.fileNo
                },
                type:'post',
                url: common.config.rootUrl + 'codefiles/search',
                columns:[{
                    data:'name',
                    title:'fileName'
                },{
                    data:'filePath',
                    title:'path'
                }],
                data:{
                    pId: typeof pid == undefined ? '' : pid,
                    name: value
                },
                searchable:false,
                currentPage:1,
                pageSize: 1000,
                pageable: false,
                headerable:false,
                rowClick: function(e,data){
                    //如果Max等于0
                    if(max&&max==0){
                        return;
                    }
                    $(this).toggleClass('selected-tr');
                    if(max){
                        var length=container.find('tr.selected-tr').length;
                        if(length>1&&max==1){
                            container.find('tr.selected-tr').removeClass("selected-tr");    
                            $(this).addClass("selected-tr");                                
                        }else if(length>max){
                            $(this).removeClass("selected-tr");
                            return;
                        }
                    }
                },
                rowDblclick:function(e,data){
                    openFiles([data.id]);                    
                }
            });
        }
    }

    function openFiles(ids){
        var service = repositoryService;
        if(service && ids && (length = ids.length)){
            service.openItemByIds(ids);
        }
    }

    module.init = function(p,keyword,c){
        container = $('.search-container');
        searchInput = container.find('#search-input');

        pid = p;

        //设置最大可选择的文件数量
        max=c;
        ide.util.autocomplete(searchInput,function(e,value){
           searchFile(value);
        });
        //如果keyword不为空,则默认搜索文件
        if(keyword){
            searchInput.val(keyword).trigger('keyup');
        }
    }



    //设置最大可选择的数量
    module.setMax=function(m){
        max=m;
    }

    //设置父目录
    module.setPid = function(p){
        pid = p;
    }
    //搜索框获得焦点
    module.focusSearchInput = function(){
        searchInput.focus();
    }
    //获取选择的files
    module.getSelectedFiles = function(){
        var ary = [];
        container.find('tr.selected-tr').each(function(){
           ary.push(datatable && datatable.data && datatable.data[$(this).attr('data-index')]);
        });
        return ary;
    }
    return module;
});