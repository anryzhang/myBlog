/**
 * Created by ruizhang on 2014/9/25.
 */
define(['jquery', 'ide', 'moduleCommon'], function ($, ide, common) {
    var module = {
        init: function () {
            var container = $('.team-container'),
                selectBtn = container.find('.team-revert-result-btn button'),
                datatable;

//            var href = common.config.rootUrl + 'assets/data/repository/team/team_revert.json';
            var href = common.config.rootUrl + 'git/getFileReverInfo';

            function _revertEvent(node) {
                console.log(node);
                datatable = new ide.util.Datatable(container.find('#team-revert-table'), {
                    type: 'post',
                    url: href,
                    columns: [
                        {
                            render: function () {
                                //console.log(arguments);
                                return '<input type="checkbox" value="' + arguments[0].id + '" />';
                            }
                        },
                        {
                            data: 'name'

                        },
                        {
                            render: function () {
                                var html;
                                if (arguments[0].isProjectStatus == 1) {
                                    html = '<span class="newstatus">update</span>';
                                } else if (arguments[0].isProjectStatus == 2) {
                                    html = '<span class="updatestatus">delete</span>'
                                }
                                return html;
                            }
                        },
                        {
                            data: 'filePath'
                        },
                        {
                            render: function () {
                                var html,
                                    version = arguments[0].version,
                                    selectStart = '<select class="form-control input-sm">',
                                    selectEnd = '</select>';
                                // <option value=""></option>
                                for (var i = 0; i < version.length; i++) {
                                    html += '<option value="' + version[i] + '">' + version[i] + '</option>';
                                }
                                html = selectStart + html + selectEnd;

                                return html;
                            }
                        }
                    ],
                    data: {
                        projectId: node[0].projectId,
                        id: node[0].id
                    },
                    currentPage: 1,
                    pageSize: 10000,
                    pageable: false,
                    headerable: false,
                    rowClick: function (e, data) {
                        //console.log(data);
                        $(this).toggleClass('selected-tr');
                        if ($(this).hasClass('selected-tr')) {
                            $(this).find('input').attr('checked', true);
                        } else {
                            $(this).find('input').removeAttr('checked');
                        }
                    }
                });
            }

            repositoryService.teamRevert.initRevert = function (nodes) {
                _revertEvent(nodes);
            };

            repositoryService.teamRevert.submit = function () {
                //提交revert数据
                var data = repositoryService.teamRevert.getSubmitData();

                if (data.selectedId.length < 1) {
                    ide.util.tips(ide.i18n.repository.fileOne, 1500, 3);
                    return false;
                } else {
                    ide.util.ajax({
                        type: 'get',
                        url: href,
                        data: JSON.stringify(data),
                        success: function (rs) {
                            if (rs.status == 200) {
                                repositoryService.teamRevert.dialog.close();
                                repositoryService.getSourceCode().updateItem(data);
                                ide.util.tips(rs.message, 1500);
                            }
                        }
                    });

                }

            }
            repositoryService.teamRevert.getSubmitData = function () {
                //返回提交revert需要的参数

                var selected = container.find('input:checked');
                var selectData = [];
                var data;
                for (var i = 0; i < selected.length; i++) {
                    var arrId = {
                        id: $(selected).eq(i).val(),
                        version: $(selected).eq(i).closest('tr').find('select option:selected').val()
                    }
                    selectData.push(arrId);
                }
                data = {
                    selectedId: selectData
                }

                return data;
            }

            //选择要提交的文件
            $.each(selectBtn, function (idx, ele) {
                $(this).on('click', function () {
                    if (idx === 0) {
                        $('#team-revert-table').find('input').attr('checked', true).closest('tr').removeClass('selected-tr');
                    } else if (idx === 1) {
                        $('#team-revert-table').find('.selected-tr input').removeAttr('checked').closest('tr').removeClass('selected-tr');
                    } else if (idx === 2) {
                        $('#team-revert-table').find('input').removeAttr('checked').closest('tr').removeClass('selected-tr');
                    }
                });
            });

        }
    };
    return module;
});