/**
 * Created by ruizhang on 2014/10/27.
 */
define(['jquery', 'ide', 'moduleCommon', 'main'], function ($, ide, common, main) {
    var module = {
        init: function () {
            var service = repositoryService,
                J_fileName = $('#fileName');

            service.updateFileType.submit = function () {
                var formBean = {},
                    sourceCode = service.getSourceCode(),
                    selectedItems = sourceCode.getSelectedItem(),
                    newFileUrl;

                if (selectedItems.length <= 0) {
                    ide.util.alert(ide.i18n.analysis.itemed, null, 3);
                    return;
                }

                formBean.id = selectedItems[0].id;
                $('#J_checkboxList input[type="radio"]:checked').each(function () {
                    formBean.fileType = $(this).attr('id');
                });

                newFileUrl = common.config.rootUrl + 'codefiles/updateFileType';
                service.updateFileType.dialog && service.updateFileType.dialog.disableButton(0);
                ide.util.ajax({
                    type: 'post',
                    url: newFileUrl,
                    dataType: 'json',
                    contentType: 'application/json',
                    data: JSON.stringify(formBean),
                    success: function (data) {
                        if (data && data.status == 200) {
                            service.updateFileType.dialog.close();
                            //刷新已经打开的tab
                            var _tab = main.getCodeTabById(formBean.id);
                            if (_tab) {
                                main.refreshCodeTab(_tab);
                            }
                            //刷新节点
                            selectedItems[0].fileType = formBean.fileType;
                            var _node = $.extend({},selectedItems[0]);
                            sourceCode.updateItem(_node);
                        }
                    },
                    error: function (data) {
                        if (data && data.message) {
                            ide.util.alert(data.message, null, 2);
                        } else {
                            ide.util.alert(ide.i18n.serverError, null, 2);
                        }
                        service.updateFileType.dialog && service.updateFileType.dialog.enableButton(0);
                    }
                });

            };
        }
    };

    return module;
});