/**
 * Created by ruizhang on 2014/11/5.
 */
define(['jquery','ide','moduleCommon','main'],function($,ide,common,main){
    var module = {
        init:function(){
            var container = $('#J-schedule-container'),
                datatable;
            menu.schedule.init = function(){
                datatable = new ide.util.Datatable(container.find('#schedule-result-table'),{
                    i18n:{
                        noData:'No Schedule!'
                    },
                    type:'get',
                    url: common.config.rootUrl + 'schedule/findAllByUser',
                    columns:[{
                        title:'Project Name',
                        data:'projectName'
                    },{
                        title:'Job Type',
                        data:'jobGroup'
                    },{
                        title:'Run Time',
                        data:'startTime'
                    },{
                        title:'End Time',
                        data:'endTime'
                    }/* ,{
                     title:"Runtime",
                     data:"runTime"
                     } */,{
                        title:"Next Run Time",
                        data:"nextFireTime"
                    },{
                        title:"Status",
                        data:"taskStatus"
                    },{
                        title:'Action',
                        render:function(full){
                            console.log('full:',full)
                            var startDisplay = '';
                            var _disabled = "disabled";
                            if(full.taskStatus == 'WAITING'){
                                _disabled = '';
                            }
                            if(full.taskStatus != 'RUNNING'){
                                startDisplay = '<div class="btn btn-xs start '+ _disabled +'" title="run now" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-start"><span id="progress-edittime" class="glyphicon glyphicon-expand"></span></div>';
                            }

                            if('PAUSED' == full.taskStatus){
                                return '<div class="btn btn-xs resume" title="resume" data-id="' + full.jobId +'" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"   id="schedule-play"><span id="progress-remove" class="glyphicon glyphicon-play"></span></div>'
                                    +	startDisplay
                                    +	'<div class="btn btn-xs remove" title="remove" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-remove"><span id="progress-remove" class="glyphicon glyphicon-trash"></span></div>'
                            }else if('COMPLETE' == full.taskStatus){
                                return '<div class="btn btn-xs remove" title="remove" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-remove"><span id="progress-remove" class="glyphicon glyphicon-trash"></span></div>'
                            }else if('ERROR' == full.taskStatus){
                                return '<div class="btn btn-xs remove" title="remove" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-remove"><span id="progress-remove" class="glyphicon glyphicon-trash"></span></div>'
                            }else if('RUNNING' == full.taskStatus){
                                return ''
                            }else{
                                return '<div class="btn btn-xs pause" title="pause" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-stop"><span class="glyphicon glyphicon-stop"></span></div>'
                                    +	startDisplay
                                    +	'<div class="btn btn-xs remove" title="remove" data-id="' + full.jobId + '" data-jobName="' + full.jobName + '"  data-jobGroup="' + full.jobGroup + '"  id="schedule-remove"><span id="progress-remove" class="glyphicon glyphicon-trash"></span></div>'
                            }

                            if(full.taskStatus == 'PAUSED'){
                                $(this).find('.start').addClass('disabled');
                            }
                        }
                    }],
                    searchable:false,
                    currentPage:1,
                    pageSize:1000,
                    pageable:false,
                    rowClick:function(e,full){

                    }
                });
                menu.schedule.datatable = datatable;
            }

            menu.schedule.init();

            container.on('click','.resume',function(){
               var id = $(this).attr('data-id'),
                   jobName = $(this).attr('data-jobName'),
                   jobGroup = $(this).attr('data-jobGroup');
                ide.util.confirm('Resume now?',function(e){
                    ide.util.ajax({
                       url: common.config.rootUrl + '/schedule/resume/' + jobName + '/' + jobGroup,
                        success:function(){
                            datatable.reload();
                        }
                    });
                    e.data.dialog.close();
                });
            });

            container.on('click','.pause',function(){
                var id=$(this).attr("data-id"),
                    jobName=$(this).attr("data-jobName"),
                    jobGroup=$(this).attr("data-jobGroup");

                ide.util.confirm("Pause now?",function(e){

                    ide.util.ajax({
                        url: common.config.rootUrl + "schedule/pause/" + jobName + "/" + jobGroup,
                        success: function () {
                            datatable.reload();

                        }
                    });
                    e.data.dialog.close();
                });
            });

            container.on("click",".remove",function(){
                var id=$(this).attr("data-id"),
                    jobName=$(this).attr("data-jobName"),
                    jobGroup=$(this).attr("data-jobGroup");
                if(id&&id!=''){
                    //如果是历史记录数据，不弹出comfirm
                    ide.util.ajax({
                        url:common.config.rootUrl+"schedule/delete",
                        type:"get",
                        data:{jobName:jobName,jobId:id,jobGroup:jobGroup},
                        success:function(){
                            console.log(arguments[0]);
                            //datatable.localSearch();
                            datatable.reload();
                        }
                    });
                    //menu.schedule.dialog.close();
                }else{
                    ide.util.confirm("Delete now?",function(e){
                        ide.util.ajax({
                            url:common.config.rootUrl+"schedule/delete",
                            type:"get",
                            data:{jobName:jobName,jobId:id,jobGroup:jobGroup},
                            success:function(){
                                console.log(arguments[0]);
                                //datatable.localSearch();
                                datatable.reload();
                            }
                        });
                        e.data.dialog.close();
                    });
                }
            });

            var runList={};
            container.on("click",".start",function(){
                var id=$(this).attr("data-id"),
                    jobName=$(this).attr("data-jobName");

                if(!runList[jobName]){

                    var jobGroup=$(this).attr("data-jobGroup");
                    ide.util.confirm("Run now?",function(e){
                        runList[jobName]=true;
                        ide.util.ajax({
                            url:common.config.rootUrl+"schedule/start/" + jobName+"/"+ jobGroup,
                            type:"get",
                            success:function(){
                                runList[jobName]=false;
                                //datatable.localSearch();
                                //datatable.reload();
                            }
                        });
                        e.data.dialog.close();
                    });
                }else{
                    ide.util.alert("This schedule is running now.",null,3);
                }

            });

            menu.schedule.reload=function(){
                datatable.reload();
            }

        }
    };
    return module;
})