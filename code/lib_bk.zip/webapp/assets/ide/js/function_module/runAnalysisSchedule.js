/**
 * Created by ruizhang on 2014/9/10.
 */
define(['jquery', 'datetimepicker'], function ($, datetimepicker) {
    var module = {
        init: function () {
            repositoryService.runAnalysisSchedule.submit = function () {

                if ($('#scheduleDate').val() == '') {
                    ide.util.alert(ide.i18n.analysis.date, null, 2);
                    return;
                }
                if ($('#scheduleTime').val() == '') {
                    ide.util.alert(ide.i18n.analysis.time, null, 2);
                    return;
                }
                if (checkTime()) {
                    ide.util.alert(ide.i18n.analysis.checkTime, null, 2);
                    return;
                }
                var selectedItems = repositoryService.getSourceCode().getSelectedItem();
                if (selectedItems.length <= 0) {
                    ide.util.alert(ide.i18n.analysis.itemed, null, 2);
                    return;
                }
                var data = {};
                data.scheduleDate = $('#scheduleDate').val();
                data.scheduleTime = $('#scheduleTime').val();
                data.projectId = selectedItems[0].projectId;
                ;

                data.checkIds = "";
                $("#checkboxList input[type='checkbox']:checked").each(function () {
                    data.checkIds += $(this).attr("id") + ",";
                });

                repositoryService.runAnalysisSchedule.dialog && repositoryService.runAnalysisSchedule.dialog.disableButton(0);
                var scheduleUrl = common.config.rootUrl + "schedule/addAnalysisJob";
                $.ajax({
                    dataType: 'json',
                    contentType: "application/json;charset=UTF-8",
                    type: 'POST',
                    url: scheduleUrl,
                    data: JSON.stringify(data),
                    success: function (data) {
                        //console.log(data);
                        repositoryService.runAnalysisSchedule.dialog.close();
                    },
                    error: function (xhr) {
                        //console.log(xhr);
                        var data = $.parseJSON(xhr.responseText);
                        ide.util.alert(data.message, null, 3);
                        repositoryService.runAnalysisSchedule.dialog && repositoryService.runAnalysisSchedule.dialog.enableButton(0);

                    }
                })

            }

            $('#datetimepicker3').datetimepicker({
                pickDate: false
            });

            $('#datetimepicker4').datetimepicker({
                pickTime: false,
                startDate: new Date()
            });

            function checkTime() {
                return ($('#scheduleDate').val() == '' || Date.parse($('#scheduleDate').val() + " " + $('#scheduleTime').val()) < new Date().getTime());
            }
        }
    };
    return module;
});