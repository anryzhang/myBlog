/**
 * Created by ruizhang on 2014/9/11.
 */
define(['jquery', 'datetimepicker'], function ($, datetimepicker) {
    var module = {
        init: function () {
            repositoryService.runCheckstyleSchedule.submit = function () {
                if ($('#scheduleDate').val() == '') {
                    ide.util.alert(ide.i18n.analysis.date, null, 2);
                    return;
                }
                if ($('#scheduleTime').val() == '') {
                    ide.util.alert(ide.i18n.analysis.time, null, 2);
                    return;
                }
                if (checkTime()) {
                    ide.util.alert(ide.i18n.analysis.checkTime, null, 2);
                    return;
                }
                var selectedItems = repositoryService.getSourceCode().getSelectedItem();
                if (selectedItems.length <= 0) {
                    ide.util.alert(ide.i18n.analysis.itemed, null, 2);
                    return;
                }
                var data = {};
                data.scheduleDate = $('#scheduleDate').val();
                data.scheduleTime = $('#scheduleTime').val();
                data.projectId = selectedItems[0].projectId;
                ;

                repositoryService.runCheckstyleSchedule.dialog && repositoryService.runCheckstyleSchedule.dialog.disableButton(0);
                var scheduleUrl = common.config.rootUrl + "schedule/addCheckstyleJob";
                $.ajax({
                    dataType: 'json',
                    contentType: "application/json;charset=UTF-8",
                    type: 'POST',
                    url: scheduleUrl,
                    data: JSON.stringify(data),
                    success: function (data) {
                        if (data.status != '200') {
                            ide.util.alert(data.message, null, 3);
                            repositoryService.runCheckstyleSchedule.dialog && repositoryService.runCheckstyleSchedule.dialog.enableButton(0);
                        } else {
                            repositoryService.runCheckstyleSchedule.dialog.close();
                        }
                    },
                    error: function (rs) {
                        if (rs.status) {
                            ide.util.alert(rs.message, null, 3);
                            repositoryService.runCheckstyleSchedule.dialog && repositoryService.runCheckstyleSchedule.dialog.enableButton(0);
                            repositoryService.runCheckstyleSchedule.dialog.close();
                        }
                    }
                })

            }

            $('#datetimepicker3').datetimepicker({
                pickDate: false
            });

            $('#datetimepicker4').datetimepicker({
                pickTime: false,
                startDate: new Date()
            });

            function checkTime() {
                return ($('#scheduleDate').val() == '' || Date.parse($('#scheduleDate').val() + " " + $('#scheduleTime').val()) < new Date().getTime());
            }
        }

    };
    return module;
});
