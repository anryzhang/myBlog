/**
 * Created by ruizhang on 2014/9/24.
 */
define(['jquery', 'ide', 'moduleCommon', 'cron'], function ($, ide, common, cron) {
    var module = {
        init: function () {
            var container = $('.main-container'),
                projectName = container.find('#new_project_p_name'),
                J_MfTab = container.find('.J_MfTab'),
                J_mappingBox = container.find('.J_mappingBox'),
                J_mapping = J_mappingBox.find('.J_mapping'),
                J_serverTime = container.find('.J_serverTime');
            var clearLocalTime;

            //获取选中的节点数据
            var node = repositoryService.getSelectedItems();

            var edit_project_save = common.config.rootUrl + 'ide/do_edit_project';
            var edit_project_search = common.config.rootUrl + 'ide/project/getProjectFormData';
            //'assets/data/repository/newProject/file_type.json';
            var FtpUrl = common.config.rootUrl + 'ide/testFtpConnection';

            function _editProject() {
                projectName.focus();

                var data = {
                    projectId: node[0].projectId
                };
                ide.util.ajax({
                    type: 'post',
                    //type:'get',
                    dataType: 'json',
                    url: edit_project_search,
                    data: JSON.stringify(data),
                    success: function (rs) {
                        if (rs.status == 200) {
                            var data = rs.data.json;
                            var fileType = data.fileType;

                            var localTime = new Date();
                            var serverTime = rs.data.json.serverTimeLong || localTime.getTime();
                            countDown(serverTime);

                            container.find('#new_project_p_name').val(data.projectName);
                            //渲染 project type
//                        var proData = data.projectType;
//                        var proOption = '';
//                        for(var i = 0; i < proData.length; i++){
//                            if(proData[i].isSelected == true){
//                                proOption += '<div class="checkbox-item"><input type="checkbox" checked="true" id="projectType'+ i +'" value="'+ proData[i].key + '"/><label class="checkbox-inline" for="projectType'+ i +'">'+ proData[i].value +'</label></div>';
//                            }else{
//                                proOption += '<div class="checkbox-item"><input type="checkbox" id="projectType'+ i +'" value="'+ proData[i].key + '"/><label class="checkbox-inline" for="projectType'+ i +'">'+ proData[i].value +'</label></div>';
//                            }
//                        }
//                        $('#J_projectType').append(proOption);
                            //设置 desc
                            $('#projectDesc').val(data.projectDesc);
                            //绑定文件类型数据 到 #Mf
                            container.find('.J_type input[id="Mf"]').data('mfdata', fileType);
                            //设置选中
                            if (data.serverType == "UPLOAD") {
                                container.find('#upload').attr('checked', "checked");
                                container.find('.J_tables').eq(1).addClass('active').siblings().removeClass('active');
                                var html = rendMapping(fileType);
                                J_mapping.find('.tab-body').append(html);
                            } else if (data.serverType == 'UNDO') {
                                container.find('#config').attr('checked', 'checked');
                                container.find('.J_tables').eq(2).addClass('active').siblings().removeClass('active');
                                var html = rendMapping(fileType);
                                J_mapping.find('.tab-body').append(html);
                            } else {
                                container.find('#Mf').attr('checked', 'checked');
                                container.find('.J_tables').eq(0).addClass('active').siblings().removeClass('active');

                                $('#urlAddress').val(data.remoteAddress);
                                $('#port').val(data.remotePort);
                                $('#Username').val(data.remoteUsername);
                                $('#Password').val(data.remotePassword);

                                var html = template('J_tempBranch', data);
                                J_mappingBox.append(html);

                            }
                            var scheduleTime = data.scheduleJob.cronExpression;
                            container.find('#J_schedual').cron({
                                initial: scheduleTime || "0 0 1 * *",
                                onChange: function () {
                                    $('#J_schedual-val').val($(this).cron("value"));
                                },
                                useGentleSelect: true
                            });

                            if(data.serverType != 'FTP'){
                                var len = J_mappingBox.find('.J_mapping').length;
                                if (!len) {
                                    var targetHtml = _defBranchHtml();
                                    var html;
                                    html = '<div class="J_mapping mapping-item">' + targetHtml + '</div>';
                                    J_mappingBox.append(html);
                                }
                            }

                            //初始化tabSelect
                            repositoryService.tabSelect(container.find('.J_MfTab'));

                        }
                    }
                });

            }

            repositoryService.editProject.initProject = function () {
                _editProject();
            };

            function countDown(time) {
                // 创建两个变量，一个数组中的月和日的名称
                var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug ", "Sep ", "Oct ", "Nov", "Dec" ];
                var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri ", "Sat"]

                var _time = parseInt(time);
                // 创建一个对象newDate（）
                var newDate = new Date(_time);
                //输出的日子，日期，月和年
                clearLocalTime = setInterval(function () {
                    _time += 1000;
                    newDate = new Date(_time);
                    J_serverTime.find('#Date').html(dayNames[newDate.getDay()] + ',  ' + monthNames[newDate.getMonth()] + ' ' + newDate.getDate() + ',  ' + newDate.getFullYear() + '<span style="display: inline; padding-left: 15px;"></span>' + ((newDate.getHours() < 10 ? "0" : "") + newDate.getHours()) + ':' + ((newDate.getMinutes() < 10 ? "0" : "") + newDate.getMinutes()) + ':' + (newDate.getSeconds() < 10 ? "0" : "") + newDate.getSeconds());


                }, 1000);

            }

            repositoryService.editProject.submit = function () {
                //提交commit数据
                var data = repositoryService.editProject.getSubmitData();
                //console.log(data);
                if (!data) {
                    return false;
                }
//            if(data.projectType.length < 1){
//                ide.util.tips('Select at least one project type!',1500,3);
//                return false;
//            }

                //ftp时 提示用户自动更新时间
                if (data.serverType == 'FTP' && data.scheduleJob.cronExpression == '0 0 0 1 * ?') {
                    ide.util.confirm('Default run time is the 1st day of every month, press OK to continue', function (ev) {
                        submitProject();
                        clearInterval(clearLocalTime);
                        ev.data.dialog.close();

                    });
                } else {
                    submitProject();
                }

                function submitProject() {
                    repositoryService.editProject.dialog.disableButton(0);
                    ide.util.ajax({
                        type: 'POST',
                        url: edit_project_save,
                        data: JSON.stringify(data),
                        success: function (rs) {
                            if (rs.status == 200) {
                                //radio 选择 upload 时
                                if (container.find('.J_upload').closest('.J_tables').hasClass('active')) {
                                    repositoryService.editProject.dialog.close();
                                    //var tree = repositoryService.getSourceCode();
                                    //repositoryService.uploadSourceCode(rs.data.json.nodes[0].id);

                                } else {
                                    repositoryService.updateProject(rs.data.json);
                                    repositoryService.editProject.dialog.close();
                                    ide.util.tips(rs.message, 1500);
                                }

                            } else {
                                repositoryService.editProject.dialog.enableButton(0);
                                ide.util.alert(rs.message, null, 2);
                            }

                        },
                        error: function (rs) {
                            if (rs.status) {
                                ide.util.alert(rs.message, null, 2);
                                repositoryService.editProject.dialog.enableButton(0);
                            }
                        }
                    });
                }

                return false;
            }

            repositoryService.editProject.getSubmitData = function () {
                //返回提交需要的参数
                var postData = {};
                var scheduleJob = {};
                var branchData = _getBranchData();


//            var project_types = [];
//            var selectedInput = container.find('#J_projectType input:checked');
//            for(var i = 0; i < selectedInput.length; i++ ){
//                project_types.push(selectedInput.eq(i).val());
//            }

                if (J_MfTab.closest('.J_tables').hasClass('active')) {
                    scheduleJob = {
                        cronExpression: container.find('#J_schedual-val').val(),
                        isRunNow: (container.find('#J_isBegin').attr('checked') == 'checked') ? true : false
                    };
                    postData = {
                        serverType: container.find('.J_type input:checked').attr('data-key'),
                        projectId: node[0].projectId,
                        projectName: $.trim(container.find('#new_project_p_name').val()),
                        //projectType: project_types,
                        projectDesc: $.trim(container.find('#projectDesc').val()),
                        remoteAddress: $.trim(container.find('#urlAddress').val()),
                        remotePort: container.find('#port').val(),
                        remoteUsername: $.trim(container.find('#Username').val()),
                        remotePassword: container.find('#Password').val(),
                        branchData: branchData,
                        scheduleJob: scheduleJob,
                        clientTime: $.now()
                    }

                    if (!postData.projectName) {
                        ide.util.tips('Project Name cannot be empty !', 1500, 3);
                        container.find('#new_project_p_name').focus();
                        return false;
                    }
//                if(postData.projectType.length < 1){
//                    ide.util.tips('Select at least one project type!',1500,3);
//                    return false;
//                }
                    if (!postData.remoteAddress) {
                        ide.util.tips(ide.i18n.projectTipInfo.ip, 1500, 3);
                        container.find('#urlAddress').focus();
                        return false;
                    }
                    if (!postData.remotePort) {
                        ide.util.tips(ide.i18n.projectTipInfo.port, 1500, 3);
                        container.find('#port').focus();
                        return false;
                    }
                    if (!postData.remoteUsername) {
                        ide.util.tips(ide.i18n.projectTipInfo.ftpusername, 1500, 3);
                        container.find('#Username').focus();
                        return false;
                    }
                    if (!postData.remotePassword) {
                        ide.util.tips(ide.i18n.projectTipInfo.ftpPassword, 1500, 3);
                        container.find('#Password').focus();
                        return false;
                    }

                    if (postData.branchData.length < 1 || postData.branchData[0].dataMapping.length < 1) {
                        ide.util.tips(ide.i18n.projectTipInfo.mapping, 1500, 3);
                        J_MfTab.find('#J_mp').closest('li').addClass('active').siblings().removeClass('active');
                        J_mappingBox.closest('.tab-pane').addClass('active').siblings().removeClass('active');

                        return false;
                    }

                    //验证ftp下载
                    for (var i = 0; i < postData.branchData.length; i++) {
                        if (postData.branchData[i].dataMapping.length) {
                            if (common.role != 1) {
                                //common.role != 1时,是一般用户,为1时是admin 用户
                                for (var k = 0, l = postData.branchData[i].dataMapping.length; k < l; k++) {

                                    if (postData.branchData[i].dataMapping[k].address.toUpperCase().indexOf(postData.remoteUsername.toUpperCase() + ".") == 0 && postData.branchData[i].dataMapping[k].address.length > (postData.remoteUsername + "." ).length) {

                                    } else {

                                        ide.util.alert("PDS name: " + postData.branchData[i].dataMapping[k].address + " is error.<br> Only FTP username's dataset can be downloaded.", null, 3);
                                        J_MfTab.find('#J_mp').closest('li').addClass('active').siblings().removeClass('active');
                                        J_mappingBox.closest('.tab-pane').addClass('active').siblings().removeClass('active');

                                        J_mapping.closest('.tab-pane').find("input").eq(k).focus();
                                        return false;
                                    }
                                }
                            }

                        }
                    }

                } else {
                    postData = {
                        serverType: container.find('.J_type input:checked').attr('data-key'),
                        projectId: node[0].projectId,
                        projectName: container.find('#new_project_p_name').val(),
                        //projectType: project_types,
                        projectDesc: container.find('#projectDesc').val()
                    }
                }

                if (!promtMessage(postData.projectName, "Project Name cannot be empty !")) {
                    container.find('#new_project_p_name').focus();
                    return false;
                }

                if (postData.projectName.length > 40) {
                    ide.util.alert('Max length for Project Name is 40 characters !', null, 3);
                    return false;
                }

                if (postData.projectName.length > 400) {
                    ide.util.alert('Max length for Description is 400 characters !', null, 3);
                    return false;
                }


                return postData;
            }

            //branch data
            function _getBranchData() {
                var branchData = [];
                var branchItem = {};
                var len = J_mappingBox.find('.J_mapping').length;
                for (var i = 0; i < len; i++) {
                    branchItem = {
                        "branchName": $.trim(J_mappingBox.find('.J_mapping').eq(i).find('.J_branchTitle').text()),
                        "isMaster": J_mappingBox.find('.J_mapping').eq(i).find('.J_delBranch:hidden').length ? true : false,
                        "dataMapping": (function () {
                            var arrMap = [];

                            for (var j = 0; j < J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').length; j++) {
                                var ft = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('select option:selected').val();
                                var as = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('.file-add input').val();
                                var fn = J_mappingBox.find('.J_mapping').eq(i).find('.tab-body li').eq(j).find('.fold-name input').val();
                                if (!as ) {
                                    continue;
                                } else {
                                    var mapItem = {
                                        "fileType": ft,
                                        "address": $.trim(as),
                                        "folderName":$.trim(as)
                                    }
                                    arrMap.push(mapItem);
                                }
                            }
                            return arrMap;
                        })()
                    }

                    branchData.push(branchItem);
                }

                return branchData;
            }

            //验证不为空的form
            function promtMessage(checkVal, msg) {
                if (checkVal == null || $.trim(checkVal) == '') {
                    ide.util.alert(msg, null, 3);
                    return false;
                }
                return true;
            }

            //仓库类型切换
            var typeBtn = container.find('.J_type input');
            $.each(typeBtn, function (idx, ele) {
                $(this).on('click', function () {
                    $('.J_tables').eq(idx).addClass('active').siblings('.J_tables').removeClass('active');
                })
            })


            //add 渲染mapping
            function rendMapping(data) {

                var _data = {
                    list:data
                }
                var html = template('J_tempBranchItem',_data);
                return html;

               /* var htmlStart = '<li>' +
                    '<div class="pull-left text-left file-type">' +
                    '<select class="form-control">';
                var option = null;
                var htmlEnd = '</select>' +
                    '</div>' +
                    '<div class="pull-left text-left fold-name">' +
                    '<input placeholder="Folder Name" class="form-control">' +
                    '</div>' +
                    '<div class="pull-left text-center file-add">' +
                    '<input placeholder="Type dataset name: eg. PROD.BATCH.SRC" class="form-control" type="text">' +
                    '</div>' +
                    '<div class="pull-left text-center mp-icon">' +
                    '<a href="" class="J_delMapp glyphicon glyphicon-minus-sign"></a>' +
                    '</div>' +
                    '</li>';


                for (var i = 0; i < data.length; i++) {
                    option += '<option value="' + data[i].key + '">' + data[i].value + '</option>';
                }

                return htmlStart + option + htmlEnd;*/
            }

            function _defBranchHtml() {
                //edit project add branch
                var data = container.find('.J_type input[id="Mf"]').data('mfdata');
                var liItem = rendMapping(data);
                var html = '<div class="J_branchHead branch-title-box">' +
                    '<div class="pull-left branch-lable">Git branch:</div>' +
                    '<div class="J_branchTitle pull-left branch-name">master</div>' +
                    '<div class=" pull-right branch-del">' +
                    '<a href="" class="J_delBranch glyphicon glyphicon-minus-sign" style="color:red;display: none"></a>' +
                    '</div>' +
                    '</div>' +
                    '<ul class="tab-head">' +
                    '<li>' +
                    '<div class="pull-left text-center  file-add">PDS Name</div>' +
                    '<div class="pull-left text-center file-type">File Type</div>' +
                    //'<div class="pull-left text-center fold-name">Folder Name</div>' +
                    '<div class="pull-left text-center  mp-icon"><a href="" class="J_addMapp glyphicon glyphicon-plus-sign"></a></div>' +
                    '</li>' +
                    '</ul>' +
                    '<ul class="tab-body">' + liItem + '</ul>';

                return html;
            }

            //显示master
            J_MfTab.find('#J_mp').closest('li').on('click', function (e) {
                var len = J_mappingBox.find('.J_mapping').length;
                if (!len) {
                    var targetHtml = _defBranchHtml();
                    var html;
                    html = '<div class="J_mapping mapping-item">' + targetHtml + '</div>';
                    J_mappingBox.append(html);
                }
            });

            //添加分支
            container.on('click', '.J_addBranch', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var targetHtml = _defBranchHtml();
                var objHtml = J_mappingBox.find('.J_mapping').eq(0).html();
                var html;
                if (J_mappingBox.find('.J_mapping').length) {
                    html = '<div class="J_mapping mapping-item" data-branch="1">' + objHtml + '</div>';
                } else {
                    html = '<div class="J_mapping mapping-item">' + targetHtml + '</div>';
                }
                J_mappingBox.append(html);
                container.find('[data-branch="1"]').find('.J_branchTitle').text('New branch').attr('contenteditable', 'true');
                container.find('[data-branch="1"]').find('.J_delBranch').show();
            });

            //删除分支
            J_mappingBox.on('click', '.J_delBranch', function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).closest('.J_mapping').remove();
            });

            //添加mapping 项
            J_mappingBox.on('click', '.J_addMapp', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var data = container.find('.J_type input[id="Mf"]').data('mfdata');
                var html = rendMapping(data);
                if (!$(this).closest('.J_mapping').find('.tab-body li').length) {
                    $(this).closest('.J_mapping').find('.tab-body').append($(html));
                } else {
                    $(this).closest('.J_mapping').find('.tab-body li:first').before($(html));
                }
            });
            //删除mapping 项
            J_mappingBox.on('click', '.J_delMapp', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var len = $(this).closest('.J_mapping').find('.tab-body li').length;
                if (len < 2) {
                    ide.util.tips("Can't delete all, keep at least one!", 1500, 3);
                    return false
                } else {
                    $(this).closest('li').remove();
                }

            });

            //test fit 连接

            container.on('click', '.J_testFtp ', function (e) {
                e.preventDefault();
                var data = {
                    remoteAddress: $('#urlAddress').val(),
                    remotePort: $('#port').val(),
                    remoteUsername: container.find('#Username').val(),
                    remotePassword: container.find('#Password').val()
                };
                //前端判断表单字段
                if (!data.remoteAddress) {
                    ide.util.tips(ide.i18n.projectTipInfo.ip, 1500, 3);
                    container.find('#urlAddress').focus();
                    return false;
                }
                if (!data.remotePort) {
                    ide.util.tips(ide.i18n.projectTipInfo.port, 1500, 3);
                    container.find('#port').focus();
                    return false;
                }
                if (!data.remoteUsername) {
                    ide.util.tips(ide.i18n.projectTipInfo.ftpusername, 1500, 3);
                    container.find('#Username').focus();
                    return false;
                }
                if (!data.remotePassword) {
                    ide.util.tips(ide.i18n.projectTipInfo.ftpPassword, 1500, 3);
                    container.find('#Password').focus();
                    return false;
                }

                ide.util.ajax({
                    type: 'post',
                    dataType: 'json',
                    url: FtpUrl,
                    data: JSON.stringify(data),
                    success: function (rs) {
                        if (rs.status == 200) {
                            ide.util.tips(rs.message, 1500);
                        } else {
                            ide.util.alert(rs.message, null, 2);
                        }
                    }
                });

            });
            //是否立即执行标识
            container.on('click', '#J_isBegin', function (e) {
                if ($(this).attr('checked')) {
                    $(this).attr('checked', true);
                } else {
                    $(this).attr('checked', false);
                }
            });
        }
    }

    return module;


})