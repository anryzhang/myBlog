/**
 * Created by ruizhang on 2014/10/28.
 */
define(['jquery','ide','moduleCommon','main'],function($,ide,common,main){
    var module = {
        init:function(){
            var J_fileName = $('#fileName'),
                id = J_fileName.attr('data-id'),
                _regName = null,
                _regStr = '^[.]|[.]$',
                _isReg,
                _fileName = J_fileName.val();

            J_fileName.focus();

            repositoryService.newFolder.submit = function(){
                var formBean = {},
                    sourceCode = repositoryService.getSourceCode(),
                    selectedItems = sourceCode.getSelectedItem(),
                    newFileUrl;

                if(selectedItems.length <= 0){
                    ide.util.alert(ide.i18n.analysis.itemed,null,3);
                    return ;
                }
                if(id != null && id !=''){
                    formBean.id = selectedItems[0].id;
                    formBean.name = J_fileName.val();
                    newFileUrl = common.config.rootUrl + 'codefiles/renamefile';
                    if(!formBean.name){
                        ide.util.alert(ide.i18n.repository.folderName,null,3);
                        return ;
                    }
                    //判断folder name 是否一致
                    if(_fileName == formBean.name){
                        repositoryService.newFolder.dialog.close();
                        return ;
                    }

                    //前端验证文件名不能以点号开始,以点号结束
                    _regName = J_fileName.val();
                    var reg_name = new RegExp(_regStr,'g');
                    _isReg = reg_name.test(_regName);
                    if(_isReg){
                        ide.util.alert(ide.i18n.repository.noPoint,null,3);
                        return;
                    }


                    repositoryService.newFolder.dialog.disableButton(0);
                    ide.util.ajax({
                        type:'post',
                        url: newFileUrl,
                        dataType: 'json',
                        contentType:'application/json',
                        data:JSON.stringify(formBean),
                        success:function(data){
                            var node = sourceCode.getSelectedItem();
                            if(node){
                                node[0].name = data.data.json.name;
                            }
                            sourceCode.updateItem(node[0]);
                            repositoryService.newFolder.dialog.close();
                        },
                        error:function(data){
                            if(data && data.message){
                                ide.util.alert(data.message,null,2);
                            }else{
                                ide.util.alert(ide.i18n.serverError,null, 2);
                            }
                            repositoryService.newFolder.dialog.enableButton(0);
                        }

                    });

                }else{
                    formBean.pId = selectedItems[0].id;
                    formBean.name = J_fileName.val();
                    formBean.fileType = 'FOLDER';
                    newFileUrl = common.config.rootUrl + 'codefiles/createfile';
                    if(!formBean.name){
                        ide.util.alert(ide.i18n.repository.folderName,null, 3);
                        return;
                    }

                    //前端验证文件名不能以点号开始,以点号结束
                    _regName = J_fileName.val();
                    var reg_name = new RegExp(_regStr,'g');
                    _isReg = reg_name.test(_regName);
                    if(_isReg){
                        ide.util.alert(ide.i18n.repository.noPoint,null,3);
                        return;
                    }


                    repositoryService.newFolder.dialog.disableButton(0);
                    ide.util.ajax({
                        type:'post',
                        url:newFileUrl,
                        dataType:'json',
                        data:JSON.stringify(formBean),
                        success:function(data){
                            sourceCode.addItem(selectedItems[0],data.data.json);
                            var addNode = sourceCode.getItemById(data.data.json.id);
                            if(selectedItems[0].children.length > 1){
                                sourceCode.moveItem(selectedItems[0].children[0],addNode[0],'prev');
                            }
                            repositoryService.newFolder.dialog.close();
                        },
                        error:function(data){
                            if(data && data.message){
                                ide.util.alert(data.message,null,2);
                            }else{
                                ide.util.alert(ide.i18n.serverError,null, 2);
                            }
                            repositoryService.newFolder.dialog.enableButton(0);
                        }
                    });
                }

            }
        }
    };

return module;
});

