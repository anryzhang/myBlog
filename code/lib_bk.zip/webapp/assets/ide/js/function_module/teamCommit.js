/**
 * Created by ruizhang on 2014/9/25.
 */
define(['jquery', 'ide', 'moduleCommon'], function ($, ide, common) {
    var module = {
        init: function () {
            var// repositoryService = main.getRepositoryWindow().repositoryService,
                container = $('.team-container'),
                selectBtn = container.find('.team-commit-result-btn button'),
                datatable;

            //var href = common.config.rootUrl + 'assets/data/repository/team/team_commit.json';
            var href = common.config.rootUrl + 'git/getCommitFileStatus';

            function _commitEvent(node) {
                var postData = {
                    projectId: node[0].projectId,
                    ids: [node[0].id]
                };
                container.find('#team-commit-input').data('projectId', node[0].projectId);
                datatable = new ide.util.Datatable(container.find('#team-commit-table'), {
                    type: 'post',
                    url: href,
                    columns: [
                        {
                            render: function () {

                                //console.log(arguments);
                                return '<input type="checkbox" data-path="' + arguments[0].filePath + '" value="' + arguments[0].id + '" checked/>';
                            }
                        },
                        {
                            data: 'fileName'

                        },
                        {
                            render: function () {
                                console.log(arguments);
                                var html;
                                if (arguments[0].changeType == "ADD") {
                                    html = '<span class="newstatus">new</span>';
                                } else if (arguments[0].changeType == 'MODIFY') {
                                    html = '<span class="updatestatus">update</span>'
                                } else if (arguments[0].changeType == 'DELETE') {
                                    html = '<span class="updatestatus">delete</span>'
                                } else {
                                    html = arguments[0].changeType;
                                }
                                return html;
                            }
                        },
                        {
                            //title:'path',
                            data: 'filePath'
                        }
                    ],
                    data: postData,
                    currentPage: 1,
                    pageSize: 10000,
                    pageable: false,
                    headerable: false,
                    rowClick: function (e, data) {
                        //console.log(data);
                        $(this).toggleClass('selected-tr');
                        if ($(this).hasClass('selected-tr')) {
                            $(this).find('input').attr('checked', true);
                        } else {
                            $(this).find('input').removeAttr('checked');
                        }
                    }
                });
            }

            repositoryService.teamCommit.initCommit = function (nodes) {
                _commitEvent(nodes);
            };

            repositoryService.teamCommit.submit = function () {
                //提交commit数据
                var postData = repositoryService.teamCommit.getSubmitData();

                if (!postData.remark) {
                    ide.util.tips(ide.i18n.repository.commit, 1500, 3);
                    return false;
                } else if (postData.filePaths.length < 1) {
                    ide.util.tips(ide.i18n.repository.fileOne, 1500, 3);
                    return false;
                } else {
                    ide.util.ajax({
                        type: 'post',
                        url: common.config.rootUrl + 'git/commitFileItem',
                        data: JSON.stringify(postData),
                        success: function (rs) {
                            if (rs.status == 200) {
                                repositoryService.teamCommit.dialog.close();
                                ide.util.tips(rs.message, 1500);
                            }
                        }
                    });

                }

            }
            repositoryService.teamCommit.getSubmitData = function () {
                //返回提交commit需要的参数
                var _commit = container.find('#team-commit-input').val();
                var projectId = container.find('#team-commit-input').data('projectId');
                var selected = container.find('input:checked');
                var selectData = [];
                var data;
                for (var i = 0; i < selected.length; i++) {
                    var paths = $(selected).eq(i).attr('data-path');
                    selectData.push(paths);
                }
                data = {
                    remark: _commit,
                    projectId: projectId,
                    filePaths: selectData
                }
                return data;
            }

            //选择要提交的文件
            $.each(selectBtn, function (idx, ele) {
                $(this).on('click', function () {
                    if (idx === 0) {
                        $('#team-commit-table').find('input').attr('checked', true).closest('tr').removeClass('selected-tr');
                    } else if (idx === 1) {
                        $('#team-commit-table').find('.selected-tr input').removeAttr('checked').closest('tr').removeClass('selected-tr');
                    } else if (idx === 2) {
                        $('#team-commit-table').find('input').removeAttr('checked').closest('tr').removeClass('selected-tr');
                    }
                });
            });
        }

    };
    return module;
});