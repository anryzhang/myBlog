/**
 * Created by ruizhang on 2014/9/25.
 */
define(['jquery', 'ide', 'moduleCommon'], function ($, ide, common) {
    var module = {
        init: function () {
            var container = $("#J-list-file-container"),
                datatable,
                pid;

            repositoryService.runTransformationImmediately.init = function (projectId) {

                datatable = new ide.util.Datatable(container.find("#list-file-result-table"), {
                    "i18n": {
                        noData: "No matched files."
                    },
                    type: "get",
                    //url:common.config.rootUrl+"/assets/ide/data/datatable.json",
                    url: common.config.rootUrl + "transformationConfig/scriptFileList?projectId=" + projectId,
                    columns: [
                        {
                            data: "name",
                            title: "Name"
                        },
                        {
                            title: "File Path",
                            data: "filePath"
                        }
                    ],
                    searchable: false,
                    currentPage: 1,
                    pageSize: 1000,
                    pageable: false,
                    //headerable:false,
                    rowClick: function (e, data) {
                        $(this).toggleClass("selected-tr").siblings().removeClass("selected-tr");
                    }
                });
            }


            //将函数绑定在service上
            repositoryService.runTransformationImmediately.setPid = function (projectId) {
                pid = projectId;
            }
            repositoryService.runTransformationImmediately.focusSearchInput = function () {
                searchInput.focus();
            }
            repositoryService.runTransformationImmediately.getSelectedFiles = function () {
                var ary = [];
                container.find("tr.selected-tr").each(function () {
                    ary.push(datatable && datatable.data && datatable.data[$(this).attr("data-index")]);
                });

                return ary;
            };
        }
    };
    return module;
})