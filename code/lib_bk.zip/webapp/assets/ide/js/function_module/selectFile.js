/**
 * Created by ruizhang on 2014/10/29.
 */
define(['jquery','moduleCommon','ide'],function($,common,ide){
    var module = {
        init:function(){
            var container = $('#select-file-container'),
                $datatable = container.find('#select-result-table'),
                $searchDatatable = container.find('#search-result-datatable'),
                $tree = container.find('#search-result-tree'),
                datatableClearSelected = container.find('#datatable-clear-selected'),
                datatableClearAll = container.find('#datatable-clear-all'),
                searchResultSelectSelected = container.find('#search-result-select-selected'),
                searchResultSelectAll = container.find('#J_result_select_all'),
                searchInput = container.find('#search-input'),
                treeSelectSelected=container.find("#tree-select-selected"),
                datatable,
                tree,
                searchDatatable,
                pid,
                selectCount,
                columns,
                searchable = true,
                url,
                timer;


            function registerHandler(){
                datatableClearSelected.click(function(){
                    var _trs = $datatable.find('tr.selected-tr');
                    if(_trs.length){
                        ide.util.confirm(ide.i18n.repository.deleteFile,function(e){
                            removeDatatableData(_trs);
                            e.data.dialog.close();
                        });
                    }
                });
            }

            datatableClearAll.click(function(){
                var _trs=$datatable.find("tr");
                if(_trs.length){
                    ide.util.confirm(ide.i18n.repository.deleteFile,function(e){
                        removeDatatableData(_trs);
                        e.data.dialog.close();
                    });
                }
            });

            treeSelectSelected.click(function(){
                var length,items=tree.getSelectedItems();
                if(items&&(length=items.length)){
                    for(var i=0;i<length;i++){
                        addData(items[i]);
                    }
                }
            });

            searchResultSelectAll.click(function(){
               var _datas = searchDatatable.getDatas(),
                   length;
                if(_datas && (length = _datas.length)){
                    for(var i = length-1;i>-1; i--){
                        addData(_datas[i],'filePath');
                    }
                }
            });

            searchResultSelectSelected.click(function(){
                var _trs = $searchDatatable.find('tr.selected-tr');
                if(_trs.length){
                    _trs.each(function(index){
                        addData(searchDatatable.data[$(this).attr('data-index')]);
                    });
                }
            });

            function removeDatatableData(trs){
                trs.each(function(index){
                   datatable.remove(datatable.data[$(this).attr('data-index')]);
                });
            }

            registerHandler();


            repositoryService.selectFiles.init = function(arg){
                pid = arg.pId;
                selectCount = arg.max;
                url = arg.url;
                columns = arg.columns;
                searchable = arg.searchable;

                if(!columns){
                    columns = [{
                        width:150,
                        data:'name',
                        title: 'fileName'
                    },{
                        data:'filePath',
                        title:'path'
                    }];
                }

                if(!url){
                    url = common.config.rootUrl + 'codefiles/search';
                }

                if(typeof searchable != undefined && !searchable){
                    container.find('#J_search_box').hide();
                }

                repositoryService.selectFiles.searchFile(null, arg.params, arg.customParams);

                ide.util.autocomplete(searchInput,function(e,value){
                    repositoryService.selectFiles.searchFile(value, arg.params, arg.customParams);
                    //initSearchTree(common.config.rootUrl + 'assets/ide/data/ztreeData.json',{
                    //    pId:p,
                    //    name:value
                    //});
                });

                initSelectTable();

            }

            function initSelectTable(){
                datatable = new ide.util.Datatable($datatable,{
                    type:'post',
                    columns: columns,
                    searchable: false,
                    currentPage: 1,
                    pageSize: 1000,
                    pageable:false,
                    headerable:false,
                    rowClick:function(e,data){
                        $(this).toggleClass('selected-tr');
                    }
                });
            }

            function addData(treeNode,name){
                if(!name){
                    name = 'filePath';
                }
                var filter = {};

                filter[name] = treeNode[name];
                
                
                if(!treeNode.isParent){
                    var _datas = datatable.localSearch(filter);
                    if(!_datas.length){
                        var datas = datatable.getDatas();
                        if(selectCount && datas && selectCount <= datas.length){
                            return ;
                        }
                        datatable.unshift([treeNode]);

                    }
                }

            }

            function initSearchTree(url,params){
                require(['codeCommon'],function(Common){
                   tree = new Common($tree,{
                       setting: {
                           async:{
                               type:'get',
                               url:url,
                               otherParam:params
                           },
                           beforeClick:function(event, treeNode){
                               if(treeNode.isParent){
                                   return false;
                               }
                           },
                           dblClick:function(event,treeNode){
                               addData(treeNode);
                           }
                       }
                   });
                });
            }

            repositoryService.selectFiles.searchFile = function(value,params,customParams){
                var _params = $.extend({},params);
                if(!customParams){
                    _params.pId = typeof pid == undefined ? '' :pid;
                    _params.name = value;
                }
                if(searchDatatable) {
                    searchDatatable.search(null,_params);
                }else{
                    searchDatatable = new ide.util.Datatable($searchDatatable,{
                       i18n:{
                           noData: ide.i18n.repository.fileNo
                       },
                        type:'post',
                        url: url,
                        columns: columns,
                        data: _params,
                        searchable: false,
                        currentPage:1,
                        pageSize:1000000,
                        pageable:false,
                        headerable:false,
                        rowClick:function(e,data){
                            $(this).toggleClass('selected-tr');
                        },
                        rowDblclick:function(e,data){
                            addData(data);
                        }
                    });
                }

            }

            repositoryService.selectFiles.focusSearchInput = function(){
                searchInput.focus();
            }

            repositoryService.selectFiles.getSelectedFiles = function(){
                var ary = [];
                return datatable.data;
            }


        }
    };
    return module;
})