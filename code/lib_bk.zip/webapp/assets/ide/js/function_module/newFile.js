/**
 * Created by ruizhang on 2014/10/27.
 */
define(['jquery','ide','moduleCommon','main'],function ($,ide,common,main) {
    var module = {
        init:function(){
            var id = "",
                service = repositoryService,
                J_fileName = $('#fileName'),
                _regName = null,
                _regStr = '^[.]|[.]$',
                _isReg,
                _fileName = J_fileName.val();


            J_fileName.focus();
            id = J_fileName.attr('data-id');



            service.newFile.submit = function(){
                var formBean = {},
                    newFileUrl,
                    sourceCode = service.getSourceCode(),
                    selectedItems = sourceCode.getSelectedItem();

                if(selectedItems.length <= 0){
                    ide.util.alert(ide.i18n.analysis.itemed,null,3);
                    return;
                }

                /*
                * if id == null or '' then new file
                * else edit file
                * */
                if(id != null && id != ''){
                    formBean.id = selectedItems[0].id;

                    formBean.name = J_fileName.val();
                    newFileUrl = common.config.rootUrl + 'codefiles/renamefile';
                    if(!formBean.name){
                        ide.util.alert(ide.i18n.repository.fileName,null,3);
                        return ;
                    }

                    //前端验证文件名不能以点号开始,以点号结束
                    _regName = J_fileName.val();
                    var reg_name = new RegExp(_regStr,'g');
                    _isReg = reg_name.test(_regName);
                    if(_isReg){
                        ide.util.alert(ide.i18n.repository.noPoint,null,3);
                        return;
                    }

                    //判断file name 是否一致
                    if(_fileName == formBean.name){
                        service.newFile.dialog.close();
                        return ;
                    }



                    service.newFile.dialog && service.newFile.dialog.disableButton(0);
                    ide.util.ajax({
                       type:'post',
                        url:newFileUrl,
                        dataType:'json',
                        contentType:'application/json',
                        data:JSON.stringify(formBean),
                        success:function(data){
                            var node = sourceCode.getSelectedItems();
                            if(node){
                                node[0].name = data.data.json.name;
                            }
                            sourceCode.updateItem(node[0]);
                            main.updateCodeTabById({
                                title:node[0].name
                            },node[0].id);
                            service.newFile.dialog.close();
                        },
                        error:function(data){
                            if(data && data.message){
                                ide.util.alert(data.message,null,2);
                            }else{
                                ide.util.alert(ide.i18n.serverError,null,2);
                            }
                            service.newFile.dialog && service.newFile.dialog.enableButton(0);
                        }
                    });

                }else{

                    formBean.pId = selectedItems[0].isParent == true? selectedItems[0].id : selectedItems[0].pId;
                    formBean.name = J_fileName.val();
                    $('#checkboxList input[type="radio"]:checked').each(function(){
                       formBean.fileType = $(this).attr('id');
                    });
                    if(!formBean.name){
                        ide.util.alert(ide.i18n.repository.fileName,null,3);
                    }else if(!formBean.fileType){
                        ide.util.alert(ide.i18n.repository.fileType,null,3);
                    }else{

                        //前端验证文件名不能以点号开始,以点号结束
                        _regName = J_fileName.val();
                        var reg_name = new RegExp(_regStr,'g');
                        _isReg = reg_name.test(_regName);
                        if(_isReg){
                            ide.util.alert(ide.i18n.repository.noPoint,null,3);
                            return;
                        }

                        newFileUrl = common.config.rootUrl + 'codefiles/createfile';
                        service.newFile.dialog && service.newFile.dialog.disableButton(0);
                        ide.util.ajax({
                            type:'post',
                            url: newFileUrl,
                            dataType: 'json',
                            contentType: 'application/json',
                            data:JSON.stringify(formBean),
                            success:function(data){
                                //var node = sourceCode.getSelectedItem();
                                var _pItem;
                                if(selectedItems[0].isParent){
                                    sourceCode.addItem(selectedItems[0],data.data.json);
                                }else{
                                     _pItem = selectedItems[0].getParentNode();
                                    sourceCode.addItem(_pItem,data.data.json);
                                }

                                var addNode = sourceCode.getItemById(data.data.json.id);

                                //新添加节点在父节点的第一个
                                if(selectedItems[0].isParent){
                                    if(selectedItems[0].children.length>1){
                                        sourceCode.moveItem(selectedItems[0].children[0],addNode[0],'prev');
                                    }
                                }else{
                                    sourceCode.moveItem(_pItem.children[0],addNode[0],'prev');
                                }
                                service.newFile.dialog.close();

                            },
                            error:function(data){
                                if(data && data.message){
                                    ide.util.alert(data.message,null,2);
                                }else{
                                    ide.util.alert(ide.i18n.serverError,null,2);
                                }
                                service.newFile.dialog && service.newFile.dialog.enableButton(0);
                            }
                        });
                    }
                }

            };
        }
    };

    return module;
});