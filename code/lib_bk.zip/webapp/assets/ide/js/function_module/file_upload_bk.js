/**
 * Created by ruizhang on 2014/9/10.
 */
define(['jquery', 'upload'], function ($, upload) {
    var module = {
        init: function () {

            var container = $('#uploadSourceFile');
            var ul = container.find('#J_uploadItem');

            container.on('click', '#drop a', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (ul.find('li').length) {
                    if (ul.find('li').hasClass('error')) {
                        $(this).parent().find('input').click();
                        container.find('#J_uploadItem').empty();
                    } else {
                        return false;
                    }
                } else {
                    $(this).parent().find('input').click();
                }

            })
            // Initialize the jQuery File Upload plugin
            container.find('#upload').fileupload({

                // This element will accept file drag/drop uploading
                dropZone: $('#drop'),
                disabled: false,
                sequentialUploads: true,
                limitConcurrentUploads: 1,
                // This function is called when a file is added to the queue;
                // either via the browse button, or via drag/drop:
                add: function (e, data) {

                    var _fileType = data.originalFiles[0].name.split('.');
                    var _lastStr = _fileType[_fileType.length - 1];
                    if (_lastStr.indexOf('zip') == -1) {
                        ide.util.alert(ide.i18n.repository.uploadFile, null, 3);
                        return false;
                    }
                    if (data.originalFiles.length > 1) {
                        ide.util.alert(ide.i18n.repository.uploadFile, null, 3);
                        return false;
                    }
                    if (container.find('#J_uploadItem li').length > 0) {
                        ide.util.tips(ide.i18n.repository.uploadFile, null, 3);
                        return false;
                    }

                    var tpl = $('<li class="working"><input type="text" value="0" data-width="48" data-height="48"' +
                        ' data-fgColor="#0788a5" data-readOnly="1" data-bgColor="#3e4043" /><p></p><span></span></li>');

                    // Append the file name and file size
                    tpl.find('p').text(data.files[0].name)
                        .append('<i>' + formatFileSize(data.files[0].size) + '</i>');


                    // Add the HTML to the UL element
                    data.context = tpl.appendTo(ul);

                    // Initialize the knob plugin
                    tpl.find('input').knob();

                    // Listen for clicks on the cancel icon
                    tpl.find('span').click(function () {

                        if (tpl.hasClass('working')) {
                            jqXHR.abort();
                        }

                        tpl.fadeOut(function () {
                            tpl.remove();
                        });

                    });

                    // Automatically upload the file once it is added to the queue
                    var jqXHR = data.submit();
                },

                progress: function (e, data) {

                    // Calculate the completion percentage of the upload
                    var progress = parseInt(data.loaded / data.total * 100, 10);

                    // Update the hidden input field and trigger a change
                    // so that the jQuery knob plugin knows to update the dial
                    data.context.find('input').val(progress).change();

                    if (progress == 100) {
                        $('#uploadBox').attr('disabled', true);
                        data.context.removeClass('working');
                    }

                },

                fail: function (e, data) {
                    // Something has gone wrong!
                    $('#uploadBox').removeAttr('disabled');
                    data.context.addClass('error');
                }

            });


            // Prevent the default action when a file is dropped on the window
            $(document).on('drop dragover', function (e) {
                e.preventDefault();
            });

            // Helper function that formats the file sizes
            function formatFileSize(bytes) {
                if (typeof bytes !== 'number') {
                    return '';
                }

                if (bytes >= 1000000000) {
                    return (bytes / 1000000000).toFixed(2) + ' GB';
                }

                if (bytes >= 1000000) {
                    return (bytes / 1000000).toFixed(2) + ' MB';
                }

                return (bytes / 1000).toFixed(2) + ' KB';
            }

            //获取选中的节点数据
            var node = repositoryService.getSelectedItems();

            container.find('#upload').bind('fileuploaddone', function (e, data) {
                var jsonData = $.parseJSON(data.jqXHR.responseText);
                if (jsonData.status == '200') {

                    var sourceCode = repositoryService.getSourceCode();
                    var projectId = jsonData.data.json[0].projectId;

                    if (projectId != null && projectId != "") {
                        var href = parent.common.config.rootUrl + "ide/getProjectOperateStatus/" + projectId;

                        $.ajax({
                            dataType: 'json',
                            url: href,
                            type: 'GET'
                        }).success(function (data) {
                            var root = sourceCode.getItemById(data.id, null);
                            root = $.extend(root[0], data);
                            sourceCode.expand(root);
                            if (root.children && !root.children.length) {
                                repositoryService.getMore(root);
                            }

                            sourceCode.updateItem(root);
                            repositoryService.uploadSourceCode.dialog.close();
                            repositoryService.editProjectTypeMapping(data);
                        })
                    }

                } else {
                    parent.ide.util.alert(jsonData.message, null, 2);

                }
            });

        }
    };

    return module;
});
