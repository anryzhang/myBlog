/**
 * Created by ruizhang on 2014/9/28.
 */
    require.config({        
        //默认情况下模块所在目录为js/lib
        //baseUrl: "../assets/build/js",
        paths: {
            ace: "lib/ace/ace",
            comet4j:'lib/comet4j/comet4j',
            jquery: "jquery.min",
            editor:  "lib/ide/editor/editor",
            template:  "lib/arttemplate/template",
            upload:  "lib/mini-upload-form/jquery.fileupload",
            uiwidget:  "lib/mini-upload-form/jquery.ui.widget",
            knob:  "lib/mini-upload-form/jquery.knob",
            fileUpload:  'function_module/file_upload',
            treetable:  'lib/jquery-treetable/jquery.treetable',
            privilege:  'module/privilege',
            cg:  'lib/cg/cg.min',
            editorSuggest:  "lib/ide/editor/suggest",
            underscore: 'lib/underscore/underscore',
            bootstrap: 'bootstrap',
            jqueryValidationEngineEn:  'lib/jquery-validation-engine/jquery.validationEngine-en',
            jqueryValidationEngine:  'lib/jquery-validation-engine/jquery.validationEngine',
            //code
            code:  'module/codeservice',
            codeCommon:  "lib/ide/code/common",
            outline:  "lib/ide/code/outline",
            deadcode:  "lib/ide/code/deadcode",
            clonecode:  "lib/ide/code/clonecode",
            translatedcode:  "lib/ide/code/translatedcode",
            transformedcode:  "lib/ide/code/transformedcode",
            codeSourcecode:  "lib/ide/code/sourcecode",
            jobflow:  "lib/ide/code/jobflow",
            controlflow:  "lib/ide/code/controlflow",
            reference:  "lib/ide/code/reference",
            callerandcallee:  "lib/ide/code/callerandcallee",
            opc:  "lib/ide/code/opc",

            //module
            /*moduleEditor:  "module/editor",
             moduleEditorService:  "module/editorservice",*/

            editProjectTypeMapping:  'function_module/editProjectTypeMapping',
            runAnalysisSchedule:  'function_module/runAnalysisSchedule',
            runCheckstyleSchedule:  'function_module/runCheckstyleSchedule',
            runTranslationSchedule:  'function_module/runTranslationSchedule',
            runTransformationImmediately:  'function_module/runTransformationImmediately',
            datetimepicker:  'lib/datetimepicker/bootstrap-datetimepicker.min',

            ide: 'lib/ide/ide',
            main:  'module/main',
            menu:  'module/menu',
            //repositoryservice 的依赖
            repositoryService:  'module/repositoryservice',
            sourcecode:  'lib/ide/repository/sourcecode',

            moduleCommon:  'module/common',
            util:  'lib/ide/util/util',
            console:  'lib/ide/util/console',
            datatable:  'lib/ide/util/datatable',
            popup:  'lib/ide/util/popup',
            progress:  'lib/ide/util/progress',
            schedule:  'lib/ide/util/schedule',
            history:'lib/ide/util/history',

            repository:  'module/repository',
            repositoryCommon:  'lib/ide/repository/common',
            ztreeCore: 'lib/ztree/jquery.ztree.core',
            ztreeExedit:  'lib/ztree/jquery.ztree.exedit',
            newProject:  'function_module/newProject',
            editProject:  'function_module/editProject',
            cronGentleSelect:  'lib/cron/jquery-gentleSelect',
            cron:  'lib/cron/jquery-cron',
            teamCommit:  'function_module/teamCommit',
            teamRevert:  'function_module/teamRevert',
            teamShowHistory:  'function_module/teamShowHistory',
            shareProject:  'function_module/shareProject',
            newFile: 'function_module/newFile',
            newFolder: 'function_module/newFolder',
            updateFileType:  'function_module/updateFileType',
            searchFile:  'function_module/searchFile',
            selectFile:  'function_module/selectFile',
            menuSchedule:  'function_module/schedule',

            /*analysisOptions.jsp*/
            analysisOptions:  'function_module/analysisOptions'
        }/*,
        shim: {
            upload: {
                deps: ["jquery", "uiwidget", "knob"],
                exports: "upload"
            },
            ztreeCore:{
                deps:['jquery'],
                exports:'ztreeCore'
            },
            ztreeExedit:{
                deps:['jquery',"ztreeCore"],
                exports:'ztreeExedit'
            },
            underscore:{
                exports:'_'
            },
            cg:{
                deps:['jquery'],
                exports:'cg'
            },
            bootstrap:{
                deps:['jquery'],
                exports:'bootstrap'
            },
            jqueryValidationEngineEn:{
                deps:['jquery'],
                exports:'jqueryValidationEngineEn'
            },
            jqueryValidationEngine:{
                deps:['jquery','jqueryValidationEngineEn'],
                exports:'validationEngineLanguage'
            },
            jqueryValidationEngineEn:{
                deps:['jquery'],
                exports:'jqueryValidationEngineEn'
            },
            cron:{
                deps:['jquery','cronGentleSelect'],
                exports:'cron'
            }
        }*/
    });

require(['jquery','moduleCommon','template','main','ztreeExedit','bootstrap','jqueryValidationEngine'], function ($,common,template,main) {
   window.template = template;
    //初始化main.init();
    main.init({
    });
    require(['history'],function(){});
});
