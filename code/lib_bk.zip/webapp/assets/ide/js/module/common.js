/*
* 公用
* */

define(['jquery'],function($){

    var common = {};

    var selectors={};

    //配置
    common.config={
        rootUrl:"",//ide根地址
        selectors:{
            repositoryContextMenu: "#ide-repository-contextmenu",
            codeTabContextMenu:"#ide-tab-contextmenu",
            dropdownMenu:".ide-container .dropdown-menu",
            dropdownMenuGroup:".btn-group",
            menu:".ide-menu-item",
            searchContent:"#search",
            uploadContextMenu:"#upload-contextMenu"

        }
    };

    common.i18n={};

    //全局缓存数据
    common.cache={};

    //获取主窗口
    common.getMainWindow=function(){
        return window.top;
    };
    //获取主窗口的大小
    common.getMainWindowSize=function(){

    };
    common.getMainWindowHeight=function(){
        var win=common.getMainWindow();
        
        return $(win).height();
    };



    //获取contextmenu 的高度
    common.getContextMenuHeight=function(contextMenu){
        var height;
        contextMenu.show();
        height=contextMenu.find(".dropdown-menu").outerHeight(true);
        contextMenu.hide();
        return height;
    }
    //根据contextmenu 高度和top属性计算top
    common.getContextMenuTop=function(top,contextMenuHeight,windowHeight){
        var _t=top+contextMenuHeight;
        if(_t>windowHeight){
            return windowHeight-contextMenuHeight;
        }
        return top;
    }


    /*var contextMenu=$(common.config.selectors.repositoryContextMenu),
        codeTabContextMenu=$(common.config.selectors.codeTabContextMenu),
        dropdownMenu=$(common.config.selectors.dropdownMenu),
        dropdownMenuGroup=$(common.config.selectors.dropdownMenuGroup);*/

    function hideContextMenu(){
        var _event="mouseup";
        //时间不够，先不深挖此bug
        //问题出在 safari 并没有阻止事件冒泡
        if($.browser.safari){
            _event="click";
        }
        $(document).on(_event,function(e){
            //contextMenu.hide();
            //codeTabContextMenu.hide();
            //屏蔽掉单击在父菜单上
            //console.log(e);
            var _a=e&&$(e.target);
            if(_a&&_a.is("a")&&_a.next(".dropdown-menu").length){
                return ;
            }
            $(".ide-contextmenu").hide();
            
            /*if(!$(e.target).closest(common.config.selectors.dropdownMenuGrou).length){
                //dropdownMenuGroup.removeClass("open");
            }*/
        });
    }
    hideContextMenu();

    //全局localstorage
    //目前采用浏览器默认是指的localstorage

    common.localStorage={};

    common.localStorage.getItem=function(name){
        return window.top.localStorage&&window.top.localStorage.getItem.apply(window.top.localStorage,arguments);
    }
    common.localStorage.setItem=function(name){
        window.top.localStorage&&window.top.localStorage.setItem.apply(window.top.localStorage,arguments);
    }

    $.extend(true,common,IDECONFIG);

    return window.common = common;
});
