var repositoryForUpload = (function(repositoryForUpload,common,ide, $) {
	"use strict";
	var contextMenu;
$(function(){
 contextMenu=jQuery(common.config.selectors.uploadContextMenu);
});
	
	//console.log(contextMenu,common.config.selectors.uploadContextMenu);

	repositoryForUpload.getContextMenu =function(){
		return jQuery(common.config.selectors.uploadContextMenu);
	}

	repositoryForUpload.hideContextMenu = function() {
		contextMenu.hide();
	}
	//显示contextmenu
	repositoryForUpload.showContextMenu = function() {
		contextMenu.show();
	}

	/*contextMenu module */
	//设置右键菜单position
	repositoryForUpload.setContextMenuPosition=function(left, top) {
		contextMenu.css({
			top: top,
			left: left
		});
	}

	function hideContextMenu(){
		$(document).click(function(e){
			contextMenu.hide();
		});
	}
	hideContextMenu();
	return repositoryForUpload;
})(repositoryForUpload || {},common, ide,jQuery);