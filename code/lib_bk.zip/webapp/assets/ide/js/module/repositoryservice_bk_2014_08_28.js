/**
 * Created by ruizhang on 2014/8/8.
 * repositoryService 树功能对外的公用接口
 */

var repositoryService = (function (repositoryService, ide, repository, $, common) {

    var repositoryWindow,
        sourceCodeCache=[],        
        sourceCode,
        options,
        optionsCache=[],
        pageNo = 0,
        pageSize = 50,
        mainWindow = common.getMainWindow(),
        contextMenu = mainWindow.jQuery(common.config.selectors.repositoryContextMenu),
        main = mainWindow.main;


    //注册右键菜单事件
    function _initContextMenu(){
        repository.getContextMenu().on('click','[data-service]',function(){
            var $_this = $(this),
                service = $_this.attr('data-service');
            repositoryService[service].call(repositoryService, repository.getContextMenu().data('data'));
        });
    }
    //搜索菜单初始化
    function _initSearch(){
        var codeSearchBtn = repository.getUI().codeSearch;
        codeSearchBtn.on('click','[data-service]',function(){
            var $_this = $(this),
                service = $_this.attr('data-service');
            repositoryService[service].call(this);
        });
    }
    //隐藏隐藏菜单
    function _hideContextMenu(){
        for(var i = 0; i < arguments.length; i++){
            var content = arguments[i];
            for(var j = 0; j < content.length; j++){
                if($(content).eq(j).find('.hide').length == 0){
                    if($(content).find('.show')){
                        $(content[j]).removeClass('show').addClass('hide');
                    }else{
                        $(content[j]).addClass('hide');
                    }
                }
            }
        }
    }
    //显示右键菜单
    function _showContextMenuItems(){
        for(var i = 0; i < arguments.length; i++){
            common.getRepositoryWindow().repository.getContextMenu()
                .find(arguments[i])
                .parent()
                .removeClass('hide')
                .addClass('show');

        }
    }
    //有版本控制参数的文件夹菜单显示Team
    function _isRevertFolderShowTeam(data,selector,len){
        if(len > 1){
            // isRevert === true 显示team
            if(data.operateMap && data.operateMap.isRevert === true){
                _showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.del,
                    selector.copy,
                    selector.paste
                );
            }else{
                _showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.commit,
                    selector.del,
                    selector.copy,
                    selector.paste
                );
            }

        }else{
            if(data.operateMap && data.operateMap.isRevert === true){
                _showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                );
            }else{
                _showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.commit,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                );
            }
        }
    }
    //有版本控制参数的文件菜单显示Team
    function _isRevertFileShowTeam(data,selector,len){
        if(len > 1){
            if(data.operateMap && data.operateMap.isRevert === true){
                _showContextMenuItems(
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.paste
                    //selector.download
                );
            }else{
                _showContextMenuItems(
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.commit,
                    selector.paste
                    //selector.download
                );
            }
        }else{
            /*if(data.operateMap && data.operateMap.isRevert === true){
             showContextMenuItems(
             selector.runTest,
             selector.eidt,
             selector.del,
             selector.copy,
             //selector.team,
             selector.update,
             selector.commit,
             selector.revert,
             selector.showHistory,
             selector.paste
             //selector.download
             );
             }else */
            if(data.operateMap && data.fileType === "RULE"){

                _showContextMenuItems(
                    selector.runTest,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                )
            }else{
                _showContextMenuItems(
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.commit,
                    selector.paste
                    //selector.download
                );
            }
        }
    }
    //remove hide class into reightClass menu
    function _removeHideContextMenuItems(){
        for(var i=0; i< arguments.length; i++){
            repository.getContextMenu()
                .find(arguments[i])
                .parent()
                .removeClass('hide')
        }

    }
    //扩展右键菜单
    function _extendOptions(options){
        //右键菜单默认top
        var contextMenuTop = 123;
        var selector = repository.getSelectors();
        console.log(selector);
        //右键或点击树节点,设置主菜单项
        options.beforeRightClick = options.beforeClick = function(data){

            console.log(data);
            sourceCode.selectItem(data,false)
            if(!data.isSharedProjectForCurrentUser && data.operateMap){
                if(data.operateMap.MainframeProject){
                    menu.disableMenus(privilege.analysis);
                    if(!data.operateMap.SourceCodeComplete){
                        $(selector.fileTypeMapping).hide();
                        menu.disableMenus(["editProjectTypeMapping"].concat(privilege.checkstyle,'runDuplicationAnalysis'));
                    }else{
                        $(selector.fileTypeMapping).show();
                        menu.enableMenus(["editProjectTypeMapping"].concat(privilege.checkstyle,privilege.analysis,'runDuplicationAnalysis'));
                    }
                }else{
                    //非ftp时
                    //1.没有上传代码  不能做分析
                    //2.有上传代码  可以做分析
                    if(data.operateMap.SourceCodeComplete){
                        // 有上传代码时:
                        menu.enableMenus(['runAnalysis','runDuplicationAnalysis','runAnalysisSchedule'].concat(privilege.checkstyle));
                    }else{
                        $(selector.fileTypeMapping).show();
                        menu.disableMenus(['runAnalysis','runDuplicationAnalysis','runAnalysisSchedule'].concat(privilege.analysis,privilege.checkstyle));
                    }

                }
            }
        };


        options.rightClick = function(e,data){
            var height = common.getMainWindowHeight();
            repository.getContextMenu().data("data",data);
            var allNodes,
                allNodesId = [],
                nodesLen = repositoryService.getSelectedItems().length;

            //缓存选中的items id 用来做tree 是否可以多选
            if(nodesLen < 1){
                allNodes = data;
                allNodesId.push(allNodes.id);
            }else{
                allNodes = repositoryService.getSelectedItems();
                for(var i = 0; i < allNodes.length; i++){
                    allNodesId.push(allNodes[i].id);
                }
            }

            //右键是否能选中多个节点
            if(allNodesId.indexOf(data.id) > -1){
                //true 可多选
                sourceCode.selectItem(data,false);
            }else{
                sourceCode.selectItem(data,false)
            }

            //右键菜单类目显示
            //如果node 是 root 节点
            if(data.id === data.projectId){
                //如果是新建的项目时
                if(data.operateMap && data.operateMap.NewProject){
                    var content = repository.getContextMenu().find('li');
                    _hideContextMenu(content);
                    if(!data.isSharedProjectForCurrentUser){
                        _showContextMenuItems(
                            selector.share);

                    }else{
                        _hideContextMenu(content);

                        //menu.disableMenus(privilege.isSharedProjectForCurrentUser);
                        return false;
                    }
                    if(data.operateMap.NewProject||data.operateMap.CheckoutProject || data.operateMap.UploadProject || data.operateMap.MainframeProject ){

                        if(data.operateMap.MainframeProject){
                            _showContextMenuItems(
                                selector.editProject,
                                selector.bre,
                                //selector.upload,
                                selector.translation,
                                selector.transformation,
                                //selector.analysis,
                                selector.delProject
                            );
                            //成功后,filetypeMapping 不显示 ,主菜单禁用
                            $(selector.fileTypeMapping).hide();
                            menu.disableMenus(["editProjectTypeMapping"]);
                            //ftpDownLoadComplete 为true时,可以做bre, 否则不可以做bre
                            $(selector.bre).hide();
                            if(data.operateMap.SourceCodeComplete){
                                $(selector.bre).show();
                                menu.enableMenus([].concat(['runDuplicationAnalysis']));
                            }else{
                                menu.disableMenus([].concat(['runDuplicationAnalysis']));
                            }

                        }else{
                            //$(selector.fileTypeMapping).show();
                            if(data.operateMap.SourceCodeComplete){
                                _showContextMenuItems(
                                    selector.editProject,
                                    selector.bre,
                                    selector.upload,
                                    selector.translation,
                                    selector.transformation,
                                    selector.analysis,
                                    selector.delProject
                                );
                            }else{
                                _showContextMenuItems(
                                    selector.editProject,
                                    //selector.bre,
                                    selector.upload,
                                    //selector.translation,
                                    //selector.transformation,
                                    //selector.analysis,
                                    selector.delProject
                                );
                            }


                        }



                        _removeHideContextMenuItems(
                            selector.breConfig,
                            selector.runBreI,
                            selector.runBreS,
                            selector.runDuplicationAnalysis,
                            selector.TLConfig,
                            selector.runTLI,
                            selector.runTLS,
                            selector.TFConfig,
                            selector.runTFI,
                            selector.runTFS,
                            selector.runANAI,
                            selector.runANAS,
                            selector.editProjectBasicInfo,
                            selector.fileTypeMapping
                        );



                    }else{

                        _showContextMenuItems(
                            selector.upload,
                            selector.delProject,
                            selector.editProject
                        );
                        _removeHideContextMenuItems(
                            selector.editProjectBasicInfo,
                            selector.fileTypeMapping
                        );
                    }
                    //transformation 初始化一次
                    //data.operateMap.transformation = true;
                    var isInit = data.operateMap.transformation;
                    var arr = [];
                    arr[0] = contextMenu.find(selector.initTransformation).closest('li').attr('data-service');
                    if(isInit){
                        repository.enableMenus([].concat(arr));
                    }else{
                        repository.disableMenus([].concat(arr));
                    }


                }

                sourceCode.selectItem(data,false);

            }else{
                // 不是root 节点
                //是文件夹时
                if(data.isSharedProjectForCurrentUser){
                    //menu.disableMenus(privilege.isSharedProjectForCurrentUser);
                    return false;
                }
                if(data.isParent){
                    var content = repository.getContextMenu().find('li');
                    _hideContextMenu(content);

                    //tree json 数据要增加 operateMap.isRevert 字段来判断节点是否已经加入过版本库 true 已经加放, false 未加入
                    var _data = {
                        operateMap:{
                            isRevert:true
                        }
                    }
                    //扩展节点json
                    $.extend(data,_data);
                    //如果是root的子节点文件夹不能手动删除
                    if(data.pId == data.projectId){
                        _showContextMenuItems(
                            selector.addFile,
                            selector.addFolder,
                            selector.copy,
                            selector.paste
                        );
                    }else{
                        //还原文件夹 显示team
                        _isRevertFolderShowTeam(data,selector,allNodesId.length);
                    }

                }else{
                    //right click is file
                    var content = repository.getContextMenu().find('li');
                    _hideContextMenu(content);

                    //tree json 数据要增加 operateMap.isRevert 字段来判断节点是否已经加入过版本库 true 已经加放, false 未加入
                    //每个节点要新加isRule来判断是否有run test 功能
                    var _data = {
                        operateMap:{
                            isRevert:true,
                            isRule: data.fileType === "RULE"?true:false
                        }
                    };
                    $.extend(data,_data);
                    //console.log(data);
                    _isRevertFileShowTeam(data,selector,allNodesId.length);
                }

            }

            //显示菜单位置
            var contextMenuHeight = common.getContextMenuHeight(repository.getContextMenu()) + 50;
            repository.setContextMenuPosition(e.pageX+10, common.getContextMenuTop(e.pageY+10 , contextMenuHeight, height));
            repository.showContextMenu();
            return false;

        };

        //双击
        options.DBclick = function(e,data){
            repository.getContextMenu().data('data', data);
            if(data && data.role > 99){
                repositoryService.getMore(data);
            }else{
                if(data && !data.isParent){
                    _openItem(data);
                }
            }
        }

    }
    //打开选择的节点
    function _openItem(data,params){
        if(typeof data != 'undefined'){
            var OpenItemURL = common.config.codeUrl;
            OpenItemURL += "/?codeFileId=" + data.id;
            OpenItemURL += "&structureType=" + data.structureType;
            OpenItemURL += "&fileType=" + data.fileType;
            OpenItemURL += "&projectId=" + data.projectId;
            OpenItemURL += "&parentId=" + data.pId;


            if(data.isSharedProjectForCurrentUser){
                if(!data.isCreateByAdmin){
                    OpenItemURL += "&readOnly=" +1;
                }else{
                    OpenItemURL += "&readOnly=" +0;
                }
            }


            if(!data.isParent){
                //文件时
                if(params){
                    for(var key in params){
                        OpenItemURL += "&" + key + "=" + params[key];
                    }
                }
                if(data.target == '_tab'){
                    OpenItemURL = common.config.rootUrl + data.path;
                }
                var fileTitle;
                if(data.isSharedProjectForCurrentUser){
                    fileTitle = data.name + ' [S]';
                }else{
                    fileTitle = data.name;
                }
                var opt = {
                    id: data.id,
                    href: OpenItemURL,
                    pId: data.pId,
                    projectId: data.projectId,
                    title: fileTitle,
                    domTitle:data.filePath,
                    readOnly:data.isSharedProjectForCurrentUser&&!data.isCreateByAdmin?true:false
                }

                main.addCodeTab(opt);
            }
        }else{
            ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
        }
    }

    //得到节点的父节点
    function _getNodesByParentNode(treeNode,inputPageNo, inputPageSize, callback){
        var postData = {
            userId: treeNode.userId,
            projectId: treeNode.projectId,
            pageSize: inputPageSize,
            pageNo: inputPageNo,
            nodeId: treeNode.moreId || treeNode.id
        };

        var href = common.config.rootUrl + 'loadNodesByParentId';
        $.ajax({
            type:'POST',
            url:href,
            contentType: 'application/json',
            dataType:'json',
            data: JSON.stringify(postData)
        }).done(function(rs){
            callback && callback.call(this,rs);
        });

    }

    //请求 nodes
    function _ajaxGetNodes(treeNode, inputPageNo, inputPageSize){
        _getNodesByParentNode(treeNode,inputPageNo,inputPageSize,function(nodes){
            if(nodes.nodes){
                if(nodes.pageNo + 1 < nodes.totalPageSize){
                    var clickMore = {
                        "name":"more...",
                        "id": nodes.nodes[0].id + 123,
                        "pageNo":nodes.pageNo + 1,
                        "pageSize": nodes.pageSize,
                        "userId": nodes.nodes[0].userId,
                        "projectId": nodes.nodes[0].projectId,
                        "role": 200,
                        "moreId":nodes.nodes[0].pId,
                        "icon":ide.config.icon.more
                    };
                    nodes.nodes.push(clickMore);
                }

                if(treeNode.role){
                    sourceCode.addItem(treeNode.getParentNode(), nodes.nodes);
                    sourceCode.deleteItem(treeNode);
                }else{
                    sourceCode.addItem(treeNode, nodes.nodes, false);
                }

            }

        });
    }

    function _getRootNode(node) {
        //返回根节点
        var root = false;
        if (!node) {
            node = sourceCode.getSelectedItems()[0];
        }
        if (node) {
            while (!node.operateMap) {
                node = node.getParentNode();
            }
            root = node;
        }
        return root;
    }

    function _getRootNodes(nodes){
        //返回根节点列表
        var roots = [];
        if(nodes){
            for(var i = 0; i <  root.length; i++){
                var root = _getRootNode(nodes[i]);
                roots.push(root)
            }
        }else{
            return false
        }
        return roots;
    }

    function _getFolderByParentNode(node) {
        // 获取文件的父节点id
        var foldersId = [];
        if (node.children && node.children.length > 0) {
            foldersId.push(node.id);
            for(var i =0;i<node.children.length; i++){
                if(node.children[i].isParent){
                    //console.log(foldersId);
                    foldersId=foldersId.concat(_getFolderByParentNode(node.children[i]));
                    //console.log(foldersId);
                }
            }
            return foldersId;
        }

    }

    function _deleteNode(node,flag){
        // flag : 是否删除树上节点。
        // flag true 删除树上节点
        // flag false 不删除树上节点。
        // node is a project node
        // ndoe.operateMap无法判断是项目文件夹
        // node.id===node.projectId

        if(node && node.id == node.projectId){
            var href = common.config.rootUrl + 'ide/delete_project?projectId=' + node.projectId;
            $.ajax({
                dataType:'text',
                url:href,
                type:'POST',
                success:function(rs){
                    var rsd = {
                        responseText: rs
                    }
                    if(rsd.responseText == 'success'){
                        if(flag){
                            sourceCode.deleteItem(node);
                        }
                        //删除项目打开的文件
                        main && main.closeCodeTabsByParams({
                            projectId: node.projectId
                        },true)
                    }else{
                        ide.util.alert(ide.i18n.repository.delProjectFailed, null, 2);
                    }
                }
            });
            return ;
        }

        //node is a folder
        if(node && node.isParent){
            ide.util.ajax({
                url:common.config.rootUrl + 'codefiles/deleteCodefiles/' + node.id,
                type:'GET',
                success:function(rs){
                    if(flag){
                        sourceCode.deleteItem(node);
                    }
                    var folderIds = _getFolderByParentNode(node);
                    for(var i = 0; i< folderIds.length; i++){
                        main && main.closeCodeTabsByParams({
                            pId: folderIds[i]
                        },true);
                    }
                }
            });
            return ;
        }

        // node is a file
        if(node){
            ide.util.ajax({
                url: common.config.rootUrl + 'codefiles/deleteCodefiles/' + node.id,
                type:'GET',
                success: function(rs){
                    if(flag){
                        sourceCode.deleteItem(node);
                    }
                    main && main.closeCodeTabById(node.id, true);
                }
            });
            return ;
        }

    }

    function _deleteNodeById (id){
        var node = sourceCode.getItemById(id)[0];
        //debugger;
        if(node){
            //if the repository tree  contain this node
            _deleteNode(node,true);
        }
        else{
            //if the repository tree not contain this node find it from database
            var flag = false;
            var href = common.config.rootUrl + "ide/findFileById/" + id;
            $.ajax({
                dataType: 'json',
                url: href,
                type: 'GET',
                success: function(rs) {
                    if (rs != "") {
                        _deleteNode(rs, false);
                        e.data.dialog.close();
                    } else {
                        ide.util.alert(ide.i18n.repository.deleteFileNo, null, 2);
                    }
                }
            });

        }

    }
    //点击节点,发送是否打开节点,true ,false
    function _updateNodeOpenStatus(treeNode){
        var postData={}
        postData.isOpen = (treeNode.open === true ? false : true);
        postData.projectId =treeNode.projectId;
        postData.id=treeNode.id;
        var href = common.config.rootUrl + 'loadNodesByParentId';
        $.ajax({
            dataType: 'json',
            url: href,
            contentType: 'application/json',
            type: 'POST',
            data: JSON.stringify(postData)
        }).done(function(data, textStatus, jqXHR) {
            //callback && callback.call(this, data);
            if(!data.status ==  200){
                ide.util.alert(data.msg,null,3);
            }
        });
    }

    repositoryService = {
        /*
         * 初始化项目
         * element jquery Dom 节点
         * arg ztree 参数
         * */
        init:function(element, arg, flag){
            var self = this;
            options = arg;
            if(!repository.getContextMenu().data('initialize')){
                _initContextMenu(options.type);
                //_initSearch();此方法好像没有用
                repository.getContextMenu().data('initialize',true);
            }
            _extendOptions(options);

            //如果 flag != true get all projects
            //如果 flag == true add a new projects into empty tree
            if(!flag){
                var href = common.config.rootUrl + "loadProjectFileStructure";
                if(options.userId){
                    href+="/"+options.userId;
                }
                $.ajax({
                    type:'GET',
                    url: href,
                    dataType: 'json'
                }).done(function(rs,textStatus,jqXHR){

                    //判断是否被share 操作
                    for(var i = 0; i < rs.length; i++){
                        if(rs[i].operateMap && rs[i].operateMap.ShareToUser === true){
                            rs[i].name += ' [S]';
                        }
                    }
                    options.nodes = rs;
                    sourceCode = new ide.repository.SourceCode(element,options);
                    //repositoryService.beforeUnload();
                    self.beforeUnload();
                });
            }

            //储存当前操作的窗口
            $(document).on('focusin',function(){
                common.getMainWindow().main.setFocusWindow(window);
            });
            //返回tree sourceCode 全局
            sourceCode = new ide.repository.SourceCode(element,options);

            var _userId=element.attr("data-user");
            sourceCodeCache[_userId]=sourceCode;
            optionsCache[_userId]=options;
        },
        changeRepository:function(id){
            sourceCode=sourceCodeCache[id];
            options=optionsCache[id];
        },
        beforeUnload:function(){
            //页面重载前事件,获取打开的节点状态
            var self = this;
            self.getNodeOpenStatus();
        },
        getNodeOpenStatus:function(){
            //获取已经打开的树的节点状态
            var self = this;
            var node = sourceCode.tree.getNodes(),
                nodes = sourceCode.getOpenItemsByFilter(function(node){
                    return node.open === true;
                });
            var openNodes = [];
            for(var i = 0; i < nodes.length; i++){
                var openId = {
                    id: nodes[i].id
                }
                openNodes.push(openId);
            }
            return openNodes;
        },
        getSourceCode:function(){
            //return sourceCode for other service
            if(typeof sourceCode == 'undefined'){
                return null;
            }else{
                return sourceCode;
            }

        },
        getSelectedItems:function(){
            //获取选中的节点的数据,返回一个JSON对象
            return sourceCode.getSelectedItems();
        },
        getMore:function(node){
            //动态加载节点
            _ajaxGetNodes(node, node.pageNo, node.pageSize, node.userId, node.projectId);
        },
        openItem:function(item, params){
            //打开树节点
            //params 双击时,触发 url 参数
            if(item && item.length > 0){
                _openItem(item,params);
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
            }
        },
        openItems:function(item,params){
            // 打开树节点
            // item 为数组
            // params 双击时候 触发的URL 参数
            var self = this;
            if(item && item.length >0){
                for(var i = 0; i< item.length; i++){
                    _openItem(item[i],params);
                }
            }else{
                var items = self.getSelectedFiles();
                if(items.length > 0){
                    for(var i = 0; i < items.length; i++){
                        _openItem(items[i],params);
                    }
                }else{
                    ide.util.alert(ide.i18n.repository.needSelectFile,null,3);
                }
            }
        },
        openItemById:function(id, params){
            //通过 id 获取节点,打开树节点
            var self = this;
            if(typeof id != 'undefined'){
                var node = sourceCode.getItemById(id);
                if(node.length > 0){
                    _openItem(node[0],params);
                }else{
                    var flag = false;
                    var href = common.config.rootUrl + "ide/findFileById/" + id;
                    $.ajax({
                        type:'Get',
                        url:href,
                        dataType:'json',
                        success:function(rs){
                            if(rs){
                                _openItem(rs,params);
                            }else{
                                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
                            }
                        }

                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null,3);
            }
        },
        getSelectedFiles:function(){
            // 获取选中的文件
            var self = this;
            var tree = self.getSourceCode(),
                files = tree.getSelectedItems();
            return _.filter(files,function(data,index){
                return !data.isParent;
            })
        },
        getSelectedFileIds:function(){
            //返回选中文件的Id
            var self = this;
            var files = self.getSelectedFiles(),
                ids = [];
            for(var i = 0; i < files.length; i++){
                ids.push(files[i].id);
            }
            return ids;
        },
        getSelectedFolders:function(){
            //返回选中的文件夹
            var self = this;
            var tree = self.getSourceCode(),
                files = tree.getSelectedItems();
            return _.filter(files,function(data,index){
                return data.isParent;
            });
        },
        getSelectedFolderIds:function(){
            //返回选中文件夹的 id
            var self = this;
            var folders = self.getSelectedFolders(),
                ids = [];
            for(var i = 0; i < folders.length; i++){
                ids.push(folders[i].id);
            }
            return ids;
        },
        getAllItems:function(){
            //返回树中的所有项目
            var self = this;
            return sourceCode.getAllItems();
        },
        beforeExpand:function(treeId, treeNode){
            //扩展节点打开前事件
            if(!treeNode.isExpanded){
                _ajaxGetNodes(treeNode, pageNo,pageSize);
                treeNode.isExpanded = true;
                sourceCode.updateItem(treeNode);
            }
            return true;

        },
        beforeCollapse:function(treeId, treeNode){
            //节点关闭前事件
            var self = this;
            if(treeNode.isExpanded){
                treeNode.isExpanded = false;
                sourceCode.updateItem(treeNode);
            }
        },
        onAsyncSuccess:function(event, treeId, treeNode, msg){
            // 异步加载成功后，弹出提示信息
            _ajaxGetNodes(treeNode, pageNo,pageSize);
            ide.util.alert(msg, null, 3);
            return true;

        },
        onAsyncError:function(){

        },
        addProject:function(node){
            // add a project;
            var self = this;
            var tree = self.getSourceCode(),
                _reopsitory = common.getRepositoryWindow().repository;
            if(!sourceCode){
                self.init(_reopsitory.getUI().treeId,{
                    nodes: node.nodes,
                    setting:{
                        view: {
                            fontCss: self.getFontCss(),
                            nameIsHTML: true
                        },
                        callback:{
                            beforeExpand: self.beforeExpand,
                            onAsyncSuccess: self.onAsyncSuccess,
                            onAsyncError: self.onAsyncError
                        }
                    },
                    type:1

                },true);
            }else{
                repository.addFolder(null, node.nodes[0], sourceCode);
                var nodes = sourceCode.getAllItems();
                sourceCode.moveItem(nodes[0], nodes[nodes.length-1],'prev');
                //新建project 时,选中project 节点
                tree.selectItem(tree.getItemsByParam('id',node.nodes[0].id,null)[0],false);
            }
        },
        updateProject:function(node){
            // update project
            var self = this;
            if(typeof node != 'undefined'){
                var selector = sourceCode.getSelectedItems();
                var nodes = _getRootNode(selector[0]);
                if(!node){
                    ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                    return false;
                }
                //判断是否被share 出去
                if(nodes.operateMap && nodes.operateMap.ShareToUser === true){
                    nodes.name = node.nodes[0].name + ' [S]';
                }else{
                    nodes.name = node.nodes[0].name;
                }
                sourceCode.updateItem(nodes);
            }
        },
        newProject:function(){
            // new project
            var self = this;
            var dialog = self.newProject.dialog = common.getMainWindow().ide.util.dialog({
                title: 'New Project',
                href: common.config.rootUrl + "page/main_newProject.html",
                iframe:false,
                width:860,
                height:620,
                modal:true,
                buttons:[{
                    text:'Save',
                    handler: function(e){
                        if(self.newProject.submit){
                            self.newProject.submit();
                        }
                    }
                },{
                    text: ide.i18n.dialogCancelButtonText,
                    handler:function(e){
                        e.data.dialog.close();
                    }
                }],
                success:function(){
                    self.newProject.initProject();
                }
            });
        },
        editProject:function(){
            //edit project
            var self = this;
            var item  = sourceCode.getSelectedItem(),
                projectId;
            if(item && item.length){
                projectId = item[0].projectId;
                if(projectId){
                    var dialog = self.editProject.dialog = common.getMainWindow().ide.util.dialog({
                        title:'Edit Project',
                        href: common.config.rootUrl + 'page/edit_Project.html',
                        iframe: false,
                        width: 860,
                        height: 620,
                        modal:true,
                        buttons:[{
                            text:'Save',
                            handler:function(e){
                                if(self.editProject.submit){
                                    self.editProject.submit();
                                }
                            }
                        },{
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            self.editProject.initProject();
                        }
                    });
                }

            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject,null, 3);
            }

        },
        uploadSourceCode:function(node){
            //upload source code
            var self = this;
            var id;
            if(typeof node === 'string'){
                id = node;
            }else{
                node = _getRootNode(node);
                if(!node){
                    ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                }
                id = node.projectId;
            }
            if(!id){
                return ;
            }
            var dialog = self.uploadSourceCode.dialog = common.getMainWindow().ide.util.dialog({
                title:'Upload',
                href:common.config.rootUrl + 'ide/projects/upload/' + id,
                width:680,
                height: 500,
                modal:true
            });
        },
        updateProjectStatus:function(projectId){
            //update project status
            var self = this;
            if(projectId){
                var href = common.config.rootUrl + 'ide/getProgetcOperateStatus/' + projectId;
                $.ajax({
                    type:'GET',
                    url:href,
                    dataType:'json',
                    success:function(rs){
                        var root = sourceCode.getItemById(rs.id, null);
                        root = $.extend(root[0], rs);
                        sourceCode.updateItem(root);
                    }
                });
            }
        },
        editProjectTypeMapping:function(node){
            //edit file type mapping
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if(node && node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject)){
                var dialog = self.editProjectTypeMapping.dialog = common.getMainWindow().ide.util.dialog({
                    title: 'File Type Mapping',
                    iframe:true,
                    href:common.config.rootUrl + 'ide/fileTypeMapping/' + node.projectId + '/' + node.id,
                    width:500,
                    height: 400,
                    modal:true,
                    closable: true,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler: function(){
                            var win = dialog.getIframeWindow();
                            if(win && win.jQuery){
                                self.editProjectTypeMapping.submit();
                            }
                        }
                    },{
                        text: ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }]
                });
            }else{
                ide.util.alert(ide.i18n.repository.needUploadorCheckout,null,3);
            }

        },
        checkout:function(node){
            // checkout code
            var self = this;
            if(!node){
                ide.util.alert(ide.i18n.needSelectProject,null,2);
                return false;
            }
            var href = common.config.rootUrl + 'checkOutProject/' + node.projectId;
            $.ajax({
                type:'GET',
                dataType:'json',
                url:href,
                success:function(rs){
                    if(rs.status != 200){
                        ide.util.alert(rs.message,null,2);
                    }else{
                        self.updateProjectStatus(node.projectId);
                        //edit file type mapping
                        var dialog = self.editProjectTypeMapping.dialog = common.getMainWindow().ide.util.dialog({
                            title:'File Type Mapping',
                            iframe: true,
                            href: common.config.rootUrl + 'ide/fileTypeMapping/' + node.projectId + '/' + node.id,
                            width: 500,
                            height:400,
                            modal:true,
                            closable:true,
                            buttons:[{
                                text: ide.i18n.dialogOkButtonText,
                                handler:function(){
                                    var win = dialog.getIframeWindow();
                                    if(win && win.jQuery){
                                        self.editProjectTypeMapping.submit();
                                    }
                                }
                            },{
                                text: ide.i18n.dialogCancelButtonText,
                                handler: function(e){
                                    e.data.dialog.close();
                                }
                            }]
                        });
                    }
                }
            });
        },
        deleteProject:function(node){
            //delete project
            var self = this;
            var mainWindow = common.getMainWindow(),
                main = mainWindow && main;
            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }


            if(typeof node != 'undefined'){
                var tips="";
                //如果此项目是通过ftp下载，而且还没下载完成
                if(node.operateMap&&node.operateMap.MainframeProject&&!node.operateMap.SourceCodeComplete){
                    tips="Project haven't be downloaded by ftp,<br/>";
                }
                tips += ide.i18n.repository.deleteProjectConfirm;
                ide.util.confirm(tips,function(e){
                    var href = common.config.rootUrl + 'ide/delete_project?projectId=' + node.projectId;
                    $.ajax({
                        type:'POST',
                        url:href,
                        dataType:'text',
                        success:function(rs){
                            if(rs == 'success'){
                                sourceCode.deleteItem(node);
                                parent.main && parent.main.closeCodeTabsByParams({
                                    projectId:node.projectId
                                },true);
                                e.data.dialog.close();
                            }else{
                                ide.util.alert(ide.i18n.repository.delProjectFailed,null,2);
                            }
                        }
                    });
                });
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject,null,3);
            }

        },
        deleteFileOrFolder:function(node){
            //delete file or folder
            var self = this;
            //右键删除多个文件
            /*var confirmContent = deleteConfirm;
             var selectItems = sourceCode.getSelectedItems();
             console.log(selectItems);
             if(selectItems.length>0){
             ide.util.confirm(confirmContent, function(e){
             for (var i = 0; i<selectItems.length;i++){
             sourceCode.deleteItem(selectItems[i]);
             }
             e.data.dialog.close();
             });
             }else{
             ide.util.alert(ide.i18n.needSelectFile,null,3);
             }*/

            var confirmContent = ide.i18n.repository.deleteConfirm;
            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }
            if(node){
                if(node.id === node.projectId){
                    confirmContent = ide.i18n.repository.deleteProjectConfirm;
                }
                ide.util.confirm(confirmContent, function(e){
                    _deleteNode(node,true);
                    e.data.dialog.close();
                });

            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile, null, 3);
            }


        },
        deleteItemById: function(id){
            //delete item by id
            var self = this;
            if(typeof id != 'undefined'){
                ide.util.confirm(ide.i18n.repository.deleteConfirm,function(e){
                    _deleteNodeById(id);
                });
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
            }
        },
        deleteItemsByIds:function(ids){
            //通过id数组删除文件
            var self = this;
            if(ids){
                ide.util.confirm(ide.i18n.repository.deleteConfirm, function(e){
                    for(var i=0; i < ids.length; i++){
                        var node = sourceCode.getItemById(ids[i]);
                        var href = common.config.rootUrl + 'codefiles/deleteCodefiles/' + ids[i];
                        if (node.length > 0){
                            ide.util.ajax({
                                url:href,
                                type:'GET',
                                success:function(rs){
                                    var nodes = sourceCode.getSelectedItems();
                                    sourceCode.deleteItem(nodes);
                                }
                            });
                        }else{
                            var flag = false;
                            var href = common.config.rootUrl + 'ide/findFileById' + ids[i];
                            $.ajax({
                                type:'GET',
                                url:href,
                                dataType:'json',
                                success:function(rs){
                                    if(rs){
                                        var delHref = common.config.rootUrl + 'codefiles/deleteCodefiles/' + rs.id;
                                        ide.util.ajax({
                                            url:delHref,
                                            type:'GET',
                                            success:function(){
                                                var node = sourceCode.getSelectedItems();
                                                sourceCode.deleteItem(node);
                                            }
                                        });
                                    }else{
                                        ide.util.alert(ide.i18n.repository.deleteFileNo,null, 3);
                                    }
                                }
                            });
                        }
                    }
                });
            }else{
                ide.util.alert("Delete files not found!",null,3);
            }


        },
        deleteItems:function(item){
            //source code deleteItem 删除多个item
            var self = this;
            var confirmStr = ide.i18n.repository.deleteConfirm;
            if(item && item.length > 0){
                if(item[0].id === item[0].projectId){
                    confirmStr = ide.i18n.repository.deleteProjectConfirm
                }
                ide.util.confirm(confirmStr, function(e){
                    for(var i = 0; i < item.length; i++){
                        _deleteNodeById(item[i].id);
                    }
                    e.data.dialog.close();
                });
            }else{
                var node = sourceCode.getSelectedItems();

                if(!node.length){
                    ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
                    return false;
                }
                if(node && node[0].id === node[0].projectId){
                    var tips="";
                    if(node[0].operateMap&&node[0].operateMap.MainframeProject&&!node[0].operateMap.SourceCodeComplete){
                        tips="Project haven't be downloaded by ftp,<br/>";
                    }
                    confirmStr = tips+ide.i18n.repository.deleteProjectConfirm;
                }
                if(node.length>0){
                    ide.util.confirm(confirmStr, function(e){
                        for(var i = 0; i < node.length; i++){
                            _deleteNodeById(node[i].id);
                        }
                        e.data.dialog.close();
                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needSelectFile, null, 3);
                }
            }
        },
        addFolderByNodes:function(node){
            // 通过节点添加文件夹
            //  this function is for translation and transformation
            //  when translation/transformation finished the tree will add root folder
            var self = this;
            if(node && node.name){
                var pNode = sourceCode.getItemsByParam('name', node.name);
                if(pNode){
                    sourceCode.updateItem(node);
                }else{
                    sourceCode.addItem(node.pId,node);
                }
            }else{
                sourceCode.addItem(node.nodes.parentId,node.nodes);
            }
        },
        openItemByIds: function(ids,params){
            //通过 id数组 搜索文件
            var self = this;
            var len;
            if(ids && (len = ids.length)){
                for(var i = 0; i < len; i++){
                    self.openItemById(ids[i], params);
                }
            }else{
                ide.util.alert('No files not be selected!', null, 3);
            }
        },
        newFile: function(parentNode){
            //add new file
            var self = this;
            if(typeof parentNode == 'undefined'){
                parentNode = sourceCode.getSelectedItems()[0];
            }
            if(parentNode && !parentNode.isExpanded){
                sourceCode.expand(parentNode);
            }
            if(parentNode){
                //根节点不允许添加文件
                if(parentNode.id == parentNode.projectId){
                    ide.util.alert(ide.i18n.repository.disableAddFile,null,3);
                    return false;
                }

                var href = common.config.rootUrl + 'ide/newFile';
                var dialog = self.newFile.dialog = common.getMainWindow().ide.util.dialog({
                    title:'New File',
                    iframe: false,
                    href: href,
                    width: 800,
                    height:300,
                    modal:true,
                    closeable:true,
                    buttons:[{
                        text: ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFile.submit &&  self.newFile.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }]
                })
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
            }
        },
        newFolder:function(node,flag){
            // add new folder
            //input : flag = true -> edit folder /
            // flag = false -> new folder
            var self = this;
            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }
            if(node && node.isExpanded){
                sourceCode.expand(node);
            }
            if(node){
                var href = common.config.rootUrl + 'ide/newFolder';
                var dialog =  self.newFolder.dialog = common.getMainWindow().ide.util.popupDialog({
                    title: 'New Folder',
                    iframe: false,
                    href: href,
                    width:400,
                    height:150,
                    modal:true,
                    closable:false,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFolder.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }]
                });

            }else{
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
            }
        },
        addNewFolder:function(p, src, message, type, time, callback){
            var self = this;
            var pg = common.getMainWindow().main.progress(message, {
                defaultProgress: 60,
                defaultTimes: time
            });
            ide.util.log.i(message);
            common.getMainWindow().main.showProgress();
            var node;
            $.ajax({
                url: src,
                dataType: "json",
                type: "get",
                success: function(data) {
                    showMessage(message, type);
                    pg.complete(time - 2000);
                    setTimeout(function() {
                        node = repository.addFolder(p, data)[0];
                        repository.expand(node);
                        ide.util.log.i("Generate files completed");
                        if (message == "Run Bre") {
                            common.getRepositoryWindow().jQuery("#" + node.children[0].children[0].tId + "_a").trigger("click");
                        }

                        if (callback) {
                            callback.call(this);
                        }
                    }, time - 4000);

                }
            });
            return node;
        },
        editFileFolder:function(node){
            //编辑文件或文件夹
            var self = this;
            if(typeof node == 'undefined'){
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
                return ;
            }
            if(!node.isParent){
                var dialog = self.newFile.dialog = common.getMainWindow().ide.util.popupDialog({
                    title:'Rename',
                    iframe:false,
                    href:common.config.rootUrl + 'ide/editFile/' + node.id + '/' + node.name,
                    width: 400,
                    height: 150,
                    modal: true,
                    closable:false,
                    buttons:[{
                        text: ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFile.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }]
                });
            }else{
                self.newFolder(node,true);
            }

        },
        selectFiles:function(options,callback){
            /**
             * 选择文件，点击Ok 按钮获取选中的文件
             * @param  {[Object]}   options 配置参数 pId必填 为父节点目录
             * @param  {Function} callback 点击ok按钮的回调函数
             */
            var self = this;
            options = options || {};

            if(typeof options.pId != 'undefined'){
                self.selectFiles.dialog = common.getMainWindow().ide.util.dialog({
                    title:'Select File',
                    width:800,
                    height: 540,
                    iframe: false,
                    modal: true,
                    href: common.config.rootUrl + 'page/select_file.html',
                    buttons:[{
                        text:'OK',
                        handler: function(e){
                            callback && $.isFunction(callback) && callback.call(this,e,self.selectFiles.getSelectedFiles());
                        }
                    },{
                        text: ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }],
                    success:function(){
                        self.selectFiles.init(options.pId);
                    }
                })
            }

        },
        runTranslationInit:function(node){
            // run init translation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            var href = common.config.rootUrl + 'translation/init/' + node.projectId;
            $.ajax({
                dataType: 'json',
                url: href,
                type: 'POST',
                success:function(rs) {

                    if (rs.length) {
                        for (var i = 0; i < rs.length; i++) {
                            //if node exits , updata this nodes.
                            var pNode = sourceCode.getItemsByParam("name", rs[i].name, node);
                            if (pNode.length > 0) {
                                sourceCode.deleteItem(pNode[0]);
                                sourceCode.addItem(node, rs[i]);
                            } else {
                                sourceCode.addItem(node, rs[i]);
                            }
                        }
                    } else {
                        var pNode = sourceCode.getItemsByParam("name", rs.name, node);
                        if (pNode.length > 0) {
                            sourceCode.deleteItem(pNode[0]);
                            sourceCode.addItem(node, rs);
                        } else {
                            sourceCode.addItem(node, rs);
                        }
                    }
                }
            });

        },
        runTranslationImmediately:function(node){
            //run translation immediately
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            if(node){
                if(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject){
                    var projectId = node.projectId;
                    var progress = new ide.util.progress("translating", {
                            type: 1,
                            complete: function() {
                                var href = common.config.rootUrl + 'codetranslation/getTranslatedCode/' + projectId;
                                $.ajax({
                                    url: href,
                                    type: "GET",
                                    success: function(rs) {
                                        //ide.util.log.i(data.msg);
                                        rs = $.parseJSON(rs);
                                        if (rs.length) {
                                            for (var i = 0; i < rs.length; i++) {
                                                //if node exits , updata this nodes.
                                                var pNode = sourceCode.getItemsByParam("name", rs[i].name, node);
                                                if (pNode.length>0) {
                                                    sourceCode.deleteItem(pNode[0]);
                                                    sourceCode.addItem(node, rs[i]);
                                                } else {
                                                    sourceCode.addItem(node, rs[i]);
                                                }
                                            }
                                        } else {
                                            var pNode = sourceCode.getItemsByParam("name", rs.name, node);
                                            if (pNode.length>0) {
                                                sourceCode.deleteItem(pNode[0]);
                                                sourceCode.addItem(node, rs);
                                            } else {
                                                sourceCode.addItem(node, rs);
                                            }
                                        }

                                        self.updateProjectStatus(projectId);
                                    },
                                    error:function(data){
                                        //to do
                                    }
                                })
                            }
                        }),
                        progressId = progress.getId();

                    $.ajax({
                        url: common.config.rootUrl + 'codetranslation/start/' + projectId + "/" + progressId,
                        type: "GET",
                        success: function(data) {
                            data = $.parseJSON(data);
                            if(data && data.status == "200") {
                                common.getMainWindow().main.showProgress();
                                ide.util.log.i(data.msg);
                                if (data.result) {
                                }
                            } else if(data && data.status == "1002") {
                                //current task is working
                                var progress = ide.util.getProgress(progressId);
                                progress && progress.remove();
                                ide.util.alert("The current project is being translated.", null, 3);
                            }
                        }
                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needUploadorCheckout + "\n", null, 3);
                }
            }

        },
        runTranslationSchedule: function(node){
            //run translation schedule
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            if(node&&node.operateMap&&(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject)){
                var dialog= self.runTranslationSchedule.dialog = common.getMainWindow().ide.util.dialog({
                    title:"Schedule",
                    iframe:true,
                    href: common.config.rootUrl + "ide/runTranslationSchedule/"+node.projectId,
                    width:500,
                    height:455,
                    modal:true,
                    closable:true,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler:function(){
                            var win=dialog.getIframeWindow();
                            if(win&&win.jQuery){
                                self.runTranslationSchedule.submit && self.runTranslationSchedule.submit();
                            }
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }]
                });
            }
        },
        mergeTranslation:function(node){
            // merge translation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
        },
        runTransformationInit:function(node){
            //run init transformation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }

            var selector = repository.getSelectors();
            //需要在operateMap 中加transformation,用来判断 transformation 是否可点击.
            // true 为可点, false 为不可点
            // node.operateMap.transformation = true;
            var isInit = node.operateMap.transformation;
            var arr = [];
            arr[0] = contextMenu.find(selector.initTransformation).closest('li').attr('data-service');
            //点击设置init不可用
            if(isInit){

                //repository.disableMenus(arr);

                menu.disableMenus(arr);

                var tfInitData = {
                    projectId: node.projectId,
                    transformation: false
                };
                ide.util.ajax({
                    type:'get',
                    url: common.config.rootUrl + "transformationConfig/initDirectory",
                    //'assets/data/repository/iniTransformation/tree.json',
                    dataType: 'json',
                    data:tfInitData,
                    success:function(rs){
                        var items = rs.data.json.nodes;
                        var zTree = sourceCode.getTree();
                        zTree.addNodes(node,items, false);
                        for(var i = 0; i < items.length; i++){
                            zTree.updateNode(items[i]);
                        }
                    }
                });

            }else{
                menu.enableMenus(arr);
            }
        },
        runTransformationImmediately:function(node){
            //run transformation immediately
            var self = this;
            node = _getRootNode(node);
            var data = {
                projectId: node.projectId
            };
            ide.util.ajax({
                type:'get',
                dataType:'json',
                url: common.config.rootUrl + "transformationConfig/scriptFileList/validate",
                // 'assets/data/repository/runTransformation/file.json',
                data:data,
                success:function(rs){
                    if(rs.status == 200){
                        self.runTransformationImmediately.dialog = common.getMainWindow().ide.util.dialog({
                            title:'Script Files',
                            width:600,
                            height:480,
                            iframe:false,
                            modal:true,
                            href: common.config.rootUrl + 'page/list_files.html',
                            buttons:[{
                                text:'OK',
                                handler: function(e){
                                    var arrId = self.runTransformationImmediately.getSelectedFiles();
                                    var createOutputArg = {
                                        projectId: arrId[0].projectId,
                                        fileId: arrId[0].id
                                    };
                                    self.runTransformationOutput(createOutputArg);
                                }
                            },{
                                text: ide.i18n.dialogCancelButtonText,
                                handler:function(e){
                                    e.data.dialog.close();
                                }
                            }],
                            success:function(){
                                self.runTransformationImmediately.init(node.projectId);
                            }
                        });
                    }else{
                        ide.util.alert(rs.message,null,2)
                    }
                }
            })
        },
        runTransformationOutput: function(data){
            //生成output 节点
            var self = this;
            ide.util.ajax({
                type:'get',
                dataType:'json',
                url: common.config.rootUrl + "ide/transformation/runScript" + "?projectId="+data.projectId+"&fileId="+data.fileId,
                //'assets/data/repository/runTransformation/Output.json'
                success:function(rs){
                    //console.log(rs);
                    var items = rs.data.json.nodes;
                    var zTree = sourceCode.getTree();
                    var nodes = sourceCode.getSelectedItems();
                    if(nodes&&nodes.length){
                        zTree.addNodes(nodes[0], items,false);
                        for(var i = 0, len = items.length; i < len; i++){
                            zTree.updateNode(items[i]);
                        }
                        self.runTransformationImmediately.dialog.close();
                    }
                }
            })
        },
        runTransformationSchedule:function(node){
            //run transformation schedule
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            if(node.operateMap.CheckoutProject||node.operateMap.UploadProject){
                common.getMainWindow().ide.util.popupDialog({
                    href: common.config.rootUrl + "ide/runSchedule ",
                    width: 500,
                    height: 400
                });
            }else{
                var alertContent = '';
                alertContent += ide.i18n.repository.needUploadorCheckout+"<br>";
                ide.util.alert(alertContent, null, 3);
            }

        },
        mergeTransformation:function(node) {
            //merge transformation
            var self = this;
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            var alertContent="" ;
            if(node.operateMap && (node.operateMap.CheckoutProject||node.operateMap.UploadProject)){
                if(node.operateMap.Transformation){
                    var src = common.config.rootUrl + "assets/data/repository/merageTransform/project_tree.json";
                    self.addNewFolder(sourceCode.getNodesByParam("id", "0102")[0], src, "Merge Transformation ", "run", 20000);
                }else{
                    alertContent+=ide.i18n.repository.needTransformation+"<br>";
                    ide.util.alert(alertContent, null, 3);
                }
            }else{
                alertContent+=ide.i18n.repository.needUploadorCheckout+"<br>";
                alertContent+=ide.i18n.repository.needTransformation+"<br>";
                ide.util.alert(alertContent, null, 3);
            }

        },
        runBreSchedule: function (node) {
            // run bre schedule
            var self = this;
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            common.getMainWindow().ide.util.popupDialog({
                href: common.config.rootUrl + "ide/runSchedule",
                width: 500,
                height: 400
            });
        },
        breConfigration: function (node) {
            // run configuration
            var self = this;
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }
            common.getMainWindow().ide.util.popupDialog({
                href: common.config.rootUrl + "ide/bre"
            });
        },
        runBreImmediately: function (node) {
            //run bre immediately
            var self = this;
            var height = top.document.body.clientHeight - 80;
            var width = top.window.document.body.clientWidth - 40;
            var alertContent = "";
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            if (node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject)) {
                //if(node.operateMap.SystemAnalysis){
                var dialog = repositoryService.runBreImmediately.dialog = common.getMainWindow().ide.util.popupDialog({
                    href: common.config.rootUrl + "/ide/patternanalysis/" + node.projectId,
                    width: width,
                    height: height
                });
            } else {

                alertContent = ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);

            }

        },
        runDuplicationAnalysis: function (node, isToolbar) {
            //isToolbar : 是否是toolbar单击
            var self = this;
            var win = $(parent.window), height = win.height() - 40,
                width = win.width() - 40,
                alertContent = "";
            node = _getRootNode(node);
            //console.log(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }
            if (node && node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject)) {
                //if(node.operateMap.SystemAnalysis){
                var dialog;
                if ((dialog = self.runDuplicationAnalysis.dialog) && dialog.projectId == node.projectId) {
                    dialog.ui.dialog.show();
                    dialog.ui.dialogOverlay.ui.overlay.fadeIn(250);
                    dialog.ui.dialog.animate(dialog.uiStatus, 300, function () {
                        dialog.ui.closeHandler.show();
                    });
                    return;
                }
                self.runDuplicationAnalysis.closeDialog = function (e) {
                    //console.log(this);
                    var dialog = self.runDuplicationAnalysis.dialog, btn = common.getMainWindow().jQuery("#runDuplicationAnalysisBtn .btn");

                    //缓存dialog状态
                    dialog.uiStatus = {
                        width: dialog.ui.dialog.width(),
                        height: dialog.ui.dialog.height(),
                        top: parseInt(dialog.ui.dialog.css("top")),
                        left: parseInt(dialog.ui.dialog.css("left"))
                    }
                    dialog.ui.closeHandler.hide();
                    dialog.ui.dialogOverlay.ui.overlay.fadeOut(250);

                    dialog.ui.dialog.animate({
                        left: btn.offset().left,
                        top: 70,
                        width: 0,
                        height: 0
                    }, 450, function () {
                        dialog.ui.dialog.hide();
                        btn.addClass("active");
                        setTimeout(function () {
                            btn.removeClass("active");
                            //setInterval(function(){
                            //btn.removeClass("bounce animated").addClass("bounce animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                            //	$(this).removeClass("bounce animated");
                            //});
                            //btn.removeClass("bounce animated").addClass("bounce animated");
                            //},3000);
                        }, 160);
                    });
                    return false;

                }
                dialog = self.runDuplicationAnalysis.dialog = common.getMainWindow().ide.util.dialog({
                    title: "Business Rule Extraction",
                    href: common.config.rootUrl + "/ide/patternanalysis/" + node.projectId+"?share="+node.isSharedProjectForCurrentUser,
                    width: width,
                    height: height,
                    modal: true,
                    closeHandler: self.runDuplicationAnalysis.closeDialog
                });
                dialog.projectId = node.projectId;
                //}else{
                //	alertContent+=ide.i18n.repository.needAnalysis;
                //	ide.util.alert(alertContent, null, 3);
                //}
            } else {
                alertContent = ide.i18n.repository.needUploadorCheckout + "<br>";
                ide.util.alert(alertContent, null, 3);
            }
        },
        runAnalysis: function (node) {
            //run analysis
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                alertContent += ide.i18n.repository.needSelectProject;
                ide.util.alert(alertContent, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runAnalysis";
                var dialog = self.runAnalysis.dialog = common.getMainWindow().ide.util.dialog({
                    title: "Analysis Options",
                    iframe: false,
                    href: href,
                    width: 500,
                    height:255,
                    modal: true,
                    closable: true,
                    buttons: [
                        {
                            text: "Run",
                            handler: function () {
                                self.runAnalysis.submit();
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                            }
                        }
                    ]
                });
            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runAnalysisSchedule: function (node) {
            //run analysis schedule
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runAnalysisSchedule";
                var dialog = repositoryService.runAnalysisSchedule.dialog = common.getMainWindow().ide.util.dialog({
                    title: "Schedule",
                    iframe: true,
                    href: href,
                    width: 500,
                    height: 480,
                    modal: true,
                    closable: true,
                    buttons: [
                        {
                            text: ide.i18n.dialogOkButtonText,
                            handler: function () {
                                var win = dialog.getIframeWindow();
                                if (win && win.jQuery) {
                                    repositoryService.runAnalysisSchedule.submit();
                                }
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                            }
                        }
                    ]
                });

            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runCheckstyle: function (node) {
            //run analysis
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                alertContent += ide.i18n.repository.needSelectProject;
                ide.util.alert(alertContent, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                ide.util.ajax({
                    url:common.config.rootUrl+"checkstyle/start",
                    type:"get",
                    data:{
                        projectId:node.projectId
                    },
                    success:function(){
                        //ide.util.tips("check");
                    }
                });
            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runCheckstyleSchedule: function (node) {
            //run Checkstyle schedule
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runCheckstyleSchedule";
                var dialog = repositoryService.runCheckstyleSchedule.dialog = common.getMainWindow().ide.util.dialog({
                    title: "Schedule",
                    iframe: true,
                    href: href,
                    width: 500,
                    height: 480,
                    modal: true,
                    closable: true,
                    buttons: [
                        {
                            text: ide.i18n.dialogOkButtonText,
                            handler: function () {
                                var win = dialog.getIframeWindow();
                                if (win && win.jQuery) {
                                    repositoryService.runCheckstyleSchedule.submit();
                                }
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                            }
                        }
                    ]
                });

            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        openFileById:function(id,params){
            //通过 id 打开文件
            var self = this;
            if(id){
                var node = sourceCode.getItemById(id);
                if(node.length > 0){
                    _openItem(node[0], params);
                }else{
                    var flag = false,
                        href = common.config.rootUrl + 'ide/findFileById/' + id;
                    $.ajax({
                        url: href,
                        type: 'GET',
                        dataType: 'json',
                        success:function(rs){
                            if(rs){
                                _openItem(rs,params);
                            }else{
                                ide.util.alert(ide.i18n.repository.fileNo,null,3);
                            }

                        }
                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.fileNo,null,3);
            }
        },
        openFilesByIds: function (ids, params) {
            //通过ID数组打开文件
            var self = this;
            var length;
            if (ids && (length = ids.length)) {
                for (var i = 0; i < length; i++) {
                    self.openFileById(ids[i], params);
                }
            } else {
                ide.util.alert(ide.i18n.repository.fileNo, null, 3);
            }
        },
        openFiles: function (files, params) {
            //通过items数组打开files
            var self = this;
            var length;
            if (files && (length = files.length)) {
                for (var i = 0; i < length; i++) {
                    _openItem(files[i], params);
                }
            } else {
                ide.util.alert(ide.i18n.repository.fileNo, null, 3);
            }
        },
        tabSelect: function (ele) {
            //     tabSelect();
            //     tab切换
            //     ele最外层节点
            //     eg:
            //     <div class='J_IT'>
            //         <ul class='J_tabNav tab-nav'>
            //            <li class='active'>tab1</li>
            //            <li>tab2</li>
            //         </ul>
            //         <div class='J_tabCont tab-content'>
            //             <div class='tab-pane active'>cont1</div>
            //             <div class='tab-pane'>cont2</div>
            //         </div>
            //     </div>
            var self = this;
            var tabBox;
            if (typeof ele == 'object') {
                tabBox = ele
            } else if (typeof ele == 'string') {
                tabBox = $(ele)
            }
            var tabNav = tabBox.find('.J_tabNav').children(),
                tabCont = tabBox.find('.J_tabCont .tab-pane'),
                ACTIVE = 'active';
            $.each(tabNav, function (idx, ele) {
                $(ele).on('click', function (e) {
                    e.preventDefault();
                    $(this).addClass(ACTIVE).siblings().removeClass(ACTIVE);
                    $(tabCont).eq(idx).addClass(ACTIVE).siblings('.tab-pane').removeClass(ACTIVE);
                })
            })
        },
        runTest:function(){
            //run rule run test
            var self = this;
            var node = sourceCode.getSelectedItem();
            if(node && node.length){
                self.selectFiles({pId:node[0].projectId},function(e,files){
                    var arrId = [];
                    if(files && files.length>0){
                        for(var i = 0; i < files.length; i++){
                            arrId.push(files[i].id);
                        }
                    }else{
                        ide.util.tips(ide.i18n.repository.needSelectFile,1500,2);
                        return false;
                    }
                    ide.util.ajax({
                        type:'post',
                        dataType:'json',
                        url: common.config.rootUrl + 'ide/transformation/runRule?projectId='+node[0].projectId+'&rulefileid='+arrId+'&sourcefileid='+node[0].id,
                        success:function(rs){
                            //console.log(rs);
                        }
                    });
                    self.selectFiles.dialog.close();
                });
            }
        },
        teamUpdate: function(){
            //team update
            //team更新代码
            /*逻辑:
             * 1.本地新建文件,新文件加入数据库,不加入版本库,
             *   本地删除后,数据库中删除. 相当于文件的删除新建的操作.
             *
             *   在commit后,数据库,版本库都会被加入,
             *   本地文件删除时,执行upddte操作,树节点中还会有此文件.
             *
             * 2.删除后,执行commit操作,数据库,版本库都会被删除.
             * */
            var self = this;
            var node = sourceCode.getSelectedItem(),
                postData = [],
                href = common.config.rootUrl + 'assets/data/repository/team/team_update_file.json';
            for(var i = 0; i < node.length; i++){
                var arrData = {
                    projectId: node[i].projectId,
                    isParent: node[i].isParent,
                    id: node[i].id//,
//                    isRevert: node[i].operateMap.isRevert
                }
                postData.push(arrData);
            }
            //调用接口
            var isSaverFullFiles = common.getMainWindow().main.hasModifiedFiles();

            if(isSaverFullFiles){
                //文件没有保存
                common.getMainWindow().main.saveAll(function(){
                    ide.util.ajax({
                        url:href,
                        type:'get',
                        data:JSON.stringify(postData),
                        success: function(rs){
                            if(rs.status === 200){
                                ide.util.tips(rs.message,1500);
                            }else{
                                ide.util.alert(rs.message, null, 2);
                            }
                        }
                    });
                });
            }else{
                ide.util.ajax({
                    url:href,
                    type:'get',
                    data: JSON.stringify(postData),
                    success:function(rs){
                        if(rs.status === 200){
                            sourceCode.updateItem(node);
                            ide.util.alert(rs.message,null);
                        }else{
                            ide.util.alert(rs.message,null,2);
                        }
                    }
                });
            }
        },
        teamCommit: function(){
            //team commit
            //team提交代码
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamCommit().dialog = common.getMainWindow().ide.util.dialog({
                        title: 'Commit',
                        href: common.config.rootUrl + 'page/team_commit.html',
                        iframe: false,
                        width:600,
                        height:500,
                        modal:true,
                        buttons:[{
                            text:"Commit",
                            handler:function(e){
                                if(self.teamCommit.submit){
                                    self.teamCommit.submit();
                                }
                            }
                        },{
                            text:ide.i18n.dialogCancelButtonText,
                            handler:function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            self.teamCommit.initCommit(node);
                        }
                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }

        },
        teamRevert: function(){
            //team revert
            //team 还原代码
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamRevert.dialog = common.getMainWindow().ide.util.dialog({
                        title:'Revert',
                        href: common.config.rootUrl + "page/team_revert.html",
                        iframe:false,
                        width: 700,
                        height: 480,
                        modal: true,
                        buttons:[{
                            text:"Revert",
                            handler:function(e){
                                if(self.teamRevert.submit){
                                    self.teamRevert.submit();
                                }
                            }
                        },{
                            text:ide.i18n.dialogCancelButtonText,
                            handler:function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            self.teamRevert.initRevert(node);
                        }
                    })
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }

        },
        teamShowHistory: function(){
            //team show history
            //显示历史信息
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamShowHistory.dialog = common.getMainWindow().ide.util.dialog({
                        title:'Show History',
                        href: common.config.rootUrl + "page/team_showHistory.html",
                        iframe:false,
                        width: 700,
                        height: 480,
                        modal: true,
                        success:function(){
                            self.teamShowHistory.initShowHistory(node);
                        }
                    })
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }
        },
        shareProject:function(){
            //share project
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.shareProject.dialog = common.getMainWindow().ide.util.dialog({
                        title:'Share / UnShare',
                        href: common.config.rootUrl + 'page/share_project.html',
                        iframe: false,
                        width:600,
                        height: 400,
                        modal: true,
                        buttons:[{
                            text:'Save',
                            handler:function(e){
                                if(self.shareProject.submit){
                                    self.shareProject.submit();
                                }
                            }
                        },{
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            self.shareProject.initShareProject(node);
                        }

                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needSelectProject);
                }
            }

        }




    };

    return repositoryService;
})(window.repositoryService || {}, ide, repository, jQuery, common);