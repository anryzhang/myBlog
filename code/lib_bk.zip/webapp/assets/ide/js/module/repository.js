
define(['jquery','ide','moduleCommon'],function($,ide,common){

//var repository = (function(repository,common,ide, $) {
	//"use strict";
    var repository = {};
	var selectors = {
			addFile:".ide-repository-add-file",
			addFolder:".ide-repository-add-folder",
			checkout:".ide-repository-check-out",
			upload:".ide-repository-upload",
            team: ".ide-repository-team",
			update:".ide-repository-update",
			commit:".ide-repository-commit",
            revert:".ide-repository-revert",
            showHistory:".ide-repository-showHistory",
			eidt:".ide-repository-edit",
            runTest:".ide-repository-run-test",
            runJob:'.ide-repository-run-job',
			copy:".ide-repository-copy",
			paste:".ide-repository-paste",
			del:".ide-repository-delete",
			editProject:".ide-repository-edit-project",
			delProject:".ide-repository-delete-project",
			download:".ide-repository-download",
			bre:".ide-repository-run-bre",
			breConfig:".ide-repository-bre-configration",
			runBreI:".ide-repository-run-bre-immediately",
			runBreS:".ide-repository-run-bre-schedule",
			runDuplicationAnalysis:".ide-repository-run-bre-duplicationAnalysis",
			translation:".ide-repository-run-translation",
			TLConfig:".ide-repository-run-translation-init",
			runTLI:".ide-repository-run-translation-immediately",
			runTLS:".ide-repository-run-translation-schedule",
			transformation:".ide-repository-run-transformation",
            initTransformation:'.ide-repository-run-transformation-init',
			TFConfig:".ide-repository-run-transformation-init",
			runTFI:".ide-repository-run-transformation-immediately",
			runTFS:".ide-repository-run-transformation-schedule",
			codeSearch:"#code-search",
			analysis:".ide-repository-run-analysis",
			runANAI:".ide-repository-run-analysis-immediately",
			runANAS:".ide-repository-run-analysis-schedule",
			editProjectBasicInfo:".ide-repository-eidt-basic-information",
			fileTypeMapping:".ide-repository-eidt-type-mapping",
            teamCommit:".team-container",
            share:'.ide-repository-share-project',
            updateFileType:'.ide-repository-updateFileType'
		},
        urls={
			analysisConfigurationUrl: common.config.rootUrl+"ide/analysis/configuration",
			translationConfigurationURL: common.config.rootUrl+"ide/translation/configuration",
			transformationConfigurationUrl: common.config.rootUrl+"ide/transformation/configuration"
		},
        options,
		contextMenu = $(common.config.selectors.repositoryContextMenu),
        sourceCode,
        menus = contextMenu.find('[data-service]');


    repository = {
        getContextMenu: function(){
            //获取上下文菜单
            return $(common.config.selectors.repositoryContextMenu);
        },
        getUI: function(){
            return {
                codeSearch: $('#code-search'),
                treeId: $('#repository-tree')
            }
        },
        getSelectors: function(){
            //获取选择器
            return selectors;
        },
        updateNodes: function(highlight, items){
            //高亮显示目前节点
            var zTree = repository.getSourceCode().getTree();
            for(var i = 0, len = items.length; i < len; i++){
                items[i].highlight = highlight;
                zTree.updateNode(items[i]);
            }
        },
        getFontCss: function(treeId, treeNode){
            //设置ztree 单击时的样式
            return (!!treeNode.highlight) ? {color:'#a60000','font-weight':'bold'} : {color:'#333','font-weight':'normal'};
        },
        searchContent: function(){
            //得到搜索内容
            return mainWindow.jQuery(common.config.selectors.searchContent);
        },
        disableMenus: function(services){
            for(var i=0,j=services.length;i<j;i++){
                menus.filter("[data-service='"+services[i]+"']").addClass("disabled").data("disbaled",true);
            }
        },
        enableMenus: function(services){
            for(var i=0,j=services.length;i<j;i++){
                menus.filter("[data-service='"+services[i]+"']").removeClass("disabled").data("disbaled",false);
            }
        },
        hideContextMenu: function(){
            //隐藏contextmenu
            contextMenu.hide();
        },
        showContextMenu: function(){
            //显示contextmenu
            contextMenu.show();
        },
        refresh: function(data){
            sourceCode.refresh(data);
        },
        search: function(d){
            return sourceCode.getNodesByFilter(d);
        },
        addFolder:function(p, data, sourceCode, m, isSlient){
            //添加文件夹
            //console.log(p,typeof p);
            if(typeof p === "string"){
                var node = sourceCode.getNodesByParam("id",p)[0];
                //showMessageAndProgress(m);
                return sourceCode.addItem(node, data, isSlient);
            }else{
                //showMessageAndProgress(m);
                return sourceCode.addItem(p, data, isSlient);
            }

        },
        addFile: function(p, data, isSlient){
            //添加文件
            data.isParent=false;
            if(typeof p === "string"){
                var node=sourceCode.getNodesByParam("id",p)[0];
                return sourceCode.addItem(node, data, isSlient);
            }else{
                return sourceCode.addItem(p, data, isSlient);
            }
        },
        expand: function(nodes){
            //扩展
            sourceCode.expand(nodes);

        },
        setContextMenuPosition: function(left, top) {
            //设置右键菜单position
            contextMenu.css({
                top: top,
                left: left
            });
        }
    };


    function showMessageAndProgress(message){
        var pg =main.progress(message,{
            defaultProgress:60,
            defaultTimes:6000
        });
        ide.util.log.i(message);
        main.showProgress();

        ide.util.log.i("Start " + message + ".......");
        ide.util.log.i("Proecssing.......");
        setTimeout(function(){
                ide.util.log.i(message + "  completed");
            }
            ,4000)
        pg.complete(2000);

    }


	return repository;
//})(repository || {},common, ide,jQuery);

});