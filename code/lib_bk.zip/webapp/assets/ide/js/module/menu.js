define(['jquery','ide','util',"repositoryService"],function($,ide,util,repositoryService){
    var menu = {};
    var selectors={
            container:".ide-menu,.ide-toolbar"
        },
        menus=$(selectors.container).find(common.config.selectors.menu),
        subMenus=$(selectors.container).find(".dropdown-submenu"),
        repositoryContextMenus=$("#ide-repository-contextmenu").children(".dropdown-menu"),
        repositoryMenus=$("#ide-repository-contextmenu").find("[data-service]"),
        repositorySubMenus=$("#ide-repository-contextmenu").find(".dropdown-submenu");

    //优化memu行为
    var _btnGroups=$('#J_smart_menu .btn-group');
    _btnGroups.hover(function(e){
    	smartMenu(e,_btnGroups);
    });
    
    var _btnTargets = $('#J_smart_header .btn-group');
    _btnTargets.hover(function(e){
    	smartMenu(e,_btnTargets);
    });
    
    function smartMenu(e,targets){
    	if (targets.filter(".open").length>0){
    		targets.removeClass('open');
    		$(e.currentTarget).addClass('open');
    	}
    }
    
    //注册menu菜单
    menu.registerMenu=function(){
        $(selectors.container).on("click",common.config.selectors.menu,function(){            
            var $this=$(this),service=$this.attr("data-service");

            if($this.data("disbaled")!==true&&service){
                menu[service].call(this);
            }

            
        });
    }

    //如果子菜单都被禁用，则将跟菜单禁用
    //否则启用
    function initMenus(){
        subMenus.each(function(){
            //console.log($(this).find("[data-service]:not('.disabled')"));
            if(!$(this).find("[data-service]:not('.disabled')").length){
                $(this).addClass("disabled");
            }else{
                $(this).removeClass("disabled");
            }
        });

        repositorySubMenus.each(function(){
            if(!$(this).find("[data-service]:not('.disabled')").length){
                $(this).hide();
            }else{

                $(this).removeAttr("style");
            }
        });


        if(!repositoryContextMenus.find("[data-service]:not('.disabled')").length){
            repositoryContextMenus.hide();
        }else{
            repositoryContextMenus.show();
        }
    }

    menu.disableAllMenus=function(){
        menus.addClass("disabled").data("disbaled",true).find(".btn").addClass("disabled");
        repositoryMenus.hide().addClass("disabled");
        initMenus();
    }
    //禁止菜单
    menu.disableMenus=function(services){
        for(var i=0,j=services.length;i<j;i++){
            menus.filter("[data-service='"+services[i]+"']").addClass("disabled").data("disbaled",true).find(".btn").addClass("disabled");

            repositoryMenus.filter("[data-service='"+services[i]+"']").hide().addClass("disabled");
        }
        if(j){
            initMenus();
        }
    };

    //enable menu
    menu.enableMenus=function(services){
        for(var i=0,j=services.length;i<j;i++){
            menus.filter("[data-service='"+services[i]+"']").removeClass("disabled").data("disbaled",false).find(".btn").removeClass("disabled");
            repositoryMenus.filter("[data-service='"+services[i]+"']").removeAttr("style").removeClass("disabled").closest(".dropdown-menu").removeAttr("style");
        }
        if(j){

            initMenus();
        }
    };
    //隐藏所有右键菜单
    menu.disableRepositoryMenus=function(){
        repositoryMenus.hide().addClass("disabled");
        initMenus();
    }



    /*menu.init=function(opts){
        menu.registerMenu(menu);
    }*/

   /* $(function(){
        menu.init();
    });*/
    

    /*sub menu of file*/
    //new files
    menu.newFile = function() {
        if(repositoryService){
            repositoryService.newFile();
        }
    };

    //open file
    menu.openFile = function() {
        if(repositoryService){
            repositoryService.openItems();
        }
    };

    menu.save = function(data) {
        var tab=main.getCurrentCodeTab();
        //console.log(tab);
        if(tab){
        //  console.log(tab);
            main.save(tab);
        }
    };
    menu.saveAll = function(data) {
        main.saveAll();
    };

    //关闭code tab
    menu.closeCodeTabs = function() {
        main.closeCodeTab(main.getCurrentCodeTab());
    };
    //关闭所有code tab
    menu.closeAllCodeTabs = function() {
        main.closeAllCodeTabs();
    };

    menu.refresh = function(){
       /* var win=main.getFocusWindow();
        if(win&&win.editorService){
            win.editorService.refresh();
        }*/
        var obj=main.getFocusObject();
        if(obj&&obj!==repositoryService){
            obj.refresh();
        }
    };

    menu.exit = function() {
        window.location.href = common.config.rootUrl + "signout";
    };
    /*end file*/

    /*sub menu of edit*/

    menu.undo = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj!==repositoryService&&(editor=obj.getActiveEditor())){
            editor.undo();
        }
    };
    menu.redo = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj!==repositoryService&&(editor=obj.getActiveEditor())){
            editor.redo();
        }
    };

    menu.compile = function() {
       /* var obj=main.getFocusObject(),_code;
        //if(obj&&obj!==repositoryService){
            var _code=main.getActiveCode();
            _code&&_code.compile();
        //}
        //*/
        
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
            repositoryService.compile();
        }else if(obj&&(editor=obj.getActiveEditor())){
            var code=main.getActiveCode();
            if(code){
                 repositoryService.compile(code.editorObject.options);
            }            
        }
    };

    menu.runJob = function(){
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
            repositoryService.runJob();
        }else if(obj&&(editor=obj.getActiveEditor())){
            var code=main.getActiveCode();
            if(code){
                 repositoryService.runJob(code.editorObject.options);
            }            
        }
    }

    menu.selectAll = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
            //win.repositoryService.selectAllItems();
        }else if(obj&&(editor=obj.getActiveEditor())){
            editor.selectAll();
        }
    };
    menu.copy = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
           
        }else if(obj&&(editor=obj.getActiveEditor())){
            editor.copy();
        }
    };
    menu.cut = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
           
        }else if(obj&&(editor=obj.getActiveEditor())){
            editor.cut();
        }
    };
    menu.paste = function() {
        var obj=main.getFocusObject(),editor;
        if(obj&&obj===repositoryService){
           
        }else if(obj&&(editor=obj.getActiveEditor())){
            editor.paste();
        }
    };

    menu.updateFileType = function() {
        

        repositoryService.updateFileType();
    };

    menu.deleteFile = function() {
        //var obj=main.getFocusObject();
        //if(obj&&obj===repositoryService){
           repositoryService.deleteItems();
        //}
    };

    /*project service*/
    menu.editProject = function() {
        repositoryService.editProject();
    };

    menu.editProjectTypeMapping = function() {
        repositoryService.editProjectTypeMapping();
    };

    menu.newProject = function() {
        repositoryService.newProject();
    };

    menu.bre = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "ide/bre"
        });
    };

    menu.downloadAnalysisReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "ide/download/analysisReport"
        });
    };
    menu.downloadTranslationReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "ide/download/translationReport "
        });
    };
    menu.downloadTransformationReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "ide/download/transformationReport"
        });
    };
    menu.downloadBREReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "bre"
        });
    };
    menu.downloadQAReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "ide/download/qaReport"
        });
    };
    menu.downloadEstimationReport = function() {
        ide.util.popupDialog({
            href: common.config.rootUrl + "estimationReport"
        });
    };

    /*run*/
    menu.runAnalysis = function() {
        repositoryService.runAnalysis();
    };
    
    menu.runAnalysisSchedule = function() {
        repositoryService.runAnalysisSchedule();
    };

    /*history*/
    menu.historyBack = function(){
        main.history.prev();
    }
    menu.historyForward = function(){
        main.history.next();
    }

    /*run*/
    menu.runCheckstyle = function() {
        repositoryService.runCheckstyle();
    };
    
    menu.runCheckstyleSchedule = function() {
        repositoryService.runCheckstyleSchedule();
    };

    
    
    
    menu.runTranslationImmediately=function(){
        repositoryService.runTranslationImmediately();
    };

    menu.runTranslationSchedule=function(){
        repositoryService.runTranslationSchedule();
    };
    menu.runTransformationImmediately=function(){
        repositoryService.runTransformationImmediately();
    };

    menu.runTransformationSchedule=function(){
        repositoryService.runTransformationSchedule();
    };

    menu.runBreSchedule=function(){
        repositoryService.runBreSchedule();
    };

    menu.runBreImmediately=function(){
        repositoryService.runBreImmediately();
    };

    menu.runDuplicationAnalysis =function(){
        repositoryService.runDuplicationAnalysis(null,true);
    }
    /*end run*/


    /*view*/
    menu.projectList = function() {
        main.changeRepository(1);
    };
    menu.translationLib = function() {
        main.changeRepository(2);
    };
    menu.transformationLib = function() {
        main.changeRepository(3);
    };
    menu.changeSkin = function(){
        //换肤
        var self = this;
        var J_theme = $('#J_theme'),
            J_themeItems = $('.J_themeItem'),
            oldTheme = J_themeItems.find('li.circle').attr('data-theme');
        var themeData = {
            theme:$(self).attr('data-theme')
        };
        var themeUrl = common.config.rootUrl + 'updateUserStyle/' + themeData.theme;

        var reg = new RegExp(themeData.theme, 'g');
        if(J_theme.attr('href').match(reg)){
            return ;
        }else{

            ide.util.ajax({
                type:'get',
                dataType:'json',
                url:themeUrl,
                success:function(rs){
                    if(rs && rs.status == 200){
                        var _objSrc ;
                        _objSrc = J_theme.attr('href').replace(oldTheme,themeData.theme);
                        J_theme.attr('href',_objSrc);
                        J_theme.attr('data-theme',themeData.theme);
                        $(self).addClass('circle').siblings().removeClass('circle');

                    }

                },
                error:function(rs){
                    ide.util.alert(rs.message,null,3);

                }
            });


        }




    }

    /*Download*/
    menu.downloadSourcecode = function(){
        repositoryService.downloadSourcecode();
    }

    /*toolbar*/
    menu.cobolCheckStyle=function(){
    };

    /*schedule*/
    menu.schedule=function(){    
        menu.schedule.dialog = ide.util.dialog({
            title:"Schedule",
            width:1000,
            height:540,
            iframe:false,
            modal:true,
            href:common.config.rootUrl+"page/schedule.html",
            success:function(){
                require(['menuSchedule'],function(menuSchedule){
                    menuSchedule.init();
                });
            }
        });
    }
    menu.schedule.push=function(data){
        if(menu.schedule.isInit()&&menu.schedule.datatable){
            menu.schedule.datatable.removeAll();
            menu.schedule.datatable.insertAfter(0,data);
        }
    }
   
    menu.schedule.isInit=function(){
        return $("#J-schedule-container").length?true:false;
    }

    menu.uploadSourceCode=function(){
        repositoryService.uploadSourceCode();
    }


    return window.menu=menu;
});