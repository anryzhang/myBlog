var repositoryServiceForUpload = (function(repositoryServiceForUpload, ide, $) {
	"use strict";

	var sourceCode,
		options,
		contextMenuHeight;


	repositoryServiceForUpload.init = function(element, arg) {
		options = arg;
		extendOptions(options);
		initContextMenu();
		sourceCode = new ide.repository.SourceCodeForUpload(element, options);
	};

	function extendOptions(options) 
	{	
		var contextMenuTop = 123, //右键菜单默认top
		    contextMenuHeight = common.getContextMenuHeight(repositoryForUpload.getContextMenu()) + 50;

		options.rightClick = function(e, data) {
			repositoryForUpload.getContextMenu().data("data", data);
			repositoryForUpload.setContextMenuPosition(e.clientX,e.clientY);
			repositoryForUpload.showContextMenu();
			return false;
		};		
	}


	//init contextmenu handle
	function initContextMenu() {
		repositoryForUpload.getContextMenu().on("click","li", function() {
			var $this = $(this),
				service = $this.attr("data-id");
		});
	}


	return repositoryServiceForUpload;
})(repositoryServiceForUpload || {}, ide, jQuery);