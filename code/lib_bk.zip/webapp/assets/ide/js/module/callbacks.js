//var callbacks=(function(callbacks,common,$){

define(['jquery','moduleCommon'],function($,common){

   var callbacks = {};
	
	callbacks.id=0;

	callbacks.cache={};


	callbacks.getId=function(){
		return ++callbacks.id;
	};
	callbacks.add=function(id,func){
		if(!callbacks.cache[id]){
			callbacks.cache[id]=new Array();

		}

		callbacks.cache[id].push(func);
		//console.log(callbacks.cache[id]);
	};


	callbacks.execute=function(id){
		if(!id){
			id=callbacks.id;
		}
		var funcs=callbacks.cache[id],mainWindow=common.getMainWindow(),repositoryWindow=common.getRepositoryWindow(),
		codeWindow=common.getCodeWindow(),editorWindow=common.getEditorWindow();

		//console.log(funcs);
		for(var i=0,length=funcs.length;i<length;i++){
			funcs[i].call(callbacks,mainWindow,repositoryWindow,codeWindow,editorWindow);
		}

		delete callbacks.cache[id];
	};
	return callbacks;

});

 //   })(callbacks||{},common,jQuery);