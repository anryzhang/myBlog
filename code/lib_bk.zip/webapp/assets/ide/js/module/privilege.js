/*
权限配置文件
所有权限点均配置在该文件中
 */
define(['jquery'],function($){

    var privilege = {};

	privilege={
		analysis:["runAnalysis","runAnalysisSchedule"],
		bre:["runDuplicationAnalysis"],
		checkstyle:["runCheckstyle","runCheckstyleSchedule"],
		translation:["runTranslationImmediately","runTranslationSchedule","viewTranslatedCode","viewSourceCode"],
		transformation:["runTransformationInit","runTransformationImmediately"],

		file:["newFile","openFile","closeCodeTabs","closeAllCodeTabs","save","refresh","exit"],

		edit:["undo","redo","selectAll","copy","cut","paste"],
		
		project:["newProject","editProject","editProjectTypeMapping"],
		newProject:["newProject"],
		editProject:["editProject","editProjectTypeMapping"],

		download:[],

		run:$.extend([],privilege.analysis,privilege.bre,privilege.checkstyle,privilege.translation,privilege.transformation),

		save:["save","saveAll"]

	};

	privilege.readOnly=(function(){
		var _privilege=["newFile","deleteFile","newFolder","editFileFolder","deleteFileOrFolder","deleteProject","addAnnotation","uploadSourceCode","shareProject"];

		_privilege.concat(privilege.project,privilege.edit,privilege.save);


		return _privilege;
	})();



	privilege.isSharedProjectForCurrentUser=(function(){
		var _privilege=["newFile","deleteFile","newFolder","editFileFolder","deleteFileOrFolder","deleteProject","uploadSourceCode","shareProject"];

		_privilege=_privilege.concat(privilege.project,privilege.analysis,privilege.checkstyle);

		
		return _privilege;
	})();



	return window.privilege = privilege;

});