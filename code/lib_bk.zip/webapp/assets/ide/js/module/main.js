//var main=(function(main,common,ide,$) {
//require(['ztreeCore','ztreeExedit'],function(){});

define(['jquery','ide','moduleCommon','cg','menu','privilege','repositoryService','menu'],function($,ide,common,cg,menu,privilege,repositoryService,menu){

    //selectors
    var main = {};
    var selectors = {
        repository: {
            container: "#ide-repository",
            currentTitle: "#current-repository-title",
            title: ".repository-title",
            panel: ".ide-repository-tree",
            toggleButton: "#repository-toggle-btn",
            chevronLeftIcon: "glyphicon-chevron-left",
            chevronRightIcon: "glyphicon-chevron-right",
            tools: ".ide-repository-tools",
            resizeHandler: "#resize-handler",
            J_porjectWorkSpace: "#J_porjectWorkSpace",
            ideRepositoryBody: '.ide-repository-body'
        },
        codeTab: {
            container: "#ide-code",
            tab: ".code-tab",
            list: "#code-tabs-list .dropdown-menu"
        },
        control: {
            menu: ".ide-control-menu",
            container: "#ide-control-panels",
            title: ".ide-control-panel-title",
            selectedClass: "ide-control-panel-title-selected",
            content: ".ide-control-panel",
            contentBody: ".panel-body-content",
            consoleClear: "#ide-console-clear",
            progressClear: "#ide-progress-clear",
            scheduleClear: "ide-schedule-clear",
            close: "#ide-control-toolbar",
            resizeHandler: ".resize-handler"
        },
        header: {
            menu: ".header-toolbar"
        },
        page: {
            page: "#other-page",
            ide: "#ide-page",
            iframe: "#other-page-iframe"
        }
    }, options;

    //加载workspace
    var loadingContainer=$("#J_loadingBox"),
        loadingImg=loadingContainer.find("#J_loading_img"),
        loadingMsg=loadingContainer.find("#J_loading_msg"),
        loadingWaiting=loadingContainer.find("#J_loading_waiting");
    main.loadWorkspace=function(){
        var flag=true;
        $(window).on("repositorycompleted codetabcompleted",function(){
            if(flag&&ide.status.repositorycompleted&&ide.status.codetabcompleted){
                setTimeout(function(){
                    clearInterval(timer);
                    main.loadWorkspaceCompleted();
                },1000);
                main.initSkin();
            }
        });

        //loadingMsg.html("Check your browser version");
        //检查浏览器版本
        if ($.browser.msie&&$.browser.version<10) {
            loadingMsg.removeAttr('style');
            loadingMsg.html('We are supporting IE10 or above on this version,<br/> it is recommended that you switch <br/>the brower to <a target="_blank" style="color:#859900" href="https://www.google.com/intl/en/chrome/browser/">Chrome</a> or <a style="color:#859900" target="_blank" href="http://www.mozilla.org/en-US/firefox/new/">Firefox</a> or <a style="color:#859900" target="_blank" href="http://www.opera.com/">Opera</a> or <a style="color:#859900" target="_blank" href="http://www.apple.com/support/mac-apps/safari/">Safari</a> for better user experience.');
            loadingImg.hide();
            flag=false;
            return ;
        }

        if(flag){
            //检查浏览器环境
            //loadingMsg.html("Check your browser environment");
            if(!window.localStorage){
                loadingMsg.html('Sorry,The browser version is too low, please upgrade your browser.');
                loadingImg.hide();
                flag=false;
                return;
            }
        }



        if(flag){
            
            var count=0;
            var timer=setInterval(function(){
                var str="";
                for(var i=0;i<count;i++){
                    str+=".";
                }
                count=(++count)%4;                
                loadingWaiting.html(str);
            },800);
            setTimeout(function(){
                clearInterval(timer);
                main.loadWorkspaceCompleted();
            },6000);

            main.initSkin();
        }
    }
    main.loadWorkspaceCompleted=function(){
        loadingContainer.fadeOut(400);
    }

    main.initSkin = function(){
        //初始化theme 菜单
        var J_theme = $('#J_theme'),
            J_themeItems = $('.J_themeItem'),
            _themeSelected = J_theme.attr('data-theme');
        if(_themeSelected){
            J_themeItems.find('li[data-theme="'+ _themeSelected  +'"]').addClass('circle').siblings().removeClass('cricle');
        }else{
            return ;
        }
    }

    /*
     初始化 header-toolbar
     注册header 事件
     */
    function initHeader() {
        var headerToolbar = $(selectors.header.menu);
        headerToolbar.on("click", "[data-service]", function () {
            var $this = $(this), service = $this.attr("data-service");
            main[service].call(this);
            //return false;
        });
    }


    /*other iframe page*/
    //currentPage 1:ide,2:otherpage
    var page = getPageUi(), currentPage = 1, _href;

    function getPageUi() {
        var ui = {};
        ui.page = $(selectors.page.page);
        ui.iframe = ui.page.find(selectors.page.iframe);
        ui.ide = $(selectors.page.ide);
        return ui;
    }

    main.showPage = function (href) {
        if (currentPage !== 2) {

            page.page.show();
            page.ide.hide();
            /*page.page.animate({
             left:"0%"
             },{
             //easing:"easeOutBack",
             "duration":500
             });*/

            currentPage = 2;
        }
        //if(href!=_href){
        page.iframe.attr("src", href);
        _href = href;
        //}

    };

    main.showIde = function () {
        if (currentPage !== 1) {
            currentPage = 1;

            /*page.page.animate({
             left:"100%"
             },{
             //easing:"easeOutBounce",
             "duration":500
             });*/
            page.ide.show();
            page.page.hide();

            page.ide.trigger("initialize");
        }
    }


    /* repository module */
    var repository = getRepositoryUi(), changeRepositoryDom, repositoryWidth = 240;
    //获取repository ui对象
    function getRepositoryUi() {
        var ui = {};
        ui.container = $(selectors.repository.container);
        ui.currentTitle = ui.container.find(selectors.repository.currentTitle);

        //ui.titles=ui.container.find(selectors.repository.title);
        //ui.panels=ui.container.find(selectors.repository.panel);

        ui.resizeHandler = ui.container.find(selectors.repository.resizeHandler);
        ui.toggleButton = $(selectors.repository.toggleButton);
        ui.toggleButtonIcon = ui.toggleButton.find("." + selectors.repository.chevronLeftIcon);

        //ui.tools=ui.container.find(selectors.repository.tools);
        return ui;
    }


    /*
     初始化repository
     */
    function initRepository() {

        repository.container.on("click", ".repository-title", function (e) {

            var $this = $(this), id = $this.attr("data-user");

            main.changeRepository(id);

            e.preventDefault();
        });

        var currentWorkspace = main.getCurrentWorkspace();
        if (!currentWorkspace) {
            main.changeRepository();
        }


        //repository.container.find(selectors.repository.title).eq(0).trigger("click");

        /*if(options.currentRepositoryType){
         main.changeRepository(options.currentRepositoryType);
         }*/
        /*resize repository panel*/
        repository.container.cgResize({
            handler: repository.resizeHandler,
            min: {
                width: 200
            },
            opacity: 1,
            max: {width: 900},
            cursor: "e-resize",
            iframeFix: true,
            direction: "e",
            resize: function (e, ui) {
                codeTab.container.css("margin-left", ui.currentSize.width);
                repositoryWidth = ui.currentSize.width;
               
            },
            stop:function(){
                //修改编辑器 resize 状态
            	$(window).trigger("editorresize");
            }
        });

        repository.toggleButton.click(function () {
            main.toggleRepository();
            //修改编辑器 resize 状态
            $(window).trigger("editorresize");
        });
        var timer;
        repository.toggleButton.hover(function () {
            clearTimeout(timer);
        }, function () {
            //$(this).hide();
        });


        repository.container.hover(function () {
            repository.toggleButton.show();
        }, function (e) {
            timer = setTimeout(function () {
                repository.toggleButton.hide();
            }, 100);
        });


        /*repository service*/

        repository.container.on("click", common.config.selectors.menu, function () {
            var $this = $(this), service = $this.attr("data-service");

            if ($this.data("disbaled") !== true && service) {
                main[service].call(this);
            }
        });
    }


    //隐藏显示repository panel
    main.toggleRepository = function () {
        if (!repository.toggleButton.data("hidden")) {
            repository.container.hide();
            codeTab.container.css("margin-left", 0);
            repository.toggleButton.data("hidden", true);
            repository.toggleButtonIcon.addClass(selectors.repository.chevronRightIcon).removeClass(selectors.repository.chevronLeftIcon);
            repository.toggleButton.show();
        } else {
            repository.container.show();
            codeTab.container.css("margin-left", repositoryWidth);
            repository.toggleButton.data("hidden", false);
            repository.toggleButtonIcon.addClass(selectors.repository.chevronLeftIcon).removeClass(selectors.repository.chevronRightIcon);
            repository.toggleButton.hide();
        }
    };
    /**
     * [changeRepository 改变当前repository]
     * @param  {[Number]} type [当前需要被改变的type值]
     */

    main.changeRepository = function (id) {
        var $this, index, currentRepositoryPanel;


        repository.titles = repository.container.find(selectors.repository.title);
        repository.panels = repository.container.find(selectors.repository.panel);
        if (id) {

            menu.disableMenus(privilege.isSharedProjectForCurrentUser)

            $this = repository.titles.filter("[data-user='" + id + "']");


            //如果share的项目取消share
            if (!$this.length) {
                main.changeRepository();
                return;
            }
            main.currentWorkspace = id;

        } else {

            main.currentWorkspace = null;

            menu.enableMenus(privilege.isSharedProjectForCurrentUser);
            $this = repository.titles.eq(0);
        }


        index = repository.titles.index($this);
        currentRepositoryPanel = repository.panels.eq(index);


        repository.currentTitle.html($this.text());
        currentRepositoryPanel.show().siblings().hide();
        //存储当前repository对象
        changeRepositoryDom = currentRepositoryPanel.find(".ide-repository-tree-box");

        //获取当前用户的workspace
        var user = changeRepositoryDom.attr("data-user");


        
        //判断是否已初始化workspace
        if (!currentRepositoryPanel.data("initialize")) {
            //初始化 repository
            repositoryService.init(changeRepositoryDom, {
                userId: user,
                setting: {
                    async: {
                        url: ""
                    },
                    view: {
                        fontCss: repository.getFontCss,
                        nameIsHTML: true,
                        selectedMulti: false,
                        addDiyDom: repositoryService.addDiyDom
                    },
                    callback: {
                        beforeExpand: repositoryService.beforeExpand
                    }
                }
            });

            //changeRepositoryDom.attr("src",$this.attr("data-src"));
            currentRepositoryPanel.data("initialize", true);
        } else {
            repositoryService.changeRepository(user);
        }
    };

    /*end repository module*/

    /*code tab module*/
    var codeTab = getCodeTabUi(), codeTabObject;

    function getCodeTabUi() {
        var ui = {};
        ui.container = $(selectors.codeTab.container);
        ui.contextMenu = $(common.config.selectors.codeTabContextMenu);
        ui.list = ui.container.find(selectors.codeTab.list);
        return ui;
    }

    //注册tab 右击事件
    function initTabContextMenu() {
       
        codeTab.container.on("contextmenu", selectors.codeTab.tab, function (e) {
            
            var $this = $(this), id = $this.attr("id"), tab = main.getCodeTabById(id);

            codeTab.contextMenu.data("tab", tab).css({
                left: e.pageX,
                top: e.pageY
            }).show();
            e.stopPropagation();
            e.preventDefault();
            return false;
        });


        codeTab.contextMenu.on("click", "[data-service]", function () {

            var $this = $(this), service = $this.attr("data-service"), serviceType = $this.attr("data-servicetype");

            main[service].call(this, codeTab.contextMenu.data("tab"));
        });
    }

    //初始化code tab
    function initCodeTab() {

        $.cgTab.defaults.tpl.tabHtml = '<li class="code-tab"><div class="ide-code-tab"><span id="edited"><span id="edited-flag">*</span> </span><span class="btn-title"></span><span class="glyphicon glyphicon-remove btn-role"></span></div></li>';
        $.cgTab.defaults.tpl.contentHtml = '<div class="ide-code-panel"></div>';
        codeTabObject = codeTab.container.cgTab({
            tabContainer: ".ide-code-tabs ul",
            tab: ".ide-code-tab",
            selectedClass: "code-tab-selected",
            contentContainer: ".ide-code-body",
            content: ".ide-code-panel"
        });

        // main.addCodeTab({
        // 	id:"123123",
        // 	"title":"",
        // 	"href":common.config.codeUrl
        // });

        //tab 右击事件
        initTabContextMenu();
        /*注册list 单击事件*/
        registerCodeList();

        //打开存储的tab
        openDefaultCodeTabs()
    }

    //打开默认存储的tab
    function openDefaultCodeTabs(){
		var storageCodeTabs=main.getStorageCodeTabs(),flag,currentTab,length
		if(storageCodeTabs&&(length=storageCodeTabs.length)){
			for(var i=0;i<length;i++){
				var tab=storageCodeTabs[i];
				var _tab=main.addCodeTab({
					id:tab.id,
					title:tab.title,
					domTitle:tab.domTitle,
					href:tab.href,
					//content:html,
					iframe:false,
					pId:tab.pId,
					projectId:tab.projectId,
					//initializeIframe:false,
					readOnly:tab.readOnly/*,
					beforeSelect:function(codeTab){
						if(flag){
							if(!codeTab.ui.tab.data("initializeIframe")){
								codeTab.getIframeWindow().location.href=codeTab.settings.href;
								codeTab.settings.initializeIframe=true;
								codeTab.ui.tab.data("initializeIframe",true);
							}
						}
					}*/
				});
			}
			flag=true;

			// 选中上一次默认选中的tab
			var _selectedCodeTab=main.getStorageSelectedCodeTab();
			_selectedCodeTab&&_selectedCodeTab.select();
			

            ide.status.codetabcompleted=true;
            $(window).trigger("codetabcompleted");
            
            
		}
	}


    //注册右侧
    //添加一个tab list
    var _hasCodeTab = false;

    function addTab(id, title) {
        $('<li data-id="' + id + '" id="code-tab-list-' + id + '"><a href="#">' + title + '</a></li>').appendTo(codeTab.list);

        if (!_hasCodeTab) {
            codeTab.list.removeClass("hide");
            _hasCodeTab = true;
        }
    }

    function deleteTab(id) {
        codeTab.list.find("#code-tab-list-" + id).remove();
        if (!codeTab.list.find("li").length) {
            _hasCodeTab = false;
            codeTab.list.addClass("hide");
        }
    }

    //update tab title
    function setTabTitle(title, id) {
        codeTab.list.find("#code-tab-list-" + id).find("a").html(title);
    }

    function registerCodeList() {
        //register code tab list handler
        codeTab.list.on("click", "li", function () {
            var $this = $(this);
            main.selectCodeTabById($this.attr("data-id"));
        });
    }


    //main.getCodeTabObject=function(){
    //	return codeTabObject;
    //};

    main.addCodeTab = function (opts) {
       
        var tab;
        if (opts.id) {
            tab = codeTabObject.getTabById(opts.id);
        }

        var _beforeSelect = opts.beforeSelect;

        var beforeSelect = function (codeTab) {
            if (_beforeSelect) {
                _beforeSelect.apply(codeTab, arguments);
            }
            
            //如果
            var _code=codeTab.code,_editorObject;
            if(_code){                
                var readOnly = _code.options.code.readOnly;
                //根据属性，禁用于启用菜单                
                if (readOnly) {
                    menu.disableMenus(privilege.edit.concat(["save"]));
                } else {
                    menu.enableMenus(privilege.edit.concat(["save"]));
                }


                //如果fileType == "PGM"
                //compile 
                if(main.getFocusObject() !== repositoryService){
                   
                }                
            }
        }
        var _opts = $.extend({}, opts);

        //选项卡在切换以后回调
        _opts.select=function(codeTab){
            var _code=codeTab.code,_editorObject,_aceEditor;
            if(_code){
                _editorObject=_code.getActiveEditor();
                _aceEditor=_editorObject.getAceEditor()
                if(_aceEditor){
                    _aceEditor.resize();
                    _editorObject.focus();
                }               
            }
        };

        _opts.beforeSelect = beforeSelect;
        opts = _opts;

		if(opts.iframe == void 0){
			opts.iframe=false;
		}
        opts.closeHandler = function (e, tab) {
            if (tab.changed) {
                ide.util.customConfirm(tab.settings.title + " has been modified,<br/>save changes?", function (e) {
                    tab.code.save(function () {
                        e.data.dialog.close();
                        deleteTab(tab.settings.id);
                        tab.close();
                    });
                }, function (e) {
                    e.data.dialog.close();
                    deleteTab(tab.settings.id);
                    tab.close();
                    tab=null;
                });
                return false;
            } else {
                deleteTab(tab.settings.id);
                tab=null;
            }
        };
        if (tab) {
            tab.select();
            return tab;
        } else {
            ide.util.showTips("Loading "+ opts.title);
            addTab(opts.id, opts.title);
            return codeTabObject.add(opts);
        }
    };

    //更新title
    main.updateCodeTabById = function (obj, id) {
        var tab = main.getCodeTabById(id);
        if (tab) {
            tab.title = obj.title;
            tab.setTitle(obj.title);
            setTabTitle(obj.title, id);
        }
    };


    main.closeCodeTab = function (tab, flag) {
        if (tab) {
            if (tab.changed && !flag) {
                ide.util.customConfirm(tab.settings.title + " has been modified,<br/>save changes?", function (e) {
                    tab.code.save(function () {
                        e.data.dialog.close();
                        deleteTab(tab.settings.id);
                        tab.close();
                    });
                }, function (e) {
                    e.data.dialog.close();
                    deleteTab(tab.settings.id);
                    tab.close();
                });
            } else {
                deleteTab(tab.settings.id);
                tab.close();
            }
        }
    };

    main.getCodeTabsByParams = function (params) {
        return codeTabObject.getTabsByParams(params);
    };


    main.closeCodeTabsByParams = function (params, flag) {
        if (params) {
            var tabs = main.getCodeTabsByParams(params), length;
            if (tabs && (length = tabs.length)) {
                for (var i = 0; i < length; i++) {
                    main.closeCodeTab(tabs[i], flag);
                }
            }
        }
    };

    main.closeCodeTabById = function (id, flag) {
        main.closeCodeTab(codeTabObject.getTabById(id), flag);
    };

    main.closeCodeTabByIds = function (ids, flag) {
        var length, tab;
        if (ids && (length = ids.length)) {
            for (var i = 0; i < length; i++) {
                tab = main.getCodeTabById(ids[i]);
                tab && main.closeCodeTab(tab, flag);
            }
        }
    };


    main.closeAllCodeTabs = function () {
        var tabs = $.extend([], codeTabObject.getAllTabs()), length = tabs.length;
        for (var i = 0; i < length; i++) {
            main.closeCodeTab(tabs[i]);
        }

    };

    //获取所有的code tabs
    main.getAllCodeTabs = function () {
        return codeTabObject.getAllTabs();
    };
    main.getCodeTabById = function (id) {
        return codeTabObject.getTabById(id);
    };

    main.getCurrentCodeTab = function () {
        return codeTabObject.getCurrentTab();
    };

    main.selectCodeTab = function (tab) {
        tab.select();
    }
    main.selectCodeTabById = function (id) {
        codeTabObject.selectTabById(id);
    };

    main.refreshCodeTab = function (tab) {
        tab.reload();
    };

    main.refreshCodeTabById = function (id) {
        main.refreshCodeTab(main.getCodeTabById(id));
    };


    main.closeOtherCodeTabs = function (tab) {
        var index = tab.getIndex(), tabs = $.extend([], codeTabObject.getAllTabs()), length = tabs.length;
        for (var i = 0; i < length; i++) {
            if (i !== index) {
                main.closeCodeTab(tabs[i]);
            }
        }
    };

    main.closeRightCodeTabs = function (tab) {
        var index = tab.getIndex(), tabs = $.extend([], codeTabObject.getAllTabs()), length = tabs.length;
        for (var i = index + 1; i < length; i++) {
            main.closeCodeTab(tabs[i]);
        }


    };
    main.closeLeftCodeTabs = function (tab) {
        var index = tab.getIndex(), tabs = $.extend([], codeTabObject.getAllTabs());
        for (var i = index - 1; i > -1; i--) {
            main.closeCodeTab(tabs[i]);
        }
    };


    /*设置codeTab edit modo*/
    main.updateCodeTabStatusById = function (id, edited) {
        var tab = main.getCodeTabById(id);
        if (edited) {
            tab.ui.tab.find("#edited-flag").show();
            //将tab的状态设置为true
            tab.changed = true;
        } else {
            tab.ui.tab.find("#edited-flag").hide();
            //将tab的状态设置为false
            tab.changed = false;
        }
    }


    main.getModifiedCodeTabs = function () {
        var tabs = main.getAllCodeTabs(), length, _tabs = [];
        if (tabs && (length = tabs.length)) {
            for (var i = 0; i < length; i++) {
                if (tabs[i].changed) {
                    _tabs.push(tabs[i]);
                }
            }
        }
        return _tabs;
    };

    main.hasModifiedFiles = function () {
        var tabs = main.getAllCodeTabs(), length;
        if (tabs && (length = tabs.length)) {
            for (var i = 0; i < length; i++) {
                if (tabs[i].changed) {
                    return true;
                }
            }
        }
        return false;
    };

    //save 当前选项卡
    main.save = function (tab, callback) {
        if (tab&&tab.code) {
            tab.code.save(callback);
        }
    }

    //save 当前选项卡
    main.saveAll = function (callback) {
        var tabs = main.getAllCodeTabs(), length, _savedFiles = [], _tabs = [];
        if (tabs && (length = tabs.length)) {
            for (var i = 0; i < length; i++) {
                if (tabs[i].changed) {
                    _tabs.push(i);
                    main.save(tabs[i], function () {
                        _savedFiles.push(i);

                        if (_savedFiles.length == _tabs.length) {
                            callback && $.isFunction(callback) && callback();
                        }
                    });
                }
            }
        }
    }

    /*end code tab module*/

    /*console&progress module*/
    var control = getControlUi(), consoleObject,controlHeight=200;
    function getControlUi() {
        var ui = {};
        ui.menus = $(selectors.control.menu);
        ui.container = $(selectors.control.container);
        ui.titles = ui.container.find(selectors.control.title);
        ui.contents = ui.container.find(selectors.control.content);

        ui.progressBody = ui.contents.eq(1).find(selectors.control.contentBody);
        ui.consoleClear = ui.container.find(selectors.control.consoleClear);
        ui.progressClear = ui.container.find(selectors.control.progressClear);
        
        ui.editorBody=$("#J_ide_code_body");
        ui.resizeHandler=ui.container.find(selectors.control.resizeHandler)
        ui.toggleBtn = ui.container.find("#J_toggle_control");

        ui.controlToolBtn=ui.container.find(".J_control_toolbtn");
        return ui;
    }



    //init control
    function initControl() {
        //init menus click handle
        /*control.menus.each(function (index) {
            $(this).click(function () {
                main.showControl();
                main.changeControl(index);
            });
        });*/
        
        control.titles.each(function (index) {
            $(this).click(function () {               
                if(!_controlVisible){
                    main.showControl();
                }else{                    
                    if(_currentControlIndex==index){
                        main.hideControl();
                    }
                }
                main.changeControl(index);
            });
        });

        //init close click handle
        control.toggleBtn.click(function () {
            var $this=$(this);
            if($this.hasClass("glyphicon-chevron-down")){
                //$this.removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
                main.hideControl();
            }else{
               // $this.addClass("glyphicon-chevron-down").removeClass("glyphicon-chevron-up");
                main.showControl();
            }
            
        });

        
        //resize control container
        control.container.cgResize({
            handler: selectors.control.resizeHandler,
            min: {
                height: 28
            },
            iframeFix: false,
            direction: "n",
            opacity: 1,
            cursor: "n-resize",
            resize: function (e, ui) {
                var height = ui.currentSize.height, left = height + 2,
                    _leftHeight=codeTab.container.height()-height;
                if(_leftHeight<=200){
                    height=_leftHeight+height-200;
                }

                //缓存默认高度
                controlHeight=height;

                $(this).css({
                    "height": height,
                    "top":"auto"
                });
                control.editorBody.css({
                    bottom:height
                });

                //触发 window resize 事件，改变编辑器尺寸
                $(window).trigger("editorresize");
                return false;
            }
        });


        //clear console
        control.consoleClear.click(function () {
            main.clearConsole();
        });


        //clear progress
        control.progressClear.click(function () {
            ide.util.Progress.removeAllProgresses();
        });

        consoleObject = new ide.util.Console(control.contents.eq(0).find(selectors.control.contentBody));
    }


    //add log info
    main.console = function (msg) {
        consoleObject.log(msg);
    };

    main.clearConsole=function(){
        consoleObject.clear();
    }


    /*
     添加进度条
     最新的进度条在上面
     */
    main.progress = function (name, options) {

        var html = $("<div></div>").prependTo(control.progressBody);
        options = options || {};
        return new ide.util.Progress(html, {
            id: options.id,
            name: name,
            type: options.type,
            defaultProgress: options.defaultProgress,
            defaultTimes: options.defaultTimes,
            complete: options.complete
        });
    };

    //显示所有未完成的进度条
    main.initProgress = function (options) {
        if (options.url) {
            ide.util.ajax({
                url: options.url,
                type: "get",
                success: function (d) {
                    var datas = d.data.json, data;
                    for (var i = 0, length = datas.length; i < length; i++) {
                        data = datas[i];
                        main.progress(data.name, {
                            id: data.id,
                            type: 1,
                            complete: JSON.parseJSON(data.complete)
                        });
                    }
                }
            });
        }
    }


    //schedule
    main.schedule = function (name, runDate, options) {
        var html = $("<div></div>").prependTo(control.scheduleBody);
        options = options || {};
        return new ide.util.Schedule(html, {
            id: options.id,
            name: name,
            runDate: new Date(runDate)
        });
    };

    //显示所有未完成的进度条
    main.initSchedule = function (options) {
        if (options.url) {
            ide.util.ajax({
                url: options.url,
                type: "get",
                success: function (d) {
                    var datas = d.data.json, data;
                    for (var i = 0, length = datas.length; i < length; i++) {
                        data = datas[i];
                        main.schedule(data.name, new Date(data.runDate), {
                            id: data.id
                        });
                    }
                }
            });
        }
    };


    var _currentControlIndex=0;
    //change control
    main.changeControl = function (index) {
        control.titles.eq(index).addClass(selectors.control.selectedClass).siblings().removeClass(selectors.control.selectedClass);
        control.contents.eq(index).show().siblings().hide();

        //切换相应的菜单
        control.controlToolBtn.hide().eq(index).show();

        //缓存当前选中的control
        _currentControlIndex=index;
    }

    //control 是否可见
    var _controlVisible=false;
    //show control
    main.showControl = function () {
         control.container.css({
            "height":controlHeight
        });
        control.editorBody.css("bottom",controlHeight);
        control.resizeHandler.show();
        control.toggleBtn.addClass("glyphicon-chevron-down").removeClass("glyphicon-chevron-up");
        $(window).trigger("editorresize");
        _controlVisible=true;
    };

    //hide control
    main.hideControl = function () {
        control.container.css({
            "height":28
        });
        control.editorBody.css("bottom",28);
        control.resizeHandler.hide();
        control.toggleBtn.removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
        $(window).trigger("editorresize");
        _controlVisible=false;
    };


    main.showConsole = function () {
        main.showControl();
        main.changeControl(0);
    }

    main.hideConsole = function () {
        main.hideControl();
    }

    main.showProgress = function () {
        main.showControl();
        main.changeControl(1);
    }

    main.hideProgress = function () {
        main.hideControl();

    }

    /*end console&progress module*/


    /*
     缓存tab与nodes状态
     */
    /*
     窗口被关闭或者刷新时缓存系统状态
     */
    function cacheStatus() {
        window.onbeforeunload = function () {
            var _tab = codeTabObject.getCurrentTab();

            storageStatus(false, getTabs(), _tab && _tab.settings.id, null, main.currentWorkspace);


        };

        //每隔10分钟发一次请求，将数据存起来
        setInterval(function () {
            var _tab = codeTabObject.getCurrentTab();

            storageStatus(true, getTabs(), _tab && _tab.settings.id, null, main.currentWorkspace);
        }, 3000);
        //600000
    }
    var getParamsByUrl=function(url){
        if(!url){
            url=window.location.href;
        }
        var params={},str=url.substr(url.indexOf("?")+1),
        str_ary=str.split("&");
        for(var i=str_ary.length-1;i>=0;i--){
            var param=str_ary[i].split("=");
            params[param[0]]=param[1];
        }
        return params;
    }
    var getUrlWithParams=function(url,params){
        var flag=false;
        if(params){
            if(url.indexOf("?")===-1){
                url+="?";
                flag=true;
            }
            var i=0;        
            for(var p in params){
                if(flag&&i==0){             
                }else{
                    url+="&";               
                }
                url+=p+"="+params[p]; 
                i++;
            }
        }
        return url;
    };

    //获取打开的tab
    function getTabs() {
        var _tabs = codeTabObject.getAllTabs(), tabs = [], tab, length;
        if (_tabs && (length = _tabs.length)) {
            for (var i = 0; i < length; i++) {


                var params=getParamsByUrl(_tabs[i].settings.href||_tabs[i].settings._href);
                delete params.startLine;
                delete params.endLine;
                delete params.startColumn;
                delete params.endColumn;

                var href=getUrlWithParams(common.config.rootUrl+"ide/code/",params);


                tabs.push({
                    id: _tabs[i].settings.id,
                    title: _tabs[i].settings.title,
                    domTitle: _tabs[i].settings.domTitle,
                    href: href,
                    pId: _tabs[i].settings.pId,
                    projectId: _tabs[i].settings.projectId,
                    readOnly: _tabs[i].settings.readOnly
                });
            }
        }
        return tabs;
    }

    //缓存tab与nodes
    function storageStatus(async, tabs, currentCodeTabId, nodes, currentWorkspace) {


        if (common.localStorage) {
            common.localStorage.setItem(common.username + "tabs", JSON.stringify(tabs || []));
            common.localStorage.setItem(common.username + "selectedcodeid", currentCodeTabId);
            common.localStorage.setItem(common.username + "nodes", JSON.stringify(nodes || []));

            common.localStorage.setItem(common.username + "currentworkspace", currentWorkspace || "");


            /*//将数据存储在数据库中
             ide.util.ajax({
             url:"",
             async:async,
             type:"post",
             data:JSON.stringify({
             tabs:tabs||[],
             selectedcodeid:currentCodeTabId,
             currentworkspace:currentWorkspace||""
             }),
             success:function(data){

             }
             });*/

        }
    }

    //获取当前workspace
    main.getCurrentWorkspace = function () {
        return common.localStorage.getItem(common.username + "currentworkspace");

    }

    //获取缓存的code tab
    main.getStorageCodeTabs = function () {

        if (common.localStorage) {
            var tabs = common.localStorage.getItem(common.username + "tabs");
            if (tabs) {
                return JSON.parse(tabs);
            }
        }
        return [];
    };

    main.getStorageSelectedCodeTab = function () {
        if (common.localStorage) {
            var id = common.localStorage.getItem(common.username + "selectedcodeid");
            if (id) {
                return main.getCodeTabById(id);
            }
        }
    };

    //获取缓存的nodes
    main.getStorageNodes = function () {
        if (common.localStorage) {
            var nodes = common.localStorage.getItem(common.username + "nodes");
            if (nodes) {
                return JSON.parse(nodes);
            }
        } else {
            return [];
        }
    }



    //搜索文件
	//
	//var main.searchFile.dialog;
	main.searchFile=function(options){

        options=$.extend({
            title:"Search File",
            okButtonText:"Ok"    
        },options);
		
        require(['searchFile'],function(searchFile){
            var okButton={
                text:options.okButtonText,
                handler:function(e){
                    if(searchFile.getSelectedFiles){
                        var service=repositoryService,files=searchFile.getSelectedFiles(),length=files&&files.length;
                        if(length){
                            //如果有回调函数
                            if(options.handler&&$.isFunction(options.handler)){
                                options.handler.call(this,e,files);
                            }else{
                                for(var i=0;i<length;i++){
                                    service.openItemById(files[i].id);
                                }
                                dialog.hide();      
                            }
                        }else{
                            ide.util.alert("Please select files.",null,3);
                        }
                    }
                }
            },cancelButton={
                text:ide.i18n.dialogCancelButtonText,
                handler:function(e){
                    dialog.hide();
                }
            },dialog=main.searchFile.dialog;

    		if(typeof options.pId !="undefined"){
    			if(dialog){
    				dialog.show();
                    
                    //设置 dialog title
                    dialog.setTitle(options.title);

                    dialog.removeButton(0);
                    dialog.removeButton(0);
                    dialog.addButtons([okButton,cancelButton]);
                    
                    searchFile.setMax(options.max);
    				searchFile.focusSearchInput();
    				searchFile.setPid(options.pId);
    			}else{
    				dialog = main.searchFile.dialog = ide.util.dialog({
    					title:options.title,
    					width:600,
    					height:480,
    					iframe:false,
    					modal:true,
    					href:common.config.rootUrl+"page/search_file.html",
    					closeHandler:function(){
    						dialog.hide();
    						return false;
    					},
    					buttons:[okButton,cancelButton],
    					//页面加载完成以后
    					success:function(){
                            searchFile.init(options.pId,options.keyword,options.max);
    					}
    				});
    			}
    		}else{
    			var ids=repositoryService.getSelectedFolderIds(),length
    			if(ids&&(length=ids.length)){
    				main.searchFile({
                        pId:ids.join(",")
                    });
    			}else{
    				ide.util.alert(ide.i18n.repository.needSelectFolder,null,3);
    			}
    		}
        });
	};

	main.dashboard=function(){
		var service=repositoryService;
		var items=service&&service.getSelectedItems();
		if(items&&items[0]){
			main.showPage(common.config.rootUrl+"manager?projectId="+(items[0].projectId||""));	
		}else{
			main.showPage(common.config.rootUrl+"manager");
		}
	}

	main.idePage=function(){
		main.showIde();
	}

	main.modifyPassword= function(){
		var url = common.config.rootUrl +"ide/modifypassword";
		main.modifyPassword.dialog=ide.util.dialog({
			iframe:false,
			title:"Modify Password",
			href:url,
			resizable:false,
			width:500,
			height:340,
			modal:true
		},function(e){
			main.modifyPassword.submit&&main.modifyPassword.submit();
		});
	}

	main.feedback= function(){
		var url = common.config.rootUrl +"ide/feedback";
		main.feedback.dialog=ide.util.dialog({
			iframe:false,
			title:"Feedback",
			height:375,
			width:585,
			href:url,
			resizable:false,
			modal:true
		},function(e){
			if(main.feedback.commitComments){
				main.feedback.commitComments();
			}
			
		});
	}

	main.coloration= function(){
		var url = common.config.rootUrl +"ide/coloration";
		var dialog=ide.util.dialog({
			iframe:false,
			title:"Coloration",
			href:url,
			width:613,
			height:210,
			resizable:false,
			modal:true
		});
	}




    main.init = function (opts) {
        var f = function () {
            main.loadWorkspace();
            /*if ($.browser.msie) {
                ide.util.alert('We are not fully supporting IE on this<br/> version, it is recommended that you switch <br/>the brower to <a target="_blank" style="color:#859900" href="https://www.google.com/intl/en/chrome/browser/">Chrome</a> or <a style="color:#859900" target="_blank" href="http://www.mozilla.org/en-US/firefox/new/">Firefox</a> for better user experience.', null, 3);
            }*/
            options = opts;
            initRepository();
            initCodeTab();

            //init control module
            initControl();

            //初始化 work space
            initWorkspace();
            //缓存tab
            cacheStatus();
        };

        var hash = document.location.hash;
        //初始化dashboard
        if (hash == "#dashboard") {
            main.showPage(common.config.rootUrl + "manager");
            //初始化header
            initHeader();
            //注册ide的initialize事件
            page.ide.one("initialize", function () {
                f();
            });
        } else {
            initHeader();
            f();

            //注册menu 事件
            menu.registerMenu();
        }

        require(["history"],function(History){
            main.history=new History();

            menu.disableMenus(['historyBack','historyForward']);

            /*main.history.add({
                fileId:"c217eb28-c6e7-4fda-9fa5-57fdea751848",
                scrollTop:100,
                row:28,
                column:10
            }).add({
                fileId:"9e5a473f-fa12-43d2-930e-4a3a662cdbf3",
                scrollTop:400,
                row:150,
                column:0
            }).add({
                fileId:"d35d9d25-f197-4109-ab65-77d62f3561a5",
                scrollTop:300,
                row:50,
                column:6
            })*/
        });
    };

    //获取repository 当前window
   /* main.getRepositoryWindow = function (type) {

        return window;
        if (type) {
            return ui.panels.eq(type - 1).find("iframe")[0].contentWindow;
        } else {
            return changeRepositoryDom[0].contentWindow;
        }

    };*/

    //获取code 当前window
    /*main.getCodeWindow = function (id) {
        var tab;
        if (id) {
            tab = codeTabObject.getTabById(id);
            if (tab) {
                return tab.getIframeWindow();
            }
        } else {
            tab = codeTabObject.getCurrentTab();
            if (tab) {
                return tab.getIframeWindow();
            }
        }
    };*/

    main.getCodeById = function (id) {
        var tab;
        if (id) {
            tab = codeTabObject.getTabById(id);
            if (tab) {
                return tab.code;
            }
        } else {
            tab = codeTabObject.getCurrentTab();
            if (tab) {
                return tab.code;
            }
        }
    };
    main.getActiveCode = function () {
        var tab;
        tab = codeTabObject.getCurrentTab();
        if (tab) {
            return tab.code;
        }
    };

    function initWorkspace() {
        var href = common.config.rootUrl + 'ide/workspaceList';
        ide.util.ajax({
            type: 'get',
            dataType: 'json',
            url: href,
            data: '',
            success: function (rs) {
                if (rs.status === '200') {
                    var wsData = rs.data.json;
                    var ws_itemsHtml = '';
                    var ws_items = '';

                    var treeHtml = '';
                    var treeItems = '';

                    for (var i = 0; i < wsData.length; i++) {
                        ws_items += '<li><a data-user="'
                            + wsData[i].userId + '" class="repository-title" href="#">' + wsData[i].workspaceName + '</a></li>';

                        treeItems += '<div class="ide-repository-tree"><ul id="' + wsData[i].userId + '" data-user="' + wsData[i].userId + '" class="ztree ide-repository-tree-box"></ul></div>';
                    }

                    ws_itemsHtml = ws_items;
                    treeHtml = treeItems;
                    $(selectors.repository.J_porjectWorkSpace).append(ws_itemsHtml);
                    $(selectors.repository.ideRepositoryBody).append(treeHtml);


                    var currentWorkspace = main.getCurrentWorkspace();
                    if (currentWorkspace) {
                        main.changeRepository(currentWorkspace);
                    }

                }

            }
        });

    }


    //获取当前获取焦点的code
    main.focusObject = null;
    main.getFocusObject = function () {
        return main.focusObject;
    }
    main.setFocusObject = function (obj) {
        main.focusObject = obj
    }


    /*
     comet 长连接
     */
    if (JS && JS.Engine) {
        JS.Engine.on({

            //{message:"输出信息",type:}
            //type:1 info
            //type:2 warning
            //type:3 error
            Channel_Console: function (data) {
                var json = eval("(" + data + ")");
                if (json.type == 2) {
                    ide.util.log.w(json.message);
                } else if (json.type == 3) {
                    ide.util.log.e(json.message);
                } else {
                    ide.util.log.i(json.message);
                }

            },
            //{progress:60,id:}
            Channel_ProgressBar: function (data) {
                data = $.parseJSON(data);

                if (data.status && data.status == '200') {
                    if (data && data.progress) {
                        //var number=parseFloat(data.progress);
                        var progress = ide.util.getProgress(parseInt(data.progressId));
                        if (progress) {
                            if (data.progress < 100) {
                                progress.update(data.progress, 6000);
                            } else {
                                progress.complete(100, 500);
                                //upload project时,分析代码
                                var sourceCode = repositoryService.getSourceCode();
                                var nodes = sourceCode.getItemById(data.projectId,null);
                                if(nodes[0].operateMap.UploadProject == true){
                                    var aObj = $('#' + nodes[0].tId + '_a');
                                    var abTarget = ide.config.icon.analysis;
                                    if(!aObj.has('.J_AIcon').length){
                                        aObj.append(abTarget);
                                        nodes[0].operateMap.SourceCodeComplete = true;
                                        nodes[0].operateMap.transformation = true;
                                        nodes[0].operateMap.SystemAnalysis = true;
                                    }
                                    //sourceCode.updateItem(nodes[0]);
                                    sourceCode.updateNodeData(nodes[0]);
                                }

                            }
                        }
                    }
                } else {
                    var progress = ide.util.getProgress(parseInt(data.progressId));
                    progress && progress.error();
                    ide.util.alert(data.message, null, 2);
                    //alert(data.message);
                }

            },
            Channel_Schedule: function (message) {
                setTimeout(menu.schedule && menu.schedule.reload && menu.schedule.reload(), 1000);
            },
            Channel_Prompt: function (data) {
                data = $.parseJSON(data);
                if (data.status && data.status == '200') {
                    //如果是code audit 而且成功
                    //启用菜单
                    if (data.type == 1) {
                        ide.util.hideTips();
                        menu.enableMenus(["runCheckstyle"]);
                        //$("#J-code-audit").removeClass("icon-loading").find(".fa").addClass("fa-user-md").removeAttr("style");
                    }else if(data.type == 4){
                        //显示A B 快捷菜单
                            var sourceCode = repositoryService.getSourceCode();
                            var nodes = sourceCode.getItemById(data.projectId,null);
                            var aObj = $('#' + nodes[0].tId + '_a');
                            var abTarget = ide.config.icon.analysis;
                            if(!aObj.has('.J_AIcon').length){
                                aObj.append(abTarget);
                                nodes[0].operateMap.SourceCodeComplete = true;
                                nodes[0].operateMap.transformation = true;
                            }
                            //sourceCode.updateItem(nodes[0]);
                            sourceCode.updateNodeData(nodes[0]);

                    }
                    ide.util.alert(data.msg, null, 1);
                } else {
                    ide.util.alert(data.msg, null, 2);
                }
            }
        });
        JS.Engine.start(common.config.cometUrl);
    }

    return window.main = main;

});
//
//})(main||{},common,ide,jQuery);