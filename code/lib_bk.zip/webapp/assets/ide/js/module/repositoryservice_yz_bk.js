var repositoryService = (function(repositoryService, ide, $) {
	"use strict";

	var repositoryWindow,
        repository,
        sourceCode,
        options;
	var pageNo = 0,
		pageSize = 50,
		mainWindow = common.getMainWindow(),
        contextMenu = mainWindow.jQuery(common.config.selectors.repositoryContextMenu),
		main = mainWindow.main;
	var needUploadorCheckout = ide.i18n.repository.needUploadorCheckout;
	var needAnalysis = ide.i18n.repository.needAnalysis;
	var needSelectFile = ide.i18n.repository.needSelectFile;
	var needSelectFolder = ide.i18n.repository.needSelectFolder;
	var needSelectProject = ide.i18n.repository.needSelectProject;
	var deleteProjectConfirm = ide.i18n.repository.deleteProjectConfirm;
	var deleteConfirm = ide.i18n.repository.deleteConfirm;

    //数据请求接口
    var app = {
        //初始化
        transformationInit: common.config.rootUrl + "transformationConfig/initDirectory",
            //'assets/data/repository/iniTransformation/tree.json',
        //run script files
        runtransformation: common.config.rootUrl + "transformationConfig/scriptFileList/validate",
        // 'assets/data/repository/runTransformation/file.json',
        runTransformationScript: common.config.rootUrl + "ide/findFileById",
        transformationOutput: common.config.rootUrl + "ide/transformation/runScript"
            //'assets/data/repository/runTransformation/Output.json'
    }

	//初始化Repository 
	//输入: element  jquery Dom节点
	//		arg    ztree 参数
	repositoryService.init = function(element, arg, flag) {
		repository = common.getRepositoryWindow().repository;
		options = arg;
		if (!repository.getContextMenu().data("initialize")) {
			initContextMenu(options.type);
			initSearch();
			repository.getContextMenu().data("initialize", true);
		}
		extendOptions(options);
		//if flag is not true ->get all projects
		//if flag is true -> add a new projects into empty tree
		if (!flag) {
			var href = common.config.codeUrl + "../../../loadProjectFileStructure";
			$.ajax({
				dataType: 'json',
				url: href,
				type: 'GET'
			}).done(function(data, textStatus, jqXHR) {
				options.nodes = data;
				sourceCode = new ide.repository.SourceCode(element, options);
                repositoryService.beforeunload();
			});
		}
		// 储存当前操作的窗口
		$(document).on("focusin",function(){
			common.getMainWindow().main.setFocusWindow(window);
		});

		sourceCode = new ide.repository.SourceCode(element, options);
	};


	// return sourceCode for other services
	repositoryService.getSourceCode = function() {
		if (typeof(sourceCode)=="undefined") {
			return null;
		} else {
			return sourceCode;
		}

	}

	// add hide class and remove show class  into rightClick Menu 
	function hideContextMenu (){
		// Example of Content
		//repository = common.getRepositoryWindow().repository;
		//var content = repository.getContextMenu().find("li");
        //debugger;
		for (var j = 0; j < arguments.length; j++) {
			var content = arguments[j];
			for (var i = 0; i < content.length; i++) {
				if (jQuery(content[i]).find(".hide").length == 0) {
					if (jQuery(content[i]).find(".show")) {
						jQuery(content[i])
							.removeClass("show")
							.addClass("hide");
					} else {
						jQuery(content[i]).addClass("hide");
					}
				}
			}
		}
		
	}


	// add show class and remove hide class  into rightClick Menu 
	function showContextMenuItems(){
		for(var i=0;i<arguments.length;i++){
			repository = common.getRepositoryWindow().repository;
			repository.getContextMenu()
						.find(arguments[i])
						.parent()
						.removeClass("hide")
						.addClass("show");
		}
	
	}

	// remove hide class  into rightClick Menu 
	function removeHideContextMenuItems(){
		for(var i=0;i<arguments.length;i++){
			repository.getContextMenu()
						.find(arguments[i])
						.parent()
						.removeClass("hide")
		}	
	}



	function extendOptions(options) {
		repository = common.getRepositoryWindow().repository;
		var contextMenuTop = 123; //右键菜单默认top

        //console.log(options);
		options.rightClick = function(e, data) {
			var height = common.getMainWindowHeight();
			repository.getContextMenu().data("data", data);

            var allNodes;
            var allNodesId = [];
            var nodesLen =  repositoryService.getSelectedItems().length;
            //菜单选择器配置
            var selector =repository.getSelectors();

            if(nodesLen < 1){
                allNodes = data;
                allNodesId.push(allNodes.id);
            }else{
                allNodes =  repositoryService.getSelectedItems();
                for(var i = 0; i < allNodes.length; i++){
                    allNodesId.push(allNodes[i].id);
                }
            }
            if(allNodesId.indexOf(data.id) > -1){
                //true为右键多选功能
                sourceCode.selectItem(data,false);
            }else{
                sourceCode.selectItem(data,false)
            }

            //console.log(data);
				//if this node is root then
			if (data.operateMap && data.operateMap.NewProject && data.operateMap.NewProject!=null){
				// the contextMenu shows 
				// 1. Check out
				// 2. Edit project
				// 3. Delete Project
				// 4. Download
				// 5. BRE
				// 6. Translation
				// 7. Transformation
				if(data.operateMap.CheckoutProject||data.operateMap.UploadProject || data.operateMap.MainframeProject){
					//if  project has been check out
					var content = repository.getContextMenu().find("li");
					hideContextMenu(content);
//					var selector =repository.getSelectors();

                    if(data.operateMap.MainframeProject){
                        showContextMenuItems(
                            selector.editProject,
                            selector.bre,
                            selector.translation,
                            selector.transformation,
                            selector.delProject
                        );
                    }else{
                        showContextMenuItems(
                            selector.editProject,
                            //selector.checkout,
                            //selector.download,
                            selector.bre,
                            //selector.team,
                            //selector.update,
                            //selector.commit,
                            //selector.revert,
                            //selector.showHistory,
                            selector.upload,
                            selector.translation,
                            selector.transformation,
                            selector.analysis,
                            selector.delProject
                        );
                    }
			
					removeHideContextMenuItems(
						selector.breConfig,
						selector.runBreI,
						selector.runBreS,
						selector.runDuplicationAnalysis,
						selector.TLConfig,
						selector.runTLI,
						selector.runTLS,
						selector.TFConfig,
						selector.runTFI,
						selector.runTFS,
						selector.runANAI,
						selector.runANAS,
						selector.editProjectBasicInfo,
						selector.fileTypeMapping
						);
					
					}else{
					//if projcet has not been check out
					//only show check out in the contextmenu
					var content = repository.getContextMenu().find("li");
					hideContextMenu(content);				
					showContextMenuItems(
                        //selector.checkout,
						selector.upload,
						selector.delProject,
						selector.editProject);
					removeHideContextMenuItems(
						selector.editProjectBasicInfo,
						selector.fileTypeMapping)
					}

                sourceCode.selectItem(data,false)
					

			}else{
                //不是根节点时,是不是文件夹.
				if(data.isParent){
					// if right click item is folder 
					// the contextMenu shows 
					// 1. Add Folder
					// 2. Add File
					// 3. Update
					// 4. Edit 
					// 5. Delete
					// 6. Commit
					// 7. COPY
					// 8. Paste
					// 9. Download
					var content = repository.getContextMenu().find("li");
					hideContextMenu(content);
//					var selector =repository.getSelectors();
                    //tree json 数据要增加 operateMap.isRevert字段来判断节点是否已经加入过版本库

                    var _data = {
                        operateMap:{
                            isRevert:true
                        }
                    };
                    $.extend(data,_data);

                    //更据是否有版本控制参数显示右键菜单,根节点的子节点文件夹不能手动删除
                    //console.log(data.pId,data.projectId);
                    if(data.pId == data.projectId){
                        //console.log('是根节点,不能删除')
                        showContextMenuItems(
                            selector.addFile,
                            selector.addFolder,
                            //selector.team,
                            //selector.update,
                            //selector.commit,
                            //selector.revert,
                            //selector.showHistory,
                            //selector.del,
                            selector.copy,
                            selector.paste
                            //selector.download
                        )
                    }else{
                        isRevertFolderShowTeam(data,selector,allNodesId.length);
                    }

				}else{
					// if right click item is file 
					// the contextMenu shows 
					// 1. Update
					// 2. Edit 
					// 3. Delete
					// 4. Commit
					// 5. COPY
					// 6. Paste
					// 7. Download
					var content = repository.getContextMenu().find("li");
					hideContextMenu(content);
//					var selector =repository.getSelectors();
                    //tree json 数据要增加 operateMap.isRevert字段来判断节点是否已经加入过版本库
                    //每个节点要新加isRule来判断是否有run test 功能

                    var _data = {
                        operateMap:{
                            isRevert:true,
                            isRule: true //data.operateMap&&data.operateMap.isRule?true:false

                        }
                    };
                    $.extend(data,_data);
                    //更据是否有版本控制参数显示右键菜单
                    isRevertFileShowTeam(data,selector,allNodesId.length)


				};
			}

			var contextMenuHeight = common.getContextMenuHeight(repository.getContextMenu()) + 50;
			//repository.setContextMenuPosition(e.clientX, common.getContextMenuTop(e.clientY + contextMenuTop, contextMenuHeight, height));

            //repository.jsp 页面嵌入到main.jsp 中
            repository.setContextMenuPosition(e.pageX+10, common.getContextMenuTop(e.pageY+10 , contextMenuHeight, height));
			repository.showContextMenu();
			return false;
		};
		options.DBclick = function(e, data) {
			repository.getContextMenu().data("data", data);
			//console.log(data);
			// if click node is more....
			if (data&&data.role > 99) {
				repositoryService.getMore(data);
			} else {
				if (data&&!data.isParent) {
					openItem(data);
				}
			}

		};
	}
    //有版本控制参数的文件夹菜单显示Team
    function isRevertFolderShowTeam(data,selector,len){
        if(len > 1){
            if(data.operateMap && data.operateMap.isRevert === true){

                showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.del,
                    selector.copy,
                    selector.paste
                    //selector.download
                );
            }else{
                showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.commit,
                    selector.del,
                    selector.copy,
                    selector.paste
                    //selector.download
                );
            }
        }else{
            if(data.operateMap && data.operateMap.isRevert === true){
                showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                    //selector.download
                );
            }else{
                showContextMenuItems(
                    selector.addFile,
                    selector.addFolder,
                    //selector.team,
                    selector.commit,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                    //selector.download
                );
            }
        }


    }
    //有版本控制参数的文件菜单显示Team
    function isRevertFileShowTeam(data,selector,len){
        //console.log(data);
        if(len > 1){
            if(data.operateMap && data.operateMap.isRevert === true){
                showContextMenuItems(
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.paste
                    //selector.download
                );
            }else{
                showContextMenuItems(
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.commit,
                    selector.paste
                    //selector.download
                );
            }
        }else{
            /*if(data.operateMap && data.operateMap.isRevert === true){
                showContextMenuItems(
                    selector.runTest,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.update,
                    selector.commit,
                    selector.revert,
                    selector.showHistory,
                    selector.paste
                    //selector.download
                );
            }else */if(data.operateMap && data.operateMap.isRule === true){

                showContextMenuItems(
                    selector.runTest,
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    selector.paste
                )
            }else{
                showContextMenuItems(
                    selector.eidt,
                    selector.del,
                    selector.copy,
                    //selector.team,
                    selector.commit,
                    selector.paste
                    //selector.download
                );
            }
        }

    }

    //team更新代码
    /*逻辑:
     * 1.本地新建文件,新文件加入数据库,不加入版本库,
     *   本地删除后,数据库中删除. 相当于文件的删除新建的操作.
     *
     *   在commit后,数据库,版本库都会被加入,
     *   本地文件删除时,执行upddte操作,树节点中还会有此文件.
     *
     * 2.删除后,执行commit操作,数据库,版本库都会被删除.
     * */
    repositoryService.teamUpdate = function(){

        var node = sourceCode.getSelectedItem(),
            postData = [],
            href = common.config.rootUrl + 'assets/data/repository/team/team_update_file.json';

        for(var i = 0; i < node.length; i++){
            var arrData = {
                projectId: node[i].projectId,
                isParent: node[i].isParent,
                id: node[i].id/*,
                 isRevert: node[i].operateMap.isRevert*/
            }
            postData.push(arrData);
        }
        //调用接口
        var isSaveFullFiles = common.getMainWindow().main.hasModifiedFiles();

        if(isSaveFullFiles){
            //文件没保存
            common.getMainWindow().main.saveAll(function(){
                ide.util.ajax({
                    url:href,
                    type:'get',
                    data:JSON.stringify(postData),
                    success:function(rs){
                        if(rs.status === 200){
                            ide.util.tips(rs.message,1500);

                        }else{
                            ide.util.alert(rs.message,null,2);
                        }

                    }
                });

            });


        }else{
            ide.util.ajax({
                url:href,
                type:'get',
                data: JSON.stringify(postData),
                success:function(rs){
                    if(rs.status === 200){
                        sourceCode.updateItem(node);
                        ide.util.alert(rs.message,null);
                    }else{
                        ide.util.alert(rs.message,null,2);
                    }
                }
            });
        }
    }
    //team提交代码
    repositoryService.teamCommit=function(){
        var node = sourceCode.getSelectedItem(),
            projectId;

        if (node && node.length) {
            projectId = node[0].projectId;
            if (projectId) {
                var dialog = repositoryService.teamCommit.dialog = common.getMainWindow().ide.util.dialog({
                    title: "commit",
                    href: common.config.rootUrl + "page/team_commit.html",
                    iframe: false,
                    width: 600,
                    height: 500,
                    modal: true,
                    buttons:[{
                        text:"Commit",
                        handler:function(e){
                            if(repositoryService.teamCommit.submit){
                                repositoryService.teamCommit.submit();
                            }
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }],
                    success:function(){
                        repositoryService.teamCommit.initCommit(node);
                    }
                });
            }
        } else {
            ide.util.alert(needSelectProject, null, 3);
        }
    }
    //team还原代码
    repositoryService.teamRevert = function(){
        var node = sourceCode.getSelectedItem(),
            projectId;
        if(node && node.length){
            projectId = node[0].projectId;
            if(projectId){
                var dialog = repositoryService.teamRevert.dialog = common.getMainWindow().ide.util.dialog({
                    title:'Revert',
                    href: common.config.rootUrl + "page/team_revert.html",
                    iframe:false,
                    width: 700,
                    height: 480,
                    modal: true,
                    buttons:[{
                        text:"Revert",
                        handler:function(e){
                            if(repositoryService.teamRevert.submit){
                                repositoryService.teamRevert.submit();
                            }
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }],
                    success:function(){
                        repositoryService.teamRevert.initRevert(node);
                    }
                })
            }
        }else{
            ide.util.alert(needSelectProject, null, 3);
        }
    }
    //显示历史信息
    repositoryService.teamShowHistory = function(){
        var node = sourceCode.getSelectedItem(),
            projectId;
        if(node && node.length){
            projectId = node[0].projectId;
            if(projectId){
                var dialog = repositoryService.teamShowHistory.dialog = common.getMainWindow().ide.util.dialog({
                    title:'Show History',
                    href: common.config.rootUrl + "page/team_showHistory.html",
                    iframe:false,
                    width: 700,
                    height: 480,
                    modal: true,
                    success:function(){
                        repositoryService.teamShowHistory.initShowHistory(node);
                    }
                })
            }
        }else{
            ide.util.alert(needSelectProject, null, 3);
        }
    }

    // runRule 事件
    repositoryService.runTest = function(){
        var node = sourceCode.getSelectedItem();

        if(node && node.length){
            repositoryService.selectFiles({pId:node[0].projectId},function(e,files){
               // console.log(e,files);
                var arrId = [];

                if(files&& files.length>0){
                    for(var i = 0;i < files.length; i++ ){
                        arrId.push(files[i].id);
                    }
                }else{
                    ide.util.tips('Please select a file!');
                    return false;
                }

                var runTestArg = {
                    projectId:node[0].projectId,
                    filesId:arrId,
                    id:node[0].id
                }
                //console.log(runTestArg);

                ide.util.ajax({
                    type:'post',
                    url:common.config.rootUrl + '/ide/transformation/runRule',
                    dataType:'json',
                    data:JSON.stringify(runTestArg),
                    success:function(rs){
                        //console.log(rs);
                    }
                });

                repositoryService.selectFiles.dialog.close();
            })
        }
    }


	//init search handle
	function initSearch() {
		var codeSearchBtn = repository.getUI().codeSearch;
		codeSearchBtn.on("click", "[data-service]", function() {
			var $this = $(this),
				service = $this.attr("data-service");
			repositoryService[service].call(this);
		});
	}

	//init contextmenu handle
	function initContextMenu() {
		repository.getContextMenu().on("click", "[data-service]", function() {
			var $this = $(this),
				service = $this.attr("data-service");
			repositoryService[service].call(this, repository.getContextMenu().data("data"));
		});
	}

	// search code 
	repositoryService.codeSearch = function() {
	}



	// function for repositorService openItem
	function openItem(data,params){
		if (typeof(data)!="undefined") {
			var OpenItemURL = common.config.codeUrl;
			OpenItemURL += "/?codeFileId=" + data.id;
			OpenItemURL += "&structureType=" + data.structureType;
			OpenItemURL += "&fileType=" + data.fileType;
			OpenItemURL += "&projectId=" + data.projectId;
			OpenItemURL += "&parentId=" + data.pId;
			if (!data.isParent) {
				if (params) {
					for (var key in params) {
						OpenItemURL += "&" + key + "=" + params[key];
					}
				}
				if (data.target == "_tab") {
					OpenItemURL = common.config.rootUrl + data.path;
				}
				var opt = {
					id: data.id,
					href: OpenItemURL,
					pId:data.pId,
					projectId:data.projectId,
					title: data.name
				}
				main.addCodeTab(opt);
			}

		} else {
			ide.util.alert(needSelectFile,null,3);
		}
		
	}


	// 打开树节点
	// params 双击时候 触发的URL 参数
	// 过度方法
	repositoryService.openItem = function(item,params) {
		 if(item&&item.length>0){
		 	openItem(item,params);
		 }else {
			ide.util.alert(needSelectFile,null,3);
		}
	}



	// 打开树节点
	// item 为数组
	// params 双击时候 触发的URL 参数
	// 过度方法
	repositoryService.openItems = function(item,params) {
		 // if(item.id.length==0){}
		 // if(item.structureType.length==0){}
		 // if(item.fileType.length==0){}
		 if(item&&item.length>0){
		 	for (var i = 0; i<item.length;i++){
		 		openItem(item[i],params);
		 	}
		 }else{
		 	var items = repositoryService.getSelectedFiles();
		 
		 	if(items.length>0&&items!=null){
		 	for (var i = 0; i<items.length;i++){
		 		openItem(items[i],params);
		 		}
		 	}else{
		 		ide.util.alert(needSelectFile,null,3);	
		 	}
		 }
	 }



	// 通过ID获取节点，打开树节点
	// 过度方法
	repositoryService.openItemById = function(id,params) {
		if (typeof(id)!="undefined") {
			var node = sourceCode.getItemById(id)
				//if the repository tree contain this node than open it by id
			if (node.length > 0) {
				openItem(node[0], params);
			} else {
				//if the repository tree not contain this node find it from database	
				var flag = false;
				var href = common.config.rootUrl + "ide/findFileById/" + id;
				$.ajax({
					dataType: 'json',
					url: href,
					type: 'GET'
				}).success(function(data, textStatus, jqXHR) {
					if (data != "") {
						openItem(data, params);
					} else {
						ide.util.alert(needSelectFile,null,3);
					}

				})

			}

		} else {
			ide.util.alert(needSelectFile,null,3);
		}
	};


	


	//获取选中的文件
	//
	repositoryService.getSelectedFiles=function(){
		var tree=repositoryService.getSourceCode(),
            files=tree.getSelectedItems();
		return _.filter(files,function(data,index){
			return !data.isParent;
		});
	}
	//获取选中文件的Id
	repositoryService.getSelectedFileIds=function(){
		var files=repositoryService.getSelectedFiles(),ids=[];
		for(var i=0,length=files.length;i<length;i++){
			ids.push(files[i].id);
		}
		return ids;
	}

	//获取选中的文件夹
	repositoryService.getSelectedFolders=function(){
		var tree=repositoryService.getSourceCode(),files=tree.getSelectedItems();
		return _.filter(files,function(data,index){
			return data.isParent;
		});
	}
	//获取选中文件夹的Id
	repositoryService.getSelectedFolderIds=function(){
		var folders=repositoryService.getSelectedFolders(),ids=[];
		for(var i=0,length=folders.length;i<length;i++){
			ids.push(folders[i].id);
		}
		return ids;
	}




	//获取树中的所有项目
	repositoryService.getAllItems = function(){
		return sourceCode.getAllItems();
	}

	//  add a project
	// 
	repositoryService.addProject = function(data) {
        var tree = repositoryService.getSourceCode();
		repository = common.getRepositoryWindow().repository;
		if (!sourceCode) {
			// add project 
			this.init(repository.getUI().treeId, {
				nodes: data.nodes,
				setting: {
					view: {
						fontCss: this.getFontCss,
						nameIsHTML: true
					},
					callback: {
						beforeExpand: repositoryService.beforeExpand,
						onAsyncSuccess: repositoryService.onAsyncSuccess,
						onAsyncError: repositoryService.onAsyncError
					}
				},
				type: 1
			}, true)

		} else {
			//initial project
			repository.addFolder(null, data.nodes[0], sourceCode);

			// var tree=sourceCode.getTree();
			var nodes = sourceCode.getAllItems();

			sourceCode.moveItem(nodes[0],nodes[nodes.length-1], "prev");

            //新建project 时,选中project 节点
            tree.selectItem(tree.getItemsByParam("id", data.nodes[0].id, null)[0],false);
		
		}
	}


	//update project
	repositoryService.updateProject = function(data) {
		if (typeof(data)!="undefined") {
				var selector = sourceCode.getSelectedItems();
				// if seleceted Item is not Root node. then get Root Node. 
				var node=getRootNode(selector[0]);
				if (!node) {
					ide.util.alert(needSelectProject, null, 3);
					return false;
				}
				node.name = data.nodes[0].name;
				sourceCode.updateItem(node);
		}
	}


	// new project
    repositoryService.newProject=function(){

        var dialog = repositoryService.newProject.dialog = common.getMainWindow().ide.util.dialog({
            title: "New Project",
            href: common.config.rootUrl + "page/main_newProject.html",
            iframe: false,
            width: 860,
            height:620,
            modal: true,
            buttons:[{
                text:"Save",
                handler:function(e){
                    if(repositoryService.newProject.submit){
                        repositoryService.newProject.submit();
                    }
                }
            },{
                text:ide.i18n.dialogCancelButtonText,
                handler:function(e){
                    e.data.dialog.close();
                }
            }],
            success:function(){
                repositoryService.newProject.initProject();
            }
        });
    };



	// edit project
	repositoryService.editProject = function() {
        var item = sourceCode.getSelectedItem(),
            projectId;
        if(item&&item.length){
            projectId= item[0].projectId;
            if(projectId){
                var dialog=repositoryService.editProject.dialog=common.getMainWindow().ide.util.dialog({
                    title:"Edit Project",
                    href: common.config.rootUrl + "page/edit_Project.html",
                    iframe: false,
                    width: 860,
                    height:620,
                    modal: true,
                    buttons:[{
                        text:"Save",
                        handler:function(e){
                            if(repositoryService.editProject.submit){
                                repositoryService.editProject.submit();
                            }
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }],
                    success:function(){
                        repositoryService.editProject.initProject();
                    }
                });
            }
        }else{
            ide.util.alert(needSelectProject,null,3);
        }

	}


	//upload source Code 
	repositoryService.uploadSourceCode =function(node){
        var id;
        if(typeof node === "string"){
            id = node;
        }else{
            node = getRootNode(node);
            if(!node){
                ide.util.alert(needSelectProject, null, 3);
                return;
            }
            id = node.projectId;
        }

		if(!id){
            return ;
        }
        var dialog=repositoryService.uploadSourceCode.dialog=common.getMainWindow().ide.util.dialog({
            title:"Upload",
            href: common.config.rootUrl + "ide/projects/upload/" + id,
            width:680,
            height:500,
            modal:true
        });

	}

	// update project status
	repositoryService.updateProjectStatus=function(projectId){
		if(projectId!=null&&projectId!=""){
			var href = common.config.rootUrl + "ide/getProjectOperateStatus/" + projectId;
			$.ajax({
				dataType:'json',
				url:href,
				type:'GET'
			}).success(function(data){
				var root = sourceCode.getItemById(data.id,null);
				root=$.extend(root[0],data);
				sourceCode.updateItem(root);	
			})
		}
	}


	//  source code check out function
	repositoryService.checkout = function(node) {
		if (typeof(node)!="undefined") {
			var href = common.config.rootUrl + "checkOutProject/" + node.projectId;
			$.ajax({
				dataType: 'json',
				url: href,
				type: 'GET'
			}).success(function(data) {
				if (data.status != "200") {
					ide.util.alert(data.message,null,2);
				} else {
					repositoryService.updateProjectStatus(node.projectId);
					// common.getMainWindow().ide.util.popupDialog({
					// 	href: common.config.rootUrl + "ide/fileTypeMapping/" + node.projectId + "/" + node.id,
					// 	width: 600,
					// 	height: 400
					// })
					
					// edit file type mapping 
					var dialog = repositoryService.editProjectTypeMapping.dialog = common.getMainWindow().ide.util.dialog({
						title: "File Type Mapping",
						iframe: true,
						href: common.config.rootUrl + "ide/fileTypeMapping/" + node.projectId + "/" + node.id,
						width: 500,
						height: 400,
						modal: true,
						closable: true,
						buttons: [{
							text: ide.i18n.dialogOkButtonText,
							handler: function() {
								var win = dialog.getIframeWindow();
								if (win && win.jQuery) {
									repositoryService.editProjectTypeMapping.submit && repositoryService.editProjectTypeMapping.submit();
								}
							}
						}, {
							text: ide.i18n.dialogCancelButtonText,
							handler: function(e) {
								e.data.dialog.close();
							}
						}]
					});
					
				}
			});
		} else {
			ide.util.alert(needSelectProject,null,2);
		}

	}


	// delete project
	// 过度方法
	repositoryService.deleteProject = function(node) {
		var mainWindow=common.getMainWindow(),
            main=mainWindow&&main;
		if(typeof(node)=="undefined"){
			node=sourceCode.getSelectedItems()[0];
		}
		if (typeof(node)!="undefined") {
			ide.util.confirm(deleteProjectConfirm, function(e) {
				var href = common.config.rootUrl + "ide/delete_project?projectId=" + node.projectId;
				$.ajax({
					dataType: 'text',
					url: href,
					type: 'POST'
				}).done(function(data) {
					if (data=="success") {
						sourceCode.deleteItem(node);
					
						parent.main&&parent.main.closeCodeTabsByParams({
							projectId:node.projectId
						},true);
						
						e.data.dialog.close();
					} else {
						ide.util.alert("Delete project failed",null,2);
					}
				});
			});
		} else {
			ide.util.alert(needSelectProject,null,3);
		}
	}


	//delete file or folder
	//过度方法
	repositoryService.deleteFileOrFolder = function(node){
		  // confirm information


        //右键删除多个文件
       /* var confirmContent = deleteConfirm;
        var selectItems = sourceCode.getSelectedItems();
        console.log(selectItems);
        if(selectItems.length>0){
            ide.util.confirm(confirmContent, function(e){
                for (var i = 0; i<selectItems.length;i++){
                    sourceCode.deleteItem(selectItems[i]);
                }
                e.data.dialog.close();
            });
        }else{
            ide.util.alert(needSelectFile,null,3);
        }*/

        var confirmContent = deleteConfirm;
		if (typeof(node)=="undefined") {
			node = sourceCode.getSelectedItems()[0];
		}
		if (node) {
			
            //if(node.operateMap){
            //如果删除的是项目
            if(node.id===node.projectId){
			// if it deletes project then change the confirm information into delete project confirm information
				confirmContent = deleteProjectConfirm;
			}
			ide.util.confirm(confirmContent, function(e) {
				deleteNode(node,true);
				e.data.dialog.close();
			});
		} else {
			ide.util.alert(needSelectFile,null,3);
		}


	
	}	
	//delete item by id
	repositoryService.deleteItemById = function(id) {
		if (typeof(id) != "undefined") {
			ide.util.confirm(deleteConfirm, function(e) {
				deleteNodeById(id);
			});
		} else {
			ide.util.alert(needSelectFile, null, 3);
		}
	}

	
	// 获取文件的父节点
	function getFolderByParentNode(node) {	
		var foldersId=new Array();
		if (node.children && node.children.length > 0) {
			foldersId.push(node.id);
			 for(var i =0;i<node.children.length; i++){
			 	if(node.children[i].isParent){
			 		//console.log(foldersId);
			 		foldersId=foldersId.concat(getFolderByParentNode(node.children[i]));
			 		//console.log(foldersId);
			 	}
			 }
			 return foldersId;		
		}

	}
	// flag : 是否删除树上节点。
	// flag true 删除树上节点
	// flag false 不删除树上节点。 
	function deleteNode(node, flag) {
        //console.log(node,flag);
		// node is a project node
        // ndoe.operateMap无法判断是项目文件夹
        // node.id===node.projectId
		if (node &&node.id===node.projectId) {
			var href = common.config.rootUrl + "ide/delete_project?projectId=" + node.projectId;
			$.ajax({
				dataType: 'text',
				url: href,
				type: 'POST'
			}).complete(function(data) {
				if (data.responseText == "success") {
					if (flag) {
						sourceCode.deleteItem(node);
					}

					//删除项目打开的文件
					main && main.closeCodeTabsByParams({
						projectId: node.projectId
					}, true);

				} else {
					ide.util.alert("Delete project failed", null, 2);
				}
			});
			return;
		}

		// node is a folder 
		if (node && node.isParent) {
			ide.util.ajax({
				url: common.config.rootUrl + "codefiles/deleteCodefiles/" + node.id,
				type: 'GET',
				success: function(data) {
					if (flag) {
						sourceCode.deleteItem(node);
					}

					var folderIds = getFolderByParentNode(node);
					for (var i = 0; i < folderIds.length; i++) {
						//删除项目打开的文件
						main && main.closeCodeTabsByParams({
							pId: folderIds[i]
						}, true);
					}
				}
			})
			return;
		}

		// node is a file 
		if (node) {
				ide.util.ajax({
					url: common.config.rootUrl + "codefiles/deleteCodefiles/" + node.id,
					type: 'GET',
					success: function(data) {
						if (flag) {
							sourceCode.deleteItem(node);
						}
						main && main.closeCodeTabById(node.id, true);
					}
				})
				return;
		}
	}

    //删除节点的Id
	function deleteNodeById (id){
			var node = sourceCode.getItemById(id)[0];
			if(node){
				//if the repository tree  contain this node
				deleteNode(node,true);
			}
			else{
				//if the repository tree not contain this node find it from database	
				var flag = false;
				var href = common.config.rootUrl + "ide/findFileById/" + id;
				$.ajax({
					dataType: 'json',
					url: href,
					type: 'GET'
				}).success(function(data, textStatus, jqXHR) {

					 if (data != "") {
					 	deleteNode(data,false);
					 	e.data.dialog.close();
					} else {
						ide.util.alert("Delete file not found.",null,2);
					}

				})

			}

	}

	//sourceCode.deleteItem方法根本就没有删除掉文件，请修正
	//而且，同一个删除接口，请统一调用
	repositoryService.deleteItems = function(item) {
		var confirmStr =deleteConfirm;

		if(item&&item.length>0){
		 	//if(item[0].operateMap){
            if(item[0].id===idem[0].projectId){
		 		confirmStr=deleteProjectConfirm;
		 	}
		 	ide.util.confirm(confirmStr,function(e){
		 		for (var i = 0; i<item.length;i++){
			 		deleteNodeById(item[i].id)
			 	}
			 	e.data.dialog.close();
		 	});		 	
		 }else{
		 	var selectItems = sourceCode.getSelectedItems();
		 	//if(item[0].operateMap){
            //删除的如果是项目
            if(selectItems&&(selectItems[0].id===selectItems[0].projectId)){
		 		confirmStr=deleteProjectConfirm;
		 	}
		 	if(selectItems.length>0){
		 		ide.util.confirm(confirmStr,function(e){
			 		for (var i = 0; i<selectItems.length;i++){
			 			deleteNodeById(selectItems[i].id)
			 		}
			 		e.data.dialog.close();
			 	});	
		 	}else{
		 		ide.util.alert(needSelectFile,null,3);	
		 	}
		 }
	 }
	

	//通过id数组删除文件
	repositoryService.deleteItemsByIds = function(ids) {
		if (ids) {
			ide.util.confirm(deleteConfirm, function(e) {
				for (var i = 0; i < ids.length; i++) {
					var node = sourceCode.getItemById(ids[i])
						//if the repository tree contain this node than open it by id
					var href = common.config.rootUrl + "codefiles/deleteCodefiles/" + ids[i];
					if (node.length > 0) {
						ide.util.ajax({
							url: href,
							type: 'GET',
							success: function(data) {
								var node = sourceCode.getSelectedItems();
								sourceCode.deleteItem(node);
							}
						})

					} else {
						//if the repository tree not contain this node find it from database	
						var flag = false;
						var href = common.config.rootUrl + "ide/findFileById/" + ids[i];
						$.ajax({
							dataType: 'json',
							url: href,
							type: 'GET'
						}).success(function(data, textStatus, jqXHR) {
							if (data != "") {
								var delHref = common.config.rootUrl + "codefiles/deleteCodefiles/" + data.id;
								ide.util.ajax({
									url: delHref,
									type: 'GET',
									success: function() {
										var node = sourceCode.getSelectedItems();
										sourceCode.deleteItem(node);
									}
								})
							} else {
								ide.util.alert("Delet file not found.",null,3);
							}

						})

					}
				}
			});
		} else {
			ide.util.alert("Delete files not found.",null,3);
		}
	}



	repositoryService.getMore = function(node) {
		ajaxGetNodes(node, node.pageNo, node.pageSize,node.userId,node.projectId);
	}

    //得到节点的父节点
	function getNodesByParentNode(treeNode, inputPageNo, inputPageSize, callback) {
		var postData = {};
		postData.userId = treeNode.userId;
		postData.projectId = treeNode.projectId;
		postData.pageSize = inputPageSize;
		postData.pageNo = inputPageNo;

		if(treeNode.moreId){
			postData.nodeId = treeNode.moreId;
		}else{
			postData.nodeId = treeNode.id;
		}
		var nodes = -1;
		var href = common.config.rootUrl + 'loadNodesByParentId';
		$.ajax({
			dataType: 'json',
			url: href,
			contentType: 'application/json',
			type: 'POST',
			data: JSON.stringify(postData)
		}).done(function(data, textStatus, jqXHR) {
			callback && callback.call(this, data);
			//nodes =data
		});
	}

    //页面重载前事件
    repositoryService.beforeunload = window.onbeforeunload = function(){
        repositoryService.getNodeOpenStatus();
    }

    //获取已经打开树的状态
    repositoryService.getNodeOpenStatus = function(){
        var node = sourceCode.tree.getNodes(),
            nodes = sourceCode.getOpenItemsByFilter(function(node){
            return (node.open === true);
        });

        var openNodes = [];
        for(var i = 0; i < nodes.length; i++){
            var openId = {
                id:nodes[i].id
            }
            openNodes.push(openId);
        }
        return openNodes;
    }

    //点击节点,发送是否打开节点,true ,false
    function updateNodeOpenStatus(treeNode){
        var postData={}
            postData.isOpen = (treeNode.open === true ? false : true);
            postData.projectId =treeNode.projectId;
            postData.id=treeNode.id;
        var href = common.config.rootUrl + 'loadNodesByParentId';
        $.ajax({
            dataType: 'json',
            url: href,
            contentType: 'application/json',
            type: 'POST',
            data: JSON.stringify(postData)
        }).done(function(data, textStatus, jqXHR) {
            //callback && callback.call(this, data);
            if(!data.status ==  200){
                ide.util.alert(data.msg,null,3);
            }
            //nodes =data
        });
       }

	function ajaxGetNodes(treeNode, inputPageNo, inputPageSize) {
		getNodesByParentNode(treeNode, inputPageNo, inputPageSize, function(nodes) {
			if (nodes.nodes != null) {
				if (nodes.pageNo + 1 < nodes.totalPageSize) {
					// more nodes
					var clickMore = {
						//"nodeId": "click_more_00123",
						"name": "more...",
						"id": nodes.nodes[0].id+123,
						"pageNo": nodes.pageNo + 1,
						"pageSize": nodes.pageSize,
						"userId": nodes.nodes[0].userId,
						"projectId": nodes.nodes[0].projectId,
						"role": 200,
						"moreId":nodes.nodes[0].pId,
						"icon":ide.config.icon.more

					};

					//console.log(clickMore);
					nodes.nodes.push(clickMore);
					//treeNode is parent node , nodes is append nodes		
				}
					if (treeNode.role) {
						sourceCode.addItem(treeNode.getParentNode(), nodes.nodes);
						sourceCode.deleteItem(treeNode);
					} else {
						sourceCode.addItem(treeNode, nodes.nodes,false);
					};


			}
			//callback

		});
	}
	//before expand node
    //扩展打开节点事件
	repositoryService.beforeExpand = function(treeId, treeNode) {

		if (!treeNode.isExpanded) {
			ajaxGetNodes(treeNode, pageNo, pageSize);
			treeNode.isExpanded = true;
			sourceCode.updateItem(treeNode);
		}
		return true;
	}
    //扩展关闭节点事件
    repositoryService.beforeCollapse = function(treeId, treeNode){
        if (treeNode.isExpanded) {
           // ajaxGetNodes(treeNode, pageNo, pageSize);
            treeNode.isExpanded = false;
            sourceCode.updateItem(treeNode);
        }
        return true;
    }
    //捕获节点被点击的事件回调
    repositoryService.onClick = function(treeId, treeNode){
        //console.log(treeNode);
    }
	// 通过节点添加文件夹
	//  this function is for translation and transformation
	//  when translation/transformation finished the tree will add root folder
	repositoryService.addFolderByNodes = function(node) {
		if (node&&node.name) {
			var pNode = sourceCode.getItemsByParam("name", nodes.name);
			if (pNode != "") {
				sourceCode.updateItem(nodes);
			} else {
				sourceCode.addItem(nodes.pId, nodes);
			}
		}else{
			sourceCode.addItem(nodes.nodes.parentId, nodes.nodes);
		}

	}

	// //add floder by path
	// repositoryService.addFloderByPath = function(path) {
	// 	var zTree = sourceCode.getTree();
	// 	$.ajax({
	// 		dataType: 'json',
	// 		url: path,
	// 		type: 'POST'
	// 	}).done(function(data, textStatus, jqXHR) {
	// 		zTree.addNodes(nodes.nodes.parentId, nodes.nodes);
	// 	});
	// }


	//搜索文件，通过ID数组
	//author:longjia
	repositoryService.openItemByIds = function(ids,params) {
		var length;
		if(ids&&(length=ids.length)){
			for(var i=0; i<length;i++){
				repositoryService.openItemById(ids[i],params);
			}
		}else{
			ide.util.alert("No files not be selected .",null,3);
		}
	}

	// // add new floder
	// // 过度方法
	// function addNewFolder(p, src, message, type, time, callback) {
	// 	var pg = common.getMainWindow().main.progress(message, {
	// 		defaultProgress: 60,
	// 		defaultTimes: time,
	// 	});
	// 	ide.util.log.i(message);
	// 	common.getMainWindow().main.showProgress();
	// 	var node;
	// 	$.ajax({
	// 		url: src,
	// 		dataType: "json",
	// 		type: "get",
	// 		success: function(data) {
	// 			showMessage(message, type);
	// 			pg.complete(time - 2000);
	// 			setTimeout(function() {
	// 				node = repository.addFolder(p, data)[0];
	// 				repository.expand(node);
	// 				ide.util.log.i("Generate files completed");
	// 				if (message == "Run Bre") {
	// 					common.getRepositoryWindow().jQuery("#" + node.children[0].children[0].tId + "_a").trigger("click");
	// 				}

	// 				if (callback) {
	// 					callback.call(this);
	// 				}
	// 			}, time - 4000);

	// 		}
	// 	});
	// 	return node;
	// }

	// add new file
	repositoryService.newFile = function(parentNode) {
		if(typeof(parentNode)=="undefined"){
			parentNode=sourceCode.getSelectedItems()[0];
		}
		if(parentNode&&!parentNode.isExpanded){
			sourceCode.expand(parentNode);
		}
		if(parentNode){
			// var dialog=repositoryService.newFile.dialog=common.getMainWindow().ide.util.dialog({
			// 	title:"New File",
			// 	iframe:false,
			// 	href: common.config.rootUrl + "ide/newFile",
			// 	width:800,
			// 	height:300,
			// 	modal:true
			// },function(e){
			// 	repositoryService.newFile.submit&&repositoryService.newFile.submit();
			// 	//repositoryService.newFile
			// });
			var href=common.config.rootUrl + "ide/newFile";
			var dialog=repositoryService.newFile.dialog=common.getMainWindow().ide.util.dialog({
				title:"New File",
				iframe:false,
				href: href,
				width:800,
				height:300,
				modal:true,
				closable:true,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
						repositoryService.newFile.submit&&repositoryService.newFile.submit();
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						//console.log(e)
						e.data.dialog.close();
					}
				}]
			});
			

		}else{
			ide.util.alert(needSelectFolder,null,3);	
		}
		
	};
	
	// add new folder
	// input : flag = true -> edit folder / flag = false -> new folder
	repositoryService.newFolder = function(node,flag) {
		// if node not exits get node from selected nodes
		if(typeof(node)=="undefined"){
			node=sourceCode.getSelectedItems()[0];
		}
		// expanded this node
		if(node&&!node.isExpanded){
			sourceCode.expand(node);
		}
		if(node){
			var href=common.config.rootUrl + "ide/newFolder",title="New Folder";
			if(flag){
				href=common.config.rootUrl + "ide/editFolder/"+node.id+"/"+node.name;
				title="Rename Folder";
			}
			var dialog=repositoryService.newFolder.dialog=common.getMainWindow().ide.util.popupDialog({
				title:title,
				iframe:false,
				href: href,
				width:400,
				height:150,
				modal:true,
				closable:false,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
						repositoryService.newFolder.submit&&repositoryService.newFolder.submit();
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});
			
		}else{
			ide.util.alert(needSelectFolder,null,3);	
		}
		
		
	};

	// 编辑文件或文件夹
	repositoryService.editFileFolder = function(node){
		if(typeof(node)=="undefined"){
			ide.util.alert(needSelectFolder, null, 3);
			return;
		}
		if(!node.isParent){
			//if node is folder 
			var dialog=repositoryService.newFile.dialog=common.getMainWindow().ide.util.popupDialog({
				title:"Rename",
				iframe:false,
				href: common.config.rootUrl + "ide/editFile/"+node.id+"/"+node.name,
				width:400,
				height:150,
				modal:true,
				closable:false,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
						repositoryService.newFile.submit&&repositoryService.newFile.submit();
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});
		}else{
			var projectId;
			repositoryService.newFolder(node,true);
		}
	}
	

    /**
     * 选择文件，点击Ok 按钮获取选中的文件
     * @param  {[Object]}   options 配置参数 pId必填 为父节点目录
     * @param  {Function} callback 点击ok按钮的回调函数
     */
    repositoryService.selectFiles=function(options,callback){
        options=options||{};        
        if(typeof options.pId !="undefined"){   
            repositoryService.selectFiles.dialog = common.getMainWindow().ide.util.dialog({
                title:"Select File",
                width:1000,
                height:540,
                iframe:false,
                modal:true,
                href:common.config.rootUrl+"page/select_file.html",
                buttons:[{
                    text:"Ok",
                    handler:function(e){

                        callback&&$.isFunction(callback)&&callback.call(this,e,repositoryService.selectFiles.getSelectedFiles());
                       
                        //console.log(repositoryService.selectFiles.getSelectedFiles());

                        /*if(repositoryService.selectFiles.getSelectedFiles){
                            var service=common.getRepositoryWindow().repositoryService,files=repositoryService.selectFiles.getSelectedFiles(),length=files&&files.length;
                            if(length){
                                for(var i=0;i<length;i++){
                                    service.openItemById(files[i].id);
                                }
                                repositoryService.selectFiles.dialog.hide();       
                            }else{
                                ide.util.alert("Please select files.",null,3);
                            }
                        }*/
                    }
                },{
                    text:ide.i18n.dialogCancelButtonText,
                    handler:function(e){
                        e.data.dialog.close();
                    }
                }],
                //页面加载完成以后
                success:function(){
                    repositoryService.selectFiles.init(options.pId);
                    //console.log(arguments);
                }
            });
        }
    };



	
	// 
	// 
	// 
	// Right Click Translation Functions
	// 
	//run translation init 
	repositoryService.runTranslationInit = function(node) {
		
		node = getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}

		// var path = common.config.rootUrl + 'translation/init/' + node.projectId;
		// $.ajax({
		// 	dataType: 'json',
		// 	url: path,
		// 	type: 'POST'
		// }).done(function(data, textStatus, jqXHR) {

		// 	if (data.length) {
		// 		for (var i = 0; i < data.length; i++) {
		// 			//if node exits , updata this nodes.
		// 			var pNode = sourceCode.getItemsByParam("name", data[i].name, nodes);
		// 			if (pNode.length>0) {
		// 				sourceCode.deleteItem(pNode[0]);
		// 				sourceCode.addItem(nodes, data[i]);
		// 			} else {
		// 				sourceCode.addItem(nodes, data[i]);
		// 			}
		// 		}
		// 	} else {
		// 		var pNode = sourceCode.getItemsByParam("name", data.name, nodes);
		// 		if (pNode.length>0) {
		// 			sourceCode.deleteItem(pNode[0]);
		// 			sourceCode.addItem(nodes, data);
		// 		} else {
		// 			sourceCode.addItem(nodes, data);
		// 		}

		// 	}

		// });
	};


	//run translation immediately
	repositoryService.runTranslationImmediately = function(node) {
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
		if(node){
			if(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject){
			var projectId = node.projectId;
			var progress = new ide.util.progress("translating", {
				type: 1,
				complete: function() {
					var href = common.config.rootUrl + 'codetranslation/getTranslatedCode/' + projectId;
					$.ajax({
						url: href,
						type: "GET",
						success: function(data) {
							//ide.util.log.i(data.msg);
							data = $.parseJSON(data);
							if (data.length) {
								for (var i = 0; i < data.length; i++) {
									//if node exits , updata this nodes.
									var pNode = sourceCode.getItemsByParam("name", data[i].name, node);
									if (pNode.length>0) {
										sourceCode.deleteItem(pNode[0]);
										sourceCode.addItem(node, data[i]);
									} else {
										sourceCode.addItem(node, data[i]);
									}
								}
							} else {
								var pNode = sourceCode.getItemsByParam("name", data.name, node);
								if (pNode.length>0) {
									sourceCode.deleteItem(pNode[0]);
									sourceCode.addItem(node, data);
								} else {
									sourceCode.addItem(node, data);
								}
							}

							repositoryService.updateProjectStatus(projectId);
						},
					error:function(data){
							//to do 
						}
					})
				}
			}),
			progressId = progress.getId();
		
		$.ajax({
			url: common.config.rootUrl + 'codetranslation/start/' + projectId + "/" + progressId,
			type: "GET",
			success: function(data) {
				common.getMainWindow().main.showProgress();
				ide.util.log.i(data.msg);
				if (data.result) {
				}
			}
		});
		}else{
			var alertContent=ide.i18n.repository.needUploadorCheckout+"\n";
			ide.util.alert(alertContent, null, 3);
		}
		}
		
		

	};

	// run translation schedule
	repositoryService.runTranslationSchedule = function(node) {
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
		if(node&&node.operateMap&&(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject)){
			var dialog=repositoryService.runTranslationSchedule.dialog=common.getMainWindow().ide.util.dialog({
				title:"Schedule",
				iframe:true,
				href: common.config.rootUrl + "ide/runTranslationSchedule/"+node.projectId,
				width:500,
				height:455,
				modal:true,
				closable:true,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
							var win=dialog.getIframeWindow();
						if(win&&win.jQuery){
						repositoryService.runTranslationSchedule.submit&&repositoryService.runTranslationSchedule.submit();
						}	
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});

			
	};
	}

	//merge translation
	repositoryService.mergeTranslation = function(node) {
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}

		// var alertContent="" ;
		// if(node.operateMap.CheckoutProject||node.operateMap.UploadProject){
		// 	if(node.operateMap.Translation){
		// 		var src = common.config.rootUrl + "assets/data/repository/mergeTranslation/project_tree.json";
		// 	addNewFolder(sourceCode.getNodesByParam("id", "0103")[0], src, "Merge Translation Codes", "run", 20000);
		// 	}else{
		// 		alertContent+=ide.i18n.repository.needTranslation+"<br>";
		// 		ide.util.alert(alertContent, null, 3);
		// 	}
		// }else{
		// 	alertContent+=ide.i18n.repository.needUploadorCheckout+"<br>";
		// 	alertContent+=ide.i18n.repository.needTranslation+"<br>";
		// 	ide.util.alert(alertContent, null, 3);
		// }

	};


	// 
	// 
	// Right Click Transformation Functions
	// 
	//init transformation
	repositoryService.runTransformationInit = function(node) {
		// get root node 
		node = getRootNode(node);
        //console.log(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
        var selector = repository.getSelectors();
        //需要在operateMap 中加transformation,用来判断 transformation 是否可点击.
        // true 为可点, false 为不可点
        node.operateMap.transformation = true;

        var isInit = node.operateMap.transformation;
        //点击设置init不可用
        if(isInit){
            var arr = [];
            arr[0] = contextMenu.find(selector.initTransformation).closest('li').attr('data-service')
            repository.disableMenus(arr);
            var tfInitData = {
                projectId: node.projectId,
                transformation:false
            }
            ide.util.ajax({
                type:"get",
                url: app.transformationInit,//+"?projectId="+node.projectId+"&transformation=false",
                dataType:'json',
                data:tfInitData,
                success:function(rs){
                    var items = rs.data.json.nodes;
                    var zTree = sourceCode.getTree();
                    zTree.addNodes(node, items,false);
                    for(var i = 0, len = items.length; i < len; i++){
                        zTree.updateNode(items[i]);
                    }
                }
            });
        }
	};

	//run transformation immediately
	repositoryService.runTransformationImmediately = function(node) {
		// get root node 
		node = getRootNode(node);

        //console.log(node)

        var data = {
            projectId: node.projectId
        }
        ide.util.ajax({
            type:'get',
            dataType:'json',
            url: app.runtransformation,
            data:data,
            success:function(rs){
                //console.log(rs);
                if(rs.status == 200){

                    //父文件夹ID
                    //var pId=1;
                    repositoryService.runTransformationImmediately.dialog = common.getMainWindow().ide.util.dialog({
                        title:"Script Files",
                        width:600,
                        height:480,
                        iframe:false,
                        modal:true,
                        href:common.config.rootUrl+"page/list_files.html",
                        buttons:[{
                            text:"Ok",
                            handler:function(e){
                                var ArrId = repositoryService.runTransformationImmediately.getSelectedFiles();
                                //console.log(repositoryService.runTransformationImmediately.getSelectedFiles());
                                //console.log(ArrId);
                                /*var objId = [];
                                for(var i = 0; i < ArrId.length; i++){
                                    objId.push(ArrId[i].id);
                                }*/

                                var createOutputArg = {
                                    projectId:ArrId[0].projectId,
                                    fileId: ArrId[0].id
                                }

                                repositoryService.runTransformationOutput(createOutputArg);
                            }
                        },{
                            text:ide.i18n.dialogCancelButtonText,
                            handler:function(e){
                                e.data.dialog.close();
                            }
                        }],
                        //页面加载完成以后
                        success:function(){
                            repositoryService.runTransformationImmediately.init(node.projectId);
                        }
                    });



                }else{
                    ide.util.alert(rs.message,null,2);
                }


            }
        });




	};

    //生成output 节点
    repositoryService.runTransformationOutput = function(data){
        ide.util.ajax({
            type:'get',
            dataType:'json',
            url: app.transformationOutput+"?projectId="+data.projectId+"&fileId="+data.fileId,
            success:function(rs){
                //console.log(rs);
                var items = rs.data.json.nodes;
                var zTree = sourceCode.getTree();
                var nodes = sourceCode.getSelectedItems();
                if(nodes&&nodes.length){
                    zTree.addNodes(nodes[0], items,false);
                    for(var i = 0, len = items.length; i < len; i++){
                        zTree.updateNode(items[i]);
                    }
                    repositoryService.runTransformationImmediately.dialog.close();
                }
            }
        })
    }



	// run transformation schedule
	repositoryService.runTransformationSchedule = function(node) {
		// get root node 
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}

		// var alertContent="" ;
		// if(node.operateMap.CheckoutProject||node.operateMap.UploadProject){
		// 	common.getMainWindow().ide.util.popupDialog({
		// 	href: common.config.rootUrl + "ide/runSchedule ",
		// 	width: 500,
		// 	height: 400
		// 	});
		// }else{
		// 	alertContent+=ide.i18n.repository.needUploadorCheckout+"<br>";
		// 	ide.util.alert(alertContent, null, 3);
		// }

		
	};

	//merge transformation
	repositoryService.mergeTransformation = function(node) {
		// get root node 
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
		// var alertContent="" ;
		// if(nodes.operateMap && (nodes.operateMap.CheckoutProject||nodes.operateMap.UploadProject)){
		// 	if(node.operateMap.Transformation){
		// 		var src = common.config.rootUrl + "assets/data/repository/merageTransform/project_tree.json";
		// 		addNewFolder(sourceCode.getNodesByParam("id", "0102")[0], src, "Merge Transformation ", "run", 20000);
		// 		}else{
		// 			alertContent+=ide.i18n.repository.needTransformation+"<br>";
		// 			ide.util.alert(alertContent, null, 3);
		// 		}
		// 	}else{
		// 	alertContent+=ide.i18n.repository.needUploadorCheckout+"<br>";
		// 	alertContent+=ide.i18n.repository.needTransformation+"<br>";
		// 	ide.util.alert(alertContent, null, 3);
		// }	
	};


	// 
	// 
	// Right Click BRE Functions
	// 
	// run bre schedule
	repositoryService.runBreSchedule = function(node) {
		// get root node 
		node=getRootNode(node)
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}

		common.getMainWindow().ide.util.popupDialog({
			href: common.config.rootUrl + "/ide/runSchedule",
			width: 500,
			height: 400
		});
	};

	// run configuration
	repositoryService.breConfigration = function(node) {
		// get root node 
		node=getRootNode(node)
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
		common.getMainWindow().ide.util.popupDialog({
			href: common.config.rootUrl + "/ide/bre"
		});
	};


	//run bre immediately
	repositoryService.runBreImmediately = function(node) {
		var height = top.document.body.clientHeight-80;
		var width = top.window.document.body.clientWidth-40;
		var alertContent="" ;
		// get root node 
		node=getRootNode(node)
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}

		if(node.operateMap && (node.operateMap.CheckoutProject||node.operateMap.UploadProject)){
			//if(node.operateMap.SystemAnalysis){
				var dialog=repositoryService.runBreImmediately.dialog=common.getMainWindow().ide.util.popupDialog({
					href: common.config.rootUrl + "/ide/patternanalysis/"+node.projectId,
					width: width,
					height: height
				});

			//}else{
			//	alertContent+=ide.i18n.repository.needAnalysis;
			//	ide.util.alert(alertContent, null, 3);
			//}
		
		}else{
			
				alertContent=ide.i18n.repository.needUploadorCheckout;
				ide.util.alert(alertContent, null, 3);
		
		}
		
	};

	


	//isToolbar : 是否是toolbar单击
	repositoryService.runDuplicationAnalysis = function(node,isToolbar) {
		var win=$(parent.window),height = win.height()-40,
		width = win.width()-40,
		alertContent="" ;
		// get root node 
		node=getRootNode(node);
		//console.log(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return;
		}
		if(node&&node.operateMap && (node.operateMap.CheckoutProject||node.operateMap.UploadProject || node.operateMap.MainframeProject)){
			//if(node.operateMap.SystemAnalysis){
				var dialog;
				if((dialog=repositoryService.runDuplicationAnalysis.dialog)&&dialog.projectId==node.projectId){
					dialog.ui.dialog.show();
					dialog.ui.dialogOverlay.ui.overlay.fadeIn(250);
					dialog.ui.dialog.animate(dialog.uiStatus,300,function(){				
						dialog.ui.closeHandler.show();
					});
					return;
				}
				repositoryService.runDuplicationAnalysis.closeDialog=function(e){
					//console.log(this);
					var dialog=repositoryService.runDuplicationAnalysis.dialog,btn=common.getMainWindow().jQuery("#runDuplicationAnalysisBtn .btn");

					//缓存dialog状态
					
					dialog.uiStatus={
						width:dialog.ui.dialog.width(),
						height:dialog.ui.dialog.height(),
						top:parseInt(dialog.ui.dialog.css("top")),
						left:parseInt(dialog.ui.dialog.css("left"))
					}
					dialog.ui.closeHandler.hide();
					dialog.ui.dialogOverlay.ui.overlay.fadeOut(250);

					dialog.ui.dialog.animate({
						left:226,
						top:70,
						width:0,
						height:0
					},450,function(){
						dialog.ui.dialog.hide();
						btn.addClass("active");
						setTimeout(function(){
							btn.removeClass("active");
							//setInterval(function(){
								//btn.removeClass("bounce animated").addClass("bounce animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
								//	$(this).removeClass("bounce animated");
								//});
								//btn.removeClass("bounce animated").addClass("bounce animated");
							//},3000);
						},160);
					});
					return false;

				}
				dialog=repositoryService.runDuplicationAnalysis.dialog=common.getMainWindow().ide.util.dialog({
					title:"Business Rule Extraction",
					href: common.config.rootUrl + "/ide/patternanalysis/"+node.projectId,
					width: width,
					height: height,
					modal:true,
					closeHandler:repositoryService.runDuplicationAnalysis.closeDialog
				});
				dialog.projectId=node.projectId;
			//}else{
			//	alertContent+=ide.i18n.repository.needAnalysis;
			//	ide.util.alert(alertContent, null, 3);
			//}
		}else{
			alertContent=ide.i18n.repository.needUploadorCheckout+"<br>";
			ide.util.alert(alertContent, null, 3);
		}
	}

	//得到根节点,返回一个根节点
	function getRootNode(node) {
		var root =false;
		if (!node) {
			node = sourceCode.getSelectedItems()[0];
		}
		if (node) {
			while (!node.operateMap) {
				node = node.getParentNode();
			}
			root = node;
		}
		return root;
	}

	//得到根节点,返回根节点的列表
	function getRootNodes(nodes) {
		var roots = new Array();
		if(nodes){
			for(var i=0;i<nodes.length;i++){
				var root = getRootNode(nodes[i]);
				roots.push(root);
			}
		}else{
			return false;
		}
		return roots;

	}
	

	//run analysis
	repositoryService.runAnalysis = function(node) {
		// get root node 
		var alertContent="" ;
		node=getRootNode(node);
		if(!node){
			alertContent+=ide.i18n.repository.needSelectProject;
			ide.util.alert(alertContent, null, 3);
			return false;
		}
        //console.log(node);
		if(node.operateMap.CheckoutProject||node.operateMap.UploadProject || node.operateMap.MainframeProject){
			// common.getMainWindow().ide.util.popupDialog({
			// href: common.config.rootUrl + "ide/runAnalysis",
			// width:500,
			// height:250
			// });	

			var href=common.config.rootUrl + "ide/runAnalysis";
			var dialog=repositoryService.runAnalysis.dialog=common.getMainWindow().ide.util.dialog({
				title:"Analysis Options",
				iframe:false,
				href: href,
				width:500,
				//height:350,
                height:255,
				modal:true,
				closable:true,
				buttons:[{
					text:"Run",
					handler:function(){
						//var win = dialog.getIframeWindow();
						//if (win && win.jQuery) {
							repositoryService.runAnalysis.submit&&repositoryService.runAnalysis.submit();
						//}
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});
		}else{
			alertContent+=ide.i18n.repository.needUploadorCheckout;
			ide.util.alert(alertContent, null, 3);
		}
	}


	//run analysis schedule
	repositoryService.runAnalysisSchedule = function(node) {
		var alertContent="" ;
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return false;
		}
		if(node.operateMap.CheckoutProject||node.operateMap.UploadProject || node.operateMap.MainframeProject){
			var href=common.config.rootUrl + "ide/runAnalysisSchedule";
			var dialog=repositoryService.runAnalysisSchedule.dialog=common.getMainWindow().ide.util.dialog({
				title:"Schedule",
				iframe:true,
				href: href,
				width:500,
				height:460,
				modal:true,
				closable:true,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
						var win = dialog.getIframeWindow();
						if (win && win.jQuery) {
							repositoryService.runAnalysisSchedule.submit && repositoryService.runAnalysisSchedule.submit();
						}
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});

		}else{
			alertContent+=ide.i18n.repository.needUploadorCheckout;
			ide.util.alert(alertContent, null, 3);
		}
	}


	//获取所有选中的节点
	repositoryService.getSelectedItems = function() {
		return sourceCode.getSelectedItems();
	}

	// //获取选中的文件
	// repositoryService.getSelectedFiles = function() {
	// 	var selectedNodes = sourceCode.getSelectedItems();
	// 	var selectFiles = [];
	// 	var n = 0;
	// 	for (var i = 0; i < selectedNodes.length; i++) {
	// 		if (!selectedNodes[i].isParent) {
	// 			selectFiles[n++].push(selectedNodes[i]);
	// 		}
	// 	}
	// 	return selectFiles;
	// }

	// //获取选中的文件夹
	// repositoryService.getSelectedFolders = function() {
	// 	var selectedNodes = sourceCode.getSelectedItems();
	// 	var selectFolders = [];
	// 	var n = 0;
	// 	for (var i = 0; i < selectedNodes.length; i++) {
	// 		if (selectedNodes[i].isParent) {
	// 			selectFolders[n++].push(selectedNodes[i]);
	// 		}
	// 	}
	// 	return selectFolders;
	// }


	//通过Id打开文件
	repositoryService.openFileById = function(id, params) {
		if (id) {
			var node = sourceCode.getItemById(id)
				//if the repository tree contain this node than open it by id
			if (node.length > 0) {
				openItem(node[0], params);
			} else {
				//if the repository tree not contain this node find it from database	
				//if the repository tree not contain this node find it from database	
				var flag = false;
				var href = common.config.rootUrl + "ide/findFileById/" + id;
				$.ajax({
					dataType: 'json',
					url: href,
					type: 'GET'
				}).success(function(data, textStatus, jqXHR) {
					if (data != "") {
						openItem(data, params);
					} else {
						ide.util.alert("File not found.",null,3);
					}

				})

			}

		} else {
			ide.util.alert("File not found.",null,3);
		}

	}
	//通过ID数组打开文件
	repositoryService.openFilesByIds = function(ids, params) {
		var length;
		if (ids && (length = ids.length)) {
			for (var i = 0; i < length; i++) {
				repositoryService.openFileById(ids[i], params);
			}
		}else {
			ide.util.alert("File not found.",null,3);
		}
	}

	//通过items数组打开files
	repositoryService.openFiles = function(files, params) {
		var length;
		if (files && (length = files.length)) {
			for (var i = 0; i < length; i++) {
				openItem(files[i], params);
			}
		}else {
			ide.util.alert("File not found.",null,3);
		}
	}



	//通过ID查找文件
	repositoryService.findFileById = function(id) {

	}

	//通过ID数组查找文件
	repositoryService.findFilesByIds = function() {

	}


	// //通过items数组删除文件
	// repositoryService.deleteItems = function(items) {
	// 	if (items) {
	// 		var confirmContent = "Are you sure delete this file?";
	// 		ide.util.confirm(confirmContent, function(e) {
	// 			for (var i = 0; i < items.length; i++) {
	// 				var href = common.config.rootUrl + "codefiles/deleteCodefiles/" + node.id;
	// 				$.ajax({
	// 					dataType: 'text',
	// 					url: href,
	// 					type: 'GET',
	// 				}).success(function(data) {
	// 					sourceCode.deleteItem(node);

	// 				});
	// 			}
	// 			e.data.dialog.close();
	// 		});
	// 	}else {
	// 		ide.util.alert("Delete file not found.");
	// 	}
	// }

	// //通过ID删除文件
	// repositoryService.deleteItemById = function(id) {
	// 	if (id) {
	// 		ide.util.confirm("Are you sure delete this files?", function(e) {
	// 			var node = sourceCode.getItemById(id)
	// 				//if the repository tree contain this node than open it by id
	// 			var href = common.config.rootUrl + "codefiles/deleteCodefiles/" + id;
	// 			if (node.length > 0) {
	// 				ide.util.ajax({
	// 					url: href,
	// 					type: 'GET',
	// 					success: function(data) {
	// 						var node = sourceCode.getSelectedItems();
	// 						sourceCode.deleteItem(node);
	// 						e.data.dialog.close();
	// 					}
	// 				})

	// 			} else {
	// 				//if the repository tree not contain this node find it from database	
	// 				var flag = false;
	// 				var href = common.config.rootUrl + "ide/findFileById/" + id;
	// 				$.ajax({
	// 					dataType: 'json',
	// 					url: href,
	// 					type: 'GET'
	// 				}).success(function(data, textStatus, jqXHR) {
	// 					if (data != "") {
	// 						var delHref = common.config.rootUrl + "codefiles/deleteCodefiles/" + data.id;
	// 						ide.util.ajax({
	// 							url: delHref,
	// 							type: 'GET',
	// 							success: function() {
	// 								var node = sourceCode.getSelectedItems();
	// 								sourceCode.deleteItem(node);
	// 								e.data.dialog.close();
	// 							}
	// 						})
	// 					} else {
	// 						ide.util.alert("Delet file not found.");
	// 					}

	// 				})

	// 			}
	// 		});

	// 	} else {
	// 		ide.util.alert("Delete file not found.");
	// 	}

	// }

	
	// edit file type mapping
	repositoryService.editProjectTypeMapping = function(node) {
		node=getRootNode(node);
		if(!node){
			ide.util.alert(needSelectProject, null, 3);
			return false;
		}
		if(node&&node.operateMap&&(node.operateMap.CheckoutProject||node.operateMap.UploadProject)){
			// common.getMainWindow().ide.util.popupDialog({
			// 	href: common.config.rootUrl + "ide/fileTypeMapping/" + node.projectId+"/"+node.id,
			// 	width: 600,
			// 	height: 400
			// })
			// 
			var dialog=repositoryService.editProjectTypeMapping.dialog=common.getMainWindow().ide.util.dialog({
				title:"File Type Mapping",
				iframe:true,
				href: common.config.rootUrl + "ide/fileTypeMapping/" + node.projectId+"/"+node.id,
				width:500,
				height:400,
				modal:true,
				closable:true,
				buttons:[{
					text:ide.i18n.dialogOkButtonText,
					handler:function(){
							var win=dialog.getIframeWindow();
						if(win&&win.jQuery){
						repositoryService.editProjectTypeMapping.submit&&repositoryService.editProjectTypeMapping.submit();
						}	
					}
				},{
					text:ide.i18n.dialogCancelButtonText,
					handler:function(e){
						e.data.dialog.close();
					}
				}]
			});

		}else{
			var alertContent=ide.i18n.repository.needUploadorCheckout;
			ide.util.alert(alertContent, null, 3);
		}
	}


    //     tabSelect();
    //     tab切换
    //     ele最外层节点
    //     eg:
    //     <div class='J_IT'>
    //         <ul class='J_tabNav tab-nav'>
    //            <li class='active'>tab1</li>
    //            <li>tab2</li>
    //         </ul>
    //         <div class='J_tabCont tab-content'>
    //             <div class='tab-pane active'>cont1</div>
    //             <div class='tab-pane'>cont2</div>
    //         </div>
    //     </div>

   repositoryService.tabSelect =  function(ele) {
       var tabBox;
       if(typeof ele == 'object'){
           tabBox = ele
       }else if(typeof ele == 'string'){
           tabBox = $(ele)
       }
        var tabNav = tabBox.find('.J_tabNav').children(),
            tabCont = tabBox.find('.J_tabCont .tab-pane'),
            ACTIVE = 'active';
        $.each(tabNav, function (idx, ele) {
            $(ele).on('click', function (e) {
                e.preventDefault();
                $(this).addClass(ACTIVE).siblings().removeClass(ACTIVE);
                $(tabCont).eq(idx).addClass(ACTIVE).siblings('.tab-pane').removeClass(ACTIVE);
            })
        })
    }


	return repositoryService;
})(repositoryService || {}, ide, jQuery);