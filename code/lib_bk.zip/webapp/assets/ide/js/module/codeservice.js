/**
 * Code 类
 */
define(['jquery','ide',"moduleCommon","menu","util","editor","editorSuggest"],function($,ide,common,menu){	
	require(["outline","deadcode","clonecode","translatedcode","transformedcode","codeSourcecode","jobflow","controlflow","reference","callerandcallee","opc"]);
	/*require("deadcode");
	require("clonecode");
	require("translatedcode");
	require("transformedcode");
	require("codeSourcecode");
	require("jobflow");
	require("controlflow");
	require("reference");
	require("callerandcallee");
	require("opc");*/
	var Code=function(element,options){
		var self=this;
		this.$element=$(element);
		this.options=$.extend({

		},options||{});
		this.ui={};

		this.selectors={
			bodyContainer:"#ide-body",
			tools:{
				container:"#ide-tools",
				body:"#ide-tools-body",
				title:"#ide-tools-title",
				menu:".ide-tools-menu li",
				content:".ide-tools-content",
				resizeHandler:"#J_tools_resize_handler",
				close:"#ide-tools-close",
				toggleButton:"#tools-toggle-btn",

				outline:"#ide-code-outline",
				deadCode:"#ide-code-deadcode",
				cloneCode:"#ide-code-clonecode",
				annotation:"#ide-code-annotation-datatable",
				controlFlow:"#ide-code-controlflow",
				dataFlow:"#ide-code-dataflow-datatable",
				translatedCode:"#ide-code-translatedcode",
				sourceCode:"#ide-code-sourcecode",
				transformedCode:"#ide-code-transformedcode",
				origin:"#ide-code-origin",
				callerAndCallee:"#ide-code-callerandcallee",
				reference:"#ide-code-reference",
				jobFlow:"#ide-code-jobflow",
				opc:"#ide-code-opc"
			},
			container:"#editor-container",
			editorWrap:"#editor-wrap",
			editor:"#J_ide_editor",
			otherEditorWrap:"#othereditor-wrap",
			otherEditor:"#ide-other-editor",
			resizeHandler:"#J_resize_handler",
			contextmenu:"#ide-editor-contextmenu"
		};

		//获取tools ui 对象
		function getToolsUi(){
			var selectors=self.selectors;
			var ui={};
			ui.container=self.$element.find(selectors.tools.container);
			
			ui.body=ui.container.find(selectors.tools.body);	
			ui.title=ui.container.find(selectors.tools.title);
			ui.menus=ui.container.find(selectors.tools.menu);
			ui.contents=ui.container.find(selectors.tools.content);
			ui.resizeHandler=ui.container.find(selectors.tools.resizeHandler);
			ui.close=ui.container.find(selectors.tools.close);
			ui.toggleButton=ui.container.find(selectors.tools.toggleButton);
			return ui;
		}

		//获取UI 节点
		function getUi(){
			var ui={};
			//ui.container=$(this.selectors.container);
			ui.editorBody=self.$element.find("#ide-editor");

			ui.editorWrap=self.$element.find(self.selectors.editorWrap);

			ui.editor=self.$element.find(self.selectors.editor);
			ui.otherEditorWrap=self.$element.find(self.selectors.otherEditorWrap);
			ui.otherEditor=self.$element.find(self.selectors.otherEditor);
			ui.resizeHandler=self.$element.find(self.selectors.resizeHandler);
			ui.contextMenu=self.$element.find(self.selectors.contextmenu);
			return ui;
		}
		//ui 对象
		this.ui=getUi();

		//获取右侧菜单UI对象
		this.ui.tools=getToolsUi();

		this.ui.contextMenus=this.$element.find(common.config.selectors.menu);

		//给右侧菜单注册事件
		this.initTools();
		self.editorObject=self._init();
	};

	(function(){

		/*editor module*/

		//初始化suggest 组件
		this.initSuggest=function(){
			var self=this,options=self.options,ui=self.ui;

			var editorSuggest=new ide.util.Suggest(self.$element.find("#editor-suggest"),{
				url:common.config.rootUrl+"assets/ide/data/annotation.json"
			});
			editorSuggest.$element.on("suggestselect",function(e,data){			
				var range=self.getActiveEditor().getAceEditor().getSelection().getRange();

				//判断range 是否选中了整行
				//console.log(range);

				if(range.end.column==0){
					range.end.row--
				}

				//console.log(range.end.column);


				self["addAnnotation"].call(self,range.start.row,range.end.row,data.startCode,data.endCode,range.start.column,range.end.column);
				editorSuggest.hide();
			});
			
			return editorSuggest;
		}

		//禁止菜单
		this.disableMenus=function(services){
			var self=this,options=self.options,ui=self.ui,
			contextMenus=ui.contextMenus;

			for(var i=0,j=services.length;i<j;i++){
				contextMenus.filter("[data-service='"+services[i]+"']").addClass("disabled").data("disbaled",true);
			}
		};

		//启用菜单menu
		this.enableMenus=function(services){
			var self=this,options=self.options,ui=self.ui,
			contextMenus=ui.contextMenus;

			for(var i=0,j=services.length;i<j;i++){
				contextMenus.filter("[data-service='"+services[i]+"']").removeClass("disabled").data("disbaled",false);
			}
		};

		//显示右键菜单
		this.showContextMenu=function(left,top){
			var self=this,options=self.options,ui=self.ui;
			ui.contextMenu.css({
				left:left,
				top:top
			}).show();
		}

		//隐藏右键菜单
		this.hideContextMenu=function(){
			var self=this,options=self.options,ui=self.ui;
			ui.contextMenu.hide();
		}


		//初始化右击菜单
		this.initContextMenu=function(){
			var self=this,options=self.options,ui=self.ui;

			var height,editorObject=self.getEditor();
			
			self.$element.on("contextmenu",".ide-editor-wraper",function(e){
				var _target=$(e.target);
				
				if(!_target.hasClass("ace_text-input")&&!_target.hasClass("ace_content")){
					return false;
				}
				
				height=common.getContextMenuHeight(ui.contextMenu)+2;
				//self.showContextMenu(e.pageX,common.getContextMenuTop(e.pageY,height,$(window).height()));
				self.showContextMenu(e.pageX,common.getContextMenuTop(e.pageY,height,$(window).height()));
				
				var activeEditorObject=self.getActiveEditor(),copytext=activeEditorObject.getCopyText(),otherEditorObject=self.getOtherEditor();

				//如果code为只读
				if(activeEditorObject.options.readOnly){				
					self.disableMenus(["undo","redo","copy","cut","paste","addAnnotation","addAnnotationRule","addTranslationRule","addTransformationRule","save","compile"]);
				}else{
					self.enableMenus(["undo","redo","copy","cut","paste","addAnnotation","addAnnotationRule","addTranslationRule","addTransformationRule","save"]);
				}


				//判断右键菜单的默认显示
				if(copytext){
					self.enableMenus(["addAnnotation","addAnnotationRule","addTranslationRule","addTransformationRule"]);
					if(!activeEditorObject.options.readOnly){
						self.enableMenus(["copy","cut",]);
					}
					ui.contextMenu.data("copytext",copytext);
				}else{
					self.disableMenus(["copy","cut","addAnnotation","addAnnotationRule","addTranslationRule","addTransformationRule"]);
				}

				//如果当前editor对象不是第一个editor对象
				//控制viewTranslatedCode
				if(activeEditorObject===self.getOtherEditor()){

					self.disableMenus(["refreshControlFlow","viewTranslatedCode","viewSourceCode","addAnnotation","compile"]);				
				}else{
					self.enableMenus(["refreshControlFlow"]);

					var range=editorObject.getAceEditor().getSelection().getRange();

					//console.log(editorObject.getCopyText());
					if(editorObject.getCopyText()&&otherEditorObject){
						ui.contextMenu.data("range",range);
						//确保otherEditor 初始化完毕
						if(isInMarkers(range,editorObject.markers)){
							self.enableMenus(["viewTranslatedCode"]);
						}else{
							self.disableMenus(["viewTranslatedCode"]);
						}
						//启用viewSourceCode
						self.enableMenus(["viewSourceCode"]);
					}else{
						self.disableMenus(["viewTranslatedCode","viewSourceCode"]);
					}
				}

				

				//对部分操作未完成做处理
				//如果 controflow 未加载完成则禁用 refreshControlFlow 菜单
				//如果完成则启用菜单
				if(!self.controlflowcomplete){
					self.disableMenus(["refreshControlFlow"]);
				}else{

					self.enableMenus(["refreshControlFlow"]);
				}


				return false;
			}).bind("click",function(){
				self.hideContextMenu();
			}).bind("contextmenu",function(){
			//	return false;
			});


			//右键菜单
			
			self.$element.on("click",common.config.selectors.menu,function(e){
				var $this=$(this);
				
				//判断右键菜单是否可操作
				if($this.data("disbaled")!==true){
					var service=$this.attr("data-service"),serviceType=$this.attr("data-servicetype"),activeEditorObject=self.getActiveEditor(),copytext=ui.contextMenu.data("copytext");
					if(serviceType==="editor"){
						//持续editor 的方法
						if(service=="save"){
							//{id:options.code.id,pid:options.code.parentId}
							activeEditorObject.save(null,function(data){
								//save sucess
							});
						}else{
							activeEditorObject[service]();
						}
					}else{
						//add rule 
						if(service==="addAnnotationRule"||service==="addTranslationRule"||service==="addTransformationRule"){				
							self[service].call(self,copytext);				
						}else if(service==="addAnnotation"){

							var aceEditor=activeEditorObject.getAceEditor(),range=aceEditor.getSelection().getRange(),session=aceEditor.getSession(),scrollTop=session.getScrollTop(),
							top=(range.start.row)*aceEditor.renderer.lineHeight-scrollTop;
							
							self.editorSuggest.show(null,top>0?top:0);
							self.hideContextMenu();
							return false;
						}else if(service==="viewTranslatedCode"||service==="viewSourceCode"){

							//var range=activeEditorObject.getAceEditor().getSelection().getRange();
							self[service](ui.contextMenu.data("range"));

						}else if(service==="refreshControlFlow"){

							//刷新control flow  
							//默认打开control flow
							self.refreshControlFlow(true);

						}else if(service === 'runJob' || service === 'compile'){
							repositoryService[service].call(repositoryService,self.editorObject.options);

						}else{
							//other editorService 
							self[service].call(self);
						}				
					}
				}
				
			});
		}


		//判断是否在选中的模块中
		function isInMarkers(range,markers){
			
			var startLine=range.start.row,endLine=range.end.row;
			for(var i in markers){
				if(startLine>=markers[i].start.row&&endLine<=markers[i].end.row-1){
					return true;
				}
			}
			return false;
		}

		//隐藏editor
		this.hideOtherEditor=function(){
			var self=this,options=self.options,ui=self.ui;

			ui.otherEditorWrap.hide();
			ui.resizeHandler.hide();
			ui.editorWrap.css({
				"width":"100%",
				"margin-left":0
			});
			self.resize();
			//self.editorObject&&self.editorObject.getAceEditor().resize();
			//self.otherEditorObject&&self.otherEditorObject.getAceEditor().resize();
		};

		//显示editor
		this.showOtherEditor=function(){
			var self=this,options=self.options,ui=self.ui;

			ui.otherEditorWrap.show();
			ui.resizeHandler.show();
			ui.editorWrap.css({
				"width":self.width,
				"margin-left":"-100%"
			});
			self.resize();
			//self.editorObject&&self.editorObject.getAceEditor().resize();
			//self.otherEditorObject&&self.otherEditorObject.getAceEditor().resize();
		};

		//检测othereditor 是否显示
		this.isOtherEditorVisible=function(){
			var self=this,options=self.options,ui=self.ui;
			return ui.otherEditorWrap.is(":visible");
		};

		
		//editor 与other editor 之间的 resize
		this.width="50%";//记录下默认宽度
		this.initResize=function(){
			var self=this,options=self.options,ui=self.ui,
			editorObject=self.editorObject,
			otherEditorObject=self.otherEditorObject;

			
			var maxWidth=ui.editorBody.width()-100,
			resize=ui.editorWrap.cgResize({
				handler:ui.resizeHandler,
				opacity:1,
				cursor:"e-resize",
				iframeFix:true,
				direction:"e",
				min:{width:100},
				start:function(){
					resize.option("max",{width:ui.editorBody.width()-100});
				},
				resize:function(e,u){
					var windowWidth=ui.editorBody.width();
					self.width=(u.currentSize.width/windowWidth)*100+"%";
					ui.otherEditor.css("margin-left",self.width);
					$(this).css("width",self.width);

					return false;
				},
				stop:function(e,u){
					$(this).css("width",self.width);
					self.resize();
					//editorObject.getAceEditor().resize();
					//otherEditorObject.getAceEditor().resize();
				}
			});
		}

		this._init=function(opts){
			var self=this,options=self.options,ui=self.ui;

			if(options.code.readOnly==1){
				options.code.readOnly=true;
			}else{
				options.code.readOnly=false;
			}

			
			//console.log(ui.editor);
			self.activeEditorObject=editorObject=new ide.Editor(ui.editor,options.code);

			
			registerEditorHandle.call(self);

			//监听浏览刷新或者关闭事件
			//registerWindowBeforeUnload(ui,options);

			self.editorSuggest=self.initSuggest(self);
			
			return editorObject;
		};
		//注册window beforeunload
		function registerWindowBeforeUnload(ui,options){
			//监听 window onbeforeunload 事件
			/*window.onbeforeunload=function(){
				
				if(editorObject&&editorObject.changed){
					return "";
				}else if(otherEditorObject&&otherEditorObject.changed){
					return "";
				}			
			};*/

			//window.onload=function(){
				//初始化进来时，将code编辑状态设为false
				//修改状态
				//common.getMainWindow().main.updateCodeTabStatusById(options.code.id,false);
			//}
		}

		//注册editor handle事件
		function registerEditorHandle(ui,options){
			var self=this,options=self.options,ui=self.ui;
			ui.otherEditor.bind("complete",function(e,otherEditorObject){
				var aceEditor=otherEditorObject.getAceEditor();
				//注册focus事件
				//设置当前操作窗口
				//监听操作窗口，获取当前操作的窗口对象
				aceEditor.on("focus",function(){
					self.activeEditorObject=otherEditorObject;
					//设置当前窗口
					main.setFocusObject(self);
				});
				
				if(!otherEditorObject.options.readOnly){
					//修改状态
					otherEditorObject.$element.on("editorchange",function(e){
						main.updateCodeTabStatusById(options.code.id,true);
					}).on("editorsave",function(e){
						main.updateCodeTabStatusById(options.code.id,false);
					});
				}
				//注册快捷键	
				otherEditorObject.$element.on("keydown",function(e){

					if(e.ctrlKey&&e.keyCode==83){
						//ctrl+s save
						otherEditorObject.save();
						return false;
					}
				});
			});

			ui.editor.bind("error",function(){
				ide.util.hideTips();
			});
			//左侧editor
			ui.editor.bind("complete",function(e,editorObject){
				ide.util.hideTips();
				var aceEditor=editorObject.getAceEditor();

				//如果selectedStartLine&&selectedEndLine不为空
				//选中当前行
				

				if(options.code.selectedEndLine!=""&&options.code.selectedStartLine!=""){
					if(options.code.selectedStartColumn!=""&&options.code.selectedEndColumn!=""){
						//变量提醒打开新文件,会包含开始列与结束列
						editorObject.selectLines(options.code.selectedStartLine-1,options.code.selectedEndLine,options.code.selectedStartColumn,options.code.selectedEndColumn);


						//用于变量提示 打开新文件
						//记录打开的位置
						//console.log(2);
						main.history.add({
							fileId:options.code.id,
							row:options.code.selectedEndLine-1,
							column:options.code.selectedEndColumn,
							scrollTop:editorObject.getAceEditor().session.getScrollTop()
						});

					}else{

						//右侧菜单 ,选中多行的情况
						editorObject.selectLines(options.code.selectedStartLine-1,options.code.selectedEndLine);	
					}
				}

				//触发单击事件
				var timer;
				//做translated时，单击单行触发选中
				//单行查看translated code 或者单行查看sourcecode
				if(options.code.structureType=="1"&&options.code.fileType=="PGM"&&options.code.translationStep==3||options.code.structureType=="2"&&options.code.fileType=="JAVA"&&options.code.translationStep==3){				
					aceEditor.selection.on("changeCursor",function(e,selection){
						timer&&clearTimeout(timer);
						timer=setTimeout(function(){
							var position=selection.getCursor();
							if(!aceEditor.getCopyText()){
								if(self.isOtherEditorVisible()){
									//translated code
									if(options.code.fileType=="PGM"){
										self.viewTranslatedCodeByLine(position);
									}else{
									//source code
										self.viewSourceCode({
											start:{
												row:position.row
											},
											end:{
												row:position.row
											}
										});
									}
								}
							}					
						},300);
					});
				}

				//获取当前操作窗口
				//当单击公用菜单时，
				aceEditor.on("focus",function(e){
					//console.log(arguments);
					//e.preventDefault();
					//e.stopPropagation();
					
					self.activeEditorObject=editorObject;
					
					//设置当前窗口
					main.setFocusObject(self);


					if(self.options.code.fileType=="PGM" || self.options.code.fileType=="PL1"){
                        menu.enableMenus(["compile"]);
                    }else{
                        menu.disableMenus(["compile"]);
                    }

                    if(self.options.code.fileType=="JOB"){
                        menu.enableMenus(["runJob"]);
                    }else{
                        menu.disableMenus(["runJob"]);
                    }

				});
			
				//editor加载完成以后，初始化右键菜单
				self.initContextMenu();

				//如果文件不是只读的
				if(!editorObject.options.readOnly){
					//修改编辑状态
					editorObject.$element.on("editorchange",function(e,editorObject){
						common.getMainWindow().main.updateCodeTabStatusById(options.code.id,editorObject.changed);
					}).on("editorsave reload",function(e){
						common.getMainWindow().main.updateCodeTabStatusById(options.code.id,false);
					});
				}


				//注册快捷键	
				editorObject.$element.on("keydown",function(e){
					
					if(e.ctrlKey&&e.keyCode==83){
						//ctrl+s save
						editorObject.save();
						return false;
					}else if(e.altKey){
						if(e.keyCode==70){
							//alt+c refresh control flow
							self.refreshControlFlow(true);
							return  false;
						}else if(e.keyCode==67){
							//alt+c 关闭tools
							self.hideTools();
						}				
					}
				});
				require(["ace/lib/event"],function(event){
					event.addListener(editorObject.getAceEditor().renderer.textarea,"keydown",function(e){

						if(e.altKey){
							
							if(e.keyCode==37){

								main.history.prev();
								e.preventDefault();
								e.stopPropagation();
							}else if( e.keyCode == 39){
								main.history.next();
								e.preventDefault();
								e.stopPropagation();
							}
							
						}
						
					});
				});
				
				
				//变量提示
				//只有cobol文件才有变量提示
				if(options.code.fileType=="PGM"){
					self.initVariableTips(aceEditor,function(data,originData){


						main.history.add({
							fileId:options.code.id,
							row:originData.row,
							column:originData.column,
							scrollTop:originData.scrollTop
						});
						var selection = this.editor.getSelection(),
						session = this.editor.session;
						//如果变量定义不在当前文件
						if(data.dcr.fid&&data.dcr.fid!==editorObject.options.id){

							self.addSelection({
								fileId:data.dcr.fid,
								startLine:data.dcr.sl,
								startColumn:parseInt(data.dcr.sc),
								endLine:data.dcr.el-1,
								endColumn:parseInt(data.dcr.ec)
							});
							editorObject.alignCursors();



						}else{
							var _scrollTop;
							selection.clearSelection();
							selection.moveCursorTo(data.dcr.sl - 1, data.dcr.sc, false);
							selection.selectTo(data.dcr.el - 1, data.dcr.ec);
							_scrollTop=session.getScrollTop()-41;
							session.setScrollTop(_scrollTop);

							main.history.add({
								fileId:options.code.id,
								row:data.dcr.el-1,
								column:data.dcr.ec,
								scrollTop:_scrollTop
							});
						}
					});
				}


				//监听左侧编辑器 save 操作
				ui.editor.bind("editorsave",function(){
					//刷新 controflow
					self.refreshControlFlow(false);

					//刷新变量提醒
					self.refreshVariableTips();

					//刷新右边outlineov 数据节点
					if(self.outlineInstance){
						self.outlineInstance.refresh();
					}

					//刷新右边 reference 数据节点
					if(self.referenceRefresh){
						self.referenceRefresh.refresh();
					}

				});
			});		
		};

		/**
		 * 初始化变量提示
		 */
		this.initVariableTips=function(aceEditor,callback){
			
			var self=this,options=self.options,ui=self.ui;
			//ajax var tips
			//console.log(self.editorObject.options.id);
			ide.util.ajax({
				url:common.config.rootUrl+"ide/file/variableDef?codeFileId="+self.editorObject.options.id,
				type:"get",
				success:function(data){
					var TokenTooltip=require(["ace/token_tooltip"],function(TokenTooltip){
						self.tokenTooltip=new TokenTooltip(aceEditor,data.data.json,callback);
					});
				}
			});
		};
		
		/**
		 * 刷新变量提示
		 */
		this.refreshVariableTips=function(){
			
			var self=this,options=self.options,ui=self.ui;

			if(options.code.fileType=="PGM"){
				ide.util.ajax({
					url:common.config.rootUrl+"ide/file/variableDef?codeFileId="+self.editorObject.options.id,
					type:"get",
					success:function(data){
						self.tokenTooltip.refresh(data.data.json);
					}
				});
			}
		};

		//获取editor对象
		this.getEditor=function(){
			return this.editorObject;
		};
		this.getOtherEditor=function(){
			return this.otherEditorObject;
		}

		//获取当前活动的editor
		this.getActiveEditor=function(){
			return this.activeEditorObject;
		};



		//save方法会保存修改后的code editor或者otherEditor
		this.save=function(callback){
			var self=this,options=self.options,ui=self.ui;

			var flag1=false,flag2=false;
			//保存editorObject
			if(self.editorObject){
				self.editorObject.save(null,function(){
					flag1=true;


					if(flag1&&flag2){
						callback&&callback();
					}
				});
			//保存其他的editorObject
			}else{
				flag1=true;
			}
			if(self.otherEditorObject){
				self.otherEditorObject.save(null,function(){
					flag2=true;
					if(flag1&&flag2){
						callback&&callback();
					}
				});
			}else{
				flag2=true;
			}
		}

		/**
		 * save 修改过的文件
		 * @param  {Function} callback save成功以后的回调函数	 
		 */
		this.saveModifiedFile=function(callback){
			var self=this;
			if(self.isModified()){
				ide.util.confirm(self.editorObject.options.name+ide.i18n.code.modify,function(e){
					e.data.dialog.disableButton(0);
					self.save(function(){
						e.data.dialog.close();
						callback&&callback();
						//e.data.dialog.enableButton(0);
					});				
				});
			}			
		};

		//关闭editor
		this.close=function(){
			var self=this,options=self.options,ui=self.ui;
			if(self.getActiveEditor()===self.editorObject){
				main.closeCodeTab(main.getCurrentCodeTab());
			}else{
				self.hideOtherEditor();
			}
		}

		//验证 editor 与 other editor 是否被修改
		this.isModified=function(){
			var self=this;
			//console.log(self.editorObject.changed,self.otherEditorObject.changed);
			return (self.editorObject&&self.editorObject.changed)||(self.otherEditorObject&&self.otherEditorObject.changed);
		};


		

		this.refresh=function(){
			var self=this,options=self.options,ui=self.ui;
			if(self.getActiveEditor()===self.editorObject){
				if(self.editorObject.changed){
					ide.util.customConfirm(self.editorObject.options.name+ide.i18n.code.modify,function(e){
						self.editorObject.save();
						e.data.dialog.close();
					},function(e){
						self.editorObject.reload();
						e.data.dialog.close();
					});
				}else{
					self.editorObject.reload();
				}
			}else{
				if(self.otherEditorObject.changed){
					ide.util.customConfirm(self.otherEditorObject.options.name+ide.i18n.code.modify,function(e){
						self.otherEditorObject.save();
						e.data.dialog.close();
					},function(e){
						self.otherEditorObject.reload();
						e.data.dialog.close();
					});
				}else{
					self.otherEditorObject.reload();
				}
			}
		}

		this.viewTranslatedCodeByLine=function(range){
			var self=this,options=self.options,ui=self.ui,
				otherEditorObject=self.otherEditorObject;

			if(self.otherEditorObject&&range){
				self.showOtherEditor();
				//console.log(range);
				//提交startLine endLine数据			

				ide.util.ajax({
					url:common.config.rootUrl+"ide/displayTranslatedCode",
					data:JSON.stringify({
						startLine:range.row+1,
						endLine:range.row+1,
						fileId:editorObject.options.id
					}),
					success:function(d){
						var data=d.data;
						//移除所有的块
						otherEditorObject.removeAllMarkers();
						

						function addMarker(otherEditorObject,data){
							//选中另外区
							for(var i=0,j=data.json.length;i<j;i++){
								otherEditorObject.addMarker(data.json[i].startLine-1,data.json[i].endLine-1);
							}
							//居中选中块
							if(j){
								otherEditorObject.scrollTo(data.json[0].startLine,data.json[0].endLine,true);
							}
						}


						if(d.data.json&&d.data.json.length){
							//console.log(d.data.json[0].fileId,otherEditorObject.options.code.id)
							if(d.data.json[0].fileId==otherEditorObject.options.id){
								addMarker(otherEditorObject,data);
							}else if(d.data.json[0].fileId){
								otherEditorObject.reload({
									url:common.config.rootUrl+"ide/content?codeFileId="+d.data.json[0].fileId
								},function(){
									addMarker(otherEditorObject,data);
								});
							}
						}
					}
				});
			}
		}
		
		//查看translatedCode
		this.viewTranslatedCode=function(range){
			var self=this,options=self.options,ui=self.ui,
				editorObject=self.editorObject,
				otherEditorObject=self.otherEditorObject;

			if(otherEditorObject&&range){
				self.showOtherEditor();
				//console.log(range);
				//提交startLine endLine数据
				ide.util.ajax({
					url:common.config.rootUrl+"ide/displayTranslatedCodeLine",
					data:JSON.stringify({
						startLine:range.start.row+1,
						endLine:range.end.row+1,
						fileId:editorObject.options.id,
						targetFileId:otherEditorObject.options.id
					}),
					success:function(d){
						var data=d.data;
						//选中另外区
						otherEditorObject.removeAllMarkers();
						for(var i=0,j=data.json.length;i<j;i++){
							otherEditorObject.addMarker(data.json[i].startLine-1,data.json[i].endLine-1);
						}
						//居中选中块
						if(j){
							//var centerLine=parseInt((data.json[0].endLine-data.json[0].startLine)/2)+data.json[0].startLine;
							//console.log(centerLine);
							//otherEditorObject.scrollTo(centerLine,true);
							otherEditorObject.scrollTo(data.json[0].startLine,data.json[0].endLine,true);
						}
					}
				});
			}
		};

		//查看translatedCode
		var _sourceCodeMarkers=[];
		this.viewSourceCode=function(range){
			var self=this,options=self.options,ui=self.ui,
				editorObject=self.editorObject,
				otherEditorObject=self.otherEditorObject;

			if(otherEditorObject&&range){
				self.showOtherEditor();
				//console.log(range);
				//提交startLine endLine数据
				ide.util.ajax({
					url:common.config.rootUrl+"ide/displaySrcCodeLine",
					data:JSON.stringify({
						startLine:range.start.row+1,
						endLine:range.end.row+1,
						fileId:editorObject.options.id
					}),
					success:function(d){
						var data=d.data;
						//选中另外区
						
						otherEditorObject.removeMarkers(_sourceCodeMarkers);
						for(var i=0,j=data.json.length;i<j;i++){
							_sourceCodeMarkers.push(otherEditorObject.addMarker(data.json[i].startLine-1,data.json[i].endLine-1));
						}

						//居中选中块
						if(j){
							//var centerLine=parseInt((data.json[0].endLine-data.json[0].startLine)/2)+data.json[0].startLine;
							//console.log(centerLine);
							otherEditorObject.scrollTo(data.json[0].startLine,data.json[0].endLine,true);
						}
					}
				});
			}
		};

		this.addAnnotation=function(startRow,endRow,startText,endText,column){
			var self=this,options=self.options,ui=self.ui,
				editorObject=self.editorObject,
				otherEditorObject=self.otherEditorObject;

			var aceEditor=editorObject.getAceEditor(),range=aceEditor.getSelection().getRange();
			editorObject.insertNewLineAtPosition(startText,{row:startRow,column:6});
			editorObject.insertNewLineAtPosition(endText,{row:endRow+2,column:6});
			//将鼠标移动到指定位置
			
			if(startText.indexOf("BusinessFunc")!=-1){
				aceEditor.navigateTo(startRow,startText.length-8);
			}else{
				aceEditor.navigateTo(startRow,startText.length+6-2);
			}
			
			aceEditor.focus();
		};

		this.selectLines=function(s,e){
			var self=this,options=self.options,ui=self.ui;

			self.getEditor().selectLines(s,e);
		};



		this.addSelection=function(data,id){
			var self = this,
				options = self.options,
				ui = self.ui;

			var editor=self.getEditor();

			if(data.fileId==editor.options.id){
				editor.selectLines(data.startLine-1,data.endLine,data.startColumn,data,endColumn);
			}else{
				var tab=main.getCodeTabById(data.fileId),_code=main.getCodeById(data.fileId);
				if(tab){
					tab.select();
					_code.getEditor().selectLines(data.startLine-1,data.endLine,data.startColumn,data.endColumn);

					main.history.add({
						fileId:data.fileId,
						row:data.startLine-1,
						column:data.endColumn,
						scrollTop:_code.getEditor().getAceEditor().session.getScrollTop()
					});

				}else{
					repositoryService.openItemById(data.fileId,{
						startLine:data.startLine,
						endLine:data.endLine,
						startColumn:data.startColumn,
						endColumn:data.endColumn
					});
				}

			}
		}

		//比较函数
		this.compare=function(opts,callback){
			var self=this,options=self.options,ui=self.ui;

			self.showOtherEditor();
			//首先初始化ui
			//console.log(otherEditorObject);
			if(self.otherEditorObject){
				self.otherEditorObject.reload(opts,callback);
			}else{
				//初始化otherEditorObject
				
				//如果complete不为空，则将callback设为complete
				if(!opts.complete){
					opts.complete=callback;
				}
				self.otherEditorObject=new ide.Editor(ui.otherEditor,opts);
				//console.log(otherEditorObject);

				//初始化resize事件
				self.initResize();
			}
			return self.otherEditorObject;
		}

		this.compareTranslation=function(opts,callback){
			var self=this,options=self.options,ui=self.ui;

			var compareEditor=self.compare(opts,callback);
			return compareEditor;
		};

		this.compareTransformation=function(opts,callback){
			var self=this,options=self.options,ui=self.ui;

			var compareEditor=self.compare(opts,callback);
			return compareEditor;
		};




		/*
		code module
		 */
		this.outline=function(selector){
			var self=this,opts=this.options.outline;
			ide.util.showTips("Loading Outline");

			//console.log(this.$element.find(selector));
			self.outlineInstance=ide.create('code.Outline',this.$element.find(selector+"-"+this.options.code.id),{
				setting : {
					async: {
						type:"get",
						url:opts.url   //url格式  例如：/outline/2c9093cd4683e8bb014683e8be270001
					},
					callback: {
						onAsyncSuccess: function(event, treeId, treeNode, msg){
							var treeObj = $.fn.zTree.getZTreeObj(treeId);

							var nodes = treeObj.transformToArray(treeObj.getNodes());
							
							$.each(nodes,function(){
								if(this.level==0){
									this.icon = common.config.rootUrl+"assets/ide/img/icon/view_tree_classic.png";
								}else if(this.level==1){
									this.icon = common.config.rootUrl+"assets/ide/img/icon/bullet_blue.png";
								}else{
									this.icon = common.config.rootUrl+"assets/ide/img/icon/bullet_blue_small.png";
								}
								treeObj.updateNode(this);
							});
							treeObj.expandAll(true);
							ide.util.hideTips();
						},
						onAsyncError:function(){
							ide.util.hideTips();
						}
					}
				},
				click:function(e,treeNode){
					if(treeNode.startLine!=null){
						//console.log(treeNode.startLine,treeNode.endLine);
						//console.log(treeNode.startLine+","+treeNode.endLine);
						self.getEditor().selectLines(treeNode.startLine-1,treeNode.endLine)
					}				
				}
			});
		};
	
		//origin 视图
		this.origin=function(selector){
			var self=this;
			var opts=this.options.origin;
			self.compareTranslation({
				url:common.config.rootUrl+opts.url
			});
		};

		
		this.deadCode=function(selector){
			var opts=this.options.deadCode;
			var deadCode=ide.create('code.DeadCode',this.$element.find(selector),{
				url:opts.url,
				rowClick:function(e,data){			
					//请根据data类型做相应的转换
					//console.log(data[1]+","+data[2]);
					self.getEditor().selectLines(data.startLine-1,data.endLine);
				}
			});
		};

		this.cloneCode=function(selector){
			var self=this,opts=this.options.cloneCode;
			var cloneCode=ide.create('code.CloneCode',this.$element.find(selector),{
				url:opts.url,
				patternUrl:opts.patternUrl,
				rowClick:function(e,data){
					//请根据data类型做相应的转换
					//console.log(data[1]+","+data[2]);
					//console.log(options,data.fileId,options.code.id);
					if(data.fileId==self.options.code.id){
						self.getEditor().selectLines(data.startLine-1,data.endLine);
					}else{
						var tab=main.getCodeTabById(data.fileId),_code=main.getCodeById(data.fileId);
						if(tab){
							tab.select();
							_code.getEditor().selectLines(data.startLine-1,data.endLine);
						}else{
							repositoryService.openItemById(data.fileId,{
								startLine:data.startLine,
								endLine:data.endLine
							});
						}
					}				
				}
			}); 
		};
		
		this.annotation=function(selector){
			var self=this;
			var opts=this.options.annotation;
			var annotation=ide.create('code.Annotation',this.$element.find(selector),{
				url:opts.url,
				rowClick:function(data){
					//请根据data类型做相应的转换
					//console.log(data[1]+","+data[2]);
					self.getEditor().selectLines(data[1]-1,data[2]);
				}
			});
		};


		

		//初始化controlflow
		this.controlFlow=function(selector){
			var self=this,opts=this.options.controlFlow,$element=this.$element.find(selector);

			//监听controlflow 完成与出错消息
			$element.on("controlflowcomplete",function(e,_controlflow){
				self.controlflowcomplete=true;				
				self.enableMenus(["refreshControlFlow"]);
			}).on("controlflowerror",function(){
				self.controlflowcomplete=true;				
				self.enableMenus(["refreshControlFlow"]);
			});
			
			this._controlFlow=ide.create('code.ControlFlow',$element,{
				element:this.$element,
				url:opts.url,
				editPatternUrl:opts.editPatternUrl,
				fileId:self.options.code.id,
				click:function(e,startLine,endLine){
					
					if(startLine&&endLine){
						self.getEditor().selectLines(startLine-1,endLine);
					}
				},
				change:function(){

				},
				editPatternHandler:function(){
					ide.util.ajax({
						url:opts.editPatternUrl,
						type:"post",
						data:JSON.stringify({
							name :"control_flow_pattern.pat",
							projectId:self.options.code.projectId
						}),
						success:function(d){						
							if(d.data&&d.data.json){
								var data=d&&d.data.json;
								if(data.isNew){
									var projectNode=repositoryService.getItemById(self.options.code.projectId),
									soueceCode=repositoryService.getSourceCode();
									soueceCode&&soueceCode.addItem(projectNode,data.node);

									repositoryService.openFiles([data.node]);
								}else{
									repositoryService&&repositoryService.openFileById(data.node.fileId)
								}
							}
						}
					});
				}
			});
			
		};


		this.controlflowcomplete=true;
		//刷新controlflow
		this.refreshControlFlow=function(flag){
			
			var self=this;
			//如果 controlflow 还没加载完成则
			if(!self.controlflowcomplete){
				return ;
			}
			//禁用refreshControlFlow菜单
			self.disableMenus(["refreshControlFlow"]);


			self.controlflowcomplete=false;
			//如果 flag == true 则显示 controflow 面板
			//flag == false 隐藏
			if(flag == void 0){
				flag=true;
			}

			if(this._controlFlow&&self._controlFlow.controflows&&self._controlFlow.controflows.length){
				var _currentControlflow=self._controlFlow.controflows[self._controlFlow.getCurrentControlflowIndex()],
				_currentId=_currentControlflow&&_currentControlflow.id,
				_index=_currentId&&self._controlFlow.findControlflowById(_currentId);
				self._controlFlow.reloadControlflows(null,function(){
					if(_index&&_index>-1){
						self._controlFlow.changeControlflow(_index);
					}else{
						self._controlFlow.changeControlflow(0);
					}				
				});
			}else{
				self.controlflowcomplete=true;
				self.enableMenus(["refreshControlFlow"]);
			}
			if(flag){
				this.showTools("controlFlow",true);
			}
		}

		this.dataFlow=function(selector){
			var self=this,opts=this.options.dataFlow;
			var dataFlow=ide.create('code.DataFlow',this.$element.find(selector),{
				url:opts.url,
				rowClick:function(data){
					//请根据data类型做相应的转换
					//console.log(data[1]+","+data[2]);
					self.getEditor().selectLines(data[1]-1,data[2]);
				}
			});    
		};

		this.translatedCode=function(selector){
			var self=this, opts=this.options.translatedCode;
			ide.util.showTips("Loading Translated Code");
			var translatedCode=ide.create('code.TranslatedCode',this.$element.find(selector+"-"+this.options.code.id),{
				setting : {
					async: {
						type:"get",
						url:opts.url
					},
					callback:{
						onAsyncSuccess:function(){
							ide.util.hideTips();
						},
						onAsyncError:function(){
							ide.util.hideTips();
						}	
					}
				},
				click:function(e,data){
					if(data.id&&!data.isParent){
						
						self.compareTranslation({
							//url:common.config.rootUrl+"/assets/ide/data/java_code.json"
							readOnly:true,
							url:common.config.codeContentUrl+data.id
						},function(){
							var editor=self.getEditor(),otherEditor=self.getOtherEditor();
							
							//otherEditor
							editor.removeAllMarkers();
							otherEditor.removeAllMarkers();
							

							//选中指定区域
							if(data.translatedLineNumDtos){
								
								for(var i=0,j=data.translatedLineNumDtos.length;i<j;i++){
									var _d=data.translatedLineNumDtos[i];
									editor.addMarker(_d.startLine-1,_d.endLine-1);
								}


								//居中选中块
								if(j){
									//var centerLine=parseInt((data.translatedLineNumDtos[0].endLine-data.translatedLineNumDtos[0].startLine)/2)+data.translatedLineNumDtos[0].startLine;
									//console.log(centerLine);
									editor.scrollTo(data.translatedLineNumDtos[0].startLine,data.translatedLineNumDtos[0].endLine,true);
								}
								
								editor.focus();

							}						
						});
						//self.hideTools();
					}
				}
			});
		};

		//translated code 
		this.sourceCode=function(selector){
			var self=this,opts=this.options.sourceCode;

			var sourceCode=ide.code.SourceCode(this.$element.find(selector+"-"+this.options.code.id),{
				setting : {
					async: {
						type:'get',
						url:opts.url
					}
				},
				click:function(e,data){
					if(data.id&&!data.isParent){
						
						self.compare({
							readOnly:true,
							url:common.config.codeContentUrl+data.id
							//url:common.config.rootUrl+"/assets/ide/data/cobol_code.json"
						},function(){
							var otherEditor=self.getOtherEditor(),editor=self.getEditor();
							if(otherEditor){
								otherEditor.removeAllMarkers();
								editor.removeAllMarkers();
								
								if(data.translatedLineNumDtos){
									for(var i=0,j=data.translatedLineNumDtos.length;i<j;i++){
										var _d=data.translatedLineNumDtos[i];
										otherEditor.addMarker(_d.startLine-1,_d.endLine-1);
									}
									
									if(j){
										otherEditor.scrollTo(data.translatedLineNumDtos[0].startLine,data.translatedLineNumDtos[0].endLine,true);
									}
								}
							}
						});
						//隐藏tool content
						//self.hideTools();
					}
				}
			});
		};

		//判断是否在指定区域中
		function getMarkerIndex(lineIndex,markers){
			var l;
			//console.log(markers,markers.length);	
			if(markers&&(l=markers.length)){
				for(var i=0;i<l;i++){
					//console.log(lineIndex,markers[i]);
					if(lineIndex>=(markers[i].startLine-1)&&lineIndex<=(markers[i].endLine-1)){
						return i;
					}
				}
			}
			return -1;
		}

		//transform service
		this.transformedCode=function(selector){
			var self=this,opts=this.options.transformedCode,otherEditor,codeData;

			/*if(data[0].targetFileId==options.module.id){
				url=common.config.codeContentUrl+data[0].sourceFileId+"&compareType=target";
			}else{
				url=common.config.codeContentUrl+data[0].targetFileId+"&compareType=source";
			}*/

			ide.util.ajax({
				url:opts.url+"&structureType="+self.options.code.structureType,
				type:"get",
				dataType:"json",
				success:function(d){
					var data=d.data.json,sourceBlocks=[],url;
					
					self.compareTransformation({
						readOnly:true,
						url:common.config.codeContentUrl+data[0].sourceFileId
					},function(){
						var editor=self.getEditor(),length;
						otherEditor=self.getOtherEditor();
						if(editor){
							//移除editor 上的markers
							editor.removeAllMarkers();

							if(data&&(length=data.length)){
								for(var i=0;i<length;i++){
									editor.addMarker(data[i].sourceBlock.startLine-1,data[i].sourceBlock.endLine-1);
									sourceBlocks.push(data[i].sourceBlock);
								}
								editor.scrollTo(data[0].sourceBlock.startLine,data[0].sourceBlock.endLine,true);
							}

							//注册editor click事件
							//根据指定的lines 触发相应的事件
							var _session=editor.getAceEditor().getSession();
							//移除changeCursor所有的事件
							//_session.selection.removeAllListeners("changeCursor");
							_session.selection.removeListener("changeCursor",_func);						
							_session.selection.on("changeCursor",_func,false);
						}
					});

					var _func=function(e,ace){
						var lineIndex=ace.getCursor().row,index;
						
						//清楚掉所有的marker
						otherEditor.removeAllMarkers();

						if((index=getMarkerIndex(lineIndex,sourceBlocks))>=0&&otherEditor&&self.isOtherEditorVisible()){
							//添加多个marker
							if(data[index].targetBlocks&&(l=data[index].targetBlocks.length)){
								for(var i=0;i<l;i++){
									var marker=data[index].targetBlocks[i];
									otherEditor.addMarker(marker.startLine-1,marker.endLine-1);
								}
							}
							//otherEditor.addMarkers(data[index].targetBlocks);
							otherEditor.scrollTo(data[index].targetBlocks[0].startLine,data[index].targetBlocks[0].endLine,true);
						}
					}
				}
			});
		};

		/*control*/
		this.callerAndCallee=function(selector){
			var opts=this.options.callerAndCallee;
			var callerAndCallee=ide.create('code.CallerAndCallee',this.$element.find(selector),{
				url: opts.url,
				click:function(data){
					if(data.id!="null"){
						repositoryService.openItemById(data.id)
					}
				}
			});
		}

		this.reference=function(selector){

			var self=this;
			var opts=this.options.reference;
			self.referenceRefresh=ide.create('code.Reference',this.$element.find(selector+"-"+this.options.code.id),{
				setting : {
					async: {
						type:"get",
						url:opts.url   //url格式  例如：/outline/2c9093cd4683e8bb014683e8be270001
					},
					view: {
						nameIsHTML: true,
						showTitle : true
					},
					callback: {
						onAsyncSuccess: function(event, treeId, treeNode, msg){
							
							var treeObj = $.fn.zTree.getZTreeObj(treeId);
							
							var nodes = treeObj.transformToArray(treeObj.getNodes());
							
							$.each(nodes,function(){
								
								if(this.level==0){
									this.icon = common.config.rootUrl+"assets/ide/img/repositoryIcons/ztree_reference_source.gif";
								}else if(this.nodeType=='TABLE'){
									this.icon = common.config.rootUrl+"assets/ide/img/repositoryIcons/ztree_table.png";
								}else if(this.nodeType=='FILE'){
									this.icon = common.config.rootUrl+"assets/ide/img/repositoryIcons/ztree_file.gif";
								}
								treeObj.updateNode(this);
							});
							treeObj.expandAll(true);
							
						}
					}
				},
				click:function(e,treeNode){
					if(treeNode.startLine!=null){
						self.getEditor().selectLines(treeNode.startLine-1,treeNode.endLine)
					}				
				}			
			});
		}

		this.jobFlow=function(selector){
			var opts=this.options.jobFlow;
			var jobflow=ide.create('code.JobFlow',this.$element.find(selector),{
				url:opts.url,
				click:function(e,id){
					if(id!="null"){
						repositoryService.openItemById(id)
					}
					
				}
			});
		}
		
		this.opc = function(selector){
			var opts = this.options.opc;
			var opc=ide.create('code.Opc',this.$element.find(selector),{
				url:opts.url,
				click:function(e,id){
					if(id!="null"){
						repositoryService.openItemById(id);
					}
				}
			});
		}



		this.toolsWidth=300;
		//初始化tools ui
		this.initTools=function(){
			var self=this,tools=this.ui.tools,selectors=this.selectors;
			
			
			tools.container.cgResize({
				handler:tools.resizeHandler,
				min:{
					width:300
				},
				iframeFix:false,
				direction:"w",
				opacity:1,
				cursor:"w-resize",
				resize:function(e,ui){
					/*var width=ui.currentSize.width,left=width+12,codeWidth=$(self.$element).width();
					width=codeWidth-200>=width?width:codeWidth-200;
					left=width+12;
					$(this).css({
						"width":width,
						"left":-left
					});*/

					var width=ui.currentSize.width,left=width+12,codeWidth=$(self.$element).width();
					width=codeWidth-200>=width?width:codeWidth-200;
					left=width;


					self.ui.editorBody.css({
						"margin-right":width
					})
					$(this).css({
						"width":width,
						"margin-left":-left
					});
					self.toolsWidth=width;

					//改变编辑器resize状态
					self.resize();
					return false;
				}
			});
			//close tools body
			tools.close.click(function(){
				self.hideTools();
			});
			tools.toggleButton.click(function(){
				self.hideTools();
			});
			//register tools menu
			tools.container.on("click",selectors.tools.menu,function(){
				self.showTools($(this).attr("data-service"));

			});
		}

		//隐藏tools
		this.hideTools=function(){
			var self=this,tools=this.ui.tools,selectors=this.selectors;
			removeActiveClass(null,tools,selectors);
			
			tools.resizeHandler.hide();
			//隐藏 code 工具条
			self.ui.editorBody.css({
				"margin-right":36
			})
			tools.container.css({
				"width":36,
				"margin-left":-36
			});
			tools.body.hide();

			//改变编辑器 resize 状态
			self.resize();
			
		}

		//移除active class
		//移除选中的code 按钮class
		function removeActiveClass(_menus,tools,selectors){
			//如果 _menus 未传递进来
			if(!_menus){
				_menus=tools.container.find(selectors.tools.menu);
			}			
			//_menus.find(".active").removeClass("active");
			_menus.filter(".ide-tools-menu-active").removeClass("ide-tools-menu-active");		
		}
		//flag ==true 表示不toggle 面板
		this.showTools=function(s,flag){
			
			var self=this,tools=this.ui.tools,selectors=this.selectors;

			var $this,_menus=tools.container.find(selectors.tools.menu);
			
			if(s){
				$this=_menus.filter("[data-service='"+s+"']");			
			}

			//如果单击的是当前的 menu 则关闭内容区域
			if($this.hasClass("ide-tools-menu-active")&&!flag){
				self.hideTools();
				return false;
			}

			tools.resizeHandler.show();

			removeActiveClass(_menus);
			
			//$this.find(".btn").addClass("active");
			$this.addClass("ide-tools-menu-active");
			
			var index=$this.index(),service=s,content=tools.contents.filter("[data-service-content='"+service+"']"),expand=$this.attr("data-expand");
			
			//将所有的菜单隐藏
			self.$element.find(".J_tools_menu_box").hide();
			//然后在每个service中显示指定的菜单
			self.$element.find("#J_"+service).show();
			
			if(expand=="false"){
				self[service].call(self,selectors.tools[service]);				
			}else{

				//显示 code 工具条
				self.ui.editorBody.css({
					"margin-right":this.toolsWidth
				})
				tools.container.css({
					"width":this.toolsWidth,
					"margin-left":-this.toolsWidth
				});
				tools.body.show();
				//改变编辑器 resize 状态
				self.resize();



				


				tools.title.html($this.attr("title"));

				if(content.data("initialize")){
					content.show().siblings().hide();
				}else{				
					service=$this.attr("data-service");
					content.show().siblings().hide();

					

					self[service].call(self,selectors.tools[service]);
					//缓存数据
					content.data("initialize",true);
				}
			}
		}

		this.resize=function(){
			var self=this;
			var _aceEditor=self.editorObject&&self.editorObject.getAceEditor(),_otherAceEditor=self.otherEditorObject&&self.otherEditorObject.getAceEditor();
			if(_aceEditor){
				_aceEditor.resize()
			}
			//self.editorObject&&self.editorObject.getAceEditor().resize();
			if(_otherAceEditor){
				_otherAceEditor.resize();
			}
			//self.otherEditorObject&&self.otherEditorObject.getAceEditor().resize();
		}
		/*end tools module*/
	}).call(Code.prototype);

	return Code;
});