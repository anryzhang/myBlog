/**
 * Created by ruizhang on 2014/8/8.
 * repositoryService 树功能对外的公用接口
 */
define(['jquery','ide','moduleCommon','sourcecode','repository'],function($,ide,common,sourcecode,repository){
   
//var repositoryService = (function (repositoryService, ide, repository, $, common) {
    var repositoryService = {};
    var repositoryWindow,
        sourceCodeCache=[],        
        sourceCode,
        options,
        optionsCache=[],
        pageNo = 0,
        pageSize = 50,
        contextMenu = $(common.config.selectors.repositoryContextMenu);


    //注册右键菜单事件
    function _initContextMenu(){
        repository.getContextMenu().on('click','[data-service]',function(){
            var $_this = $(this),
                service = $_this.attr('data-service');
            repositoryService[service].call(repositoryService, repository.getContextMenu().data('data'),$_this);
        });
    }

    //右键菜单
    function _initMenus(data){
        menu.disableRepositoryMenus();
        if(data.isSharedProjectForCurrentUser){
            //share 过来的项目, 右键菜单不显示
            return false;
        }

        var teamNav = ['teamUpdate','teamCommit','teamShowHistory'];
        //menu.enableMenus(teamNav);
        //获取根节点
        var _root = _getRootNode(data);
        //默认启用菜单
        menu.enableMenus(['downloadSourcecode']);
        if(data.id === data.projectId){
            //根节点
            //根节点显示的右键菜单
            var rootRightNav = ['shareProject','editProject','deleteProject','runTranslationInit','runTranslationImmediately'];

            menu.enableMenus(rootRightNav);
            if(data.operateMap && data.operateMap.MainframeProject){
                //ftp时
                //SourceCodeComplete  为true, 可以做bre 操作
                menu.disableMenus([].concat(privilege.analysis,'uploadSourceCode'));
                if(data.operateMap.SourceCodeComplete){
                    menu.enableMenus([].concat(privilege.checkstyle,privilege.analysis,'runDuplicationAnalysis'));
                }else{
                    menu.disableMenus(["editProjectTypeMapping"].concat(privilege.checkstyle,'runDuplicationAnalysis'));
                }

            }else{
                //非ftp时
                //1.没有上传代码  不能做分析
                //2.有上传代码  可以做分析
                var rootAllNav = rootRightNav.concat('uploadSourceCode');
                menu.enableMenus(rootAllNav);
                if(data.operateMap.SourceCodeComplete){
                    // 有上传代码时:
                    menu.enableMenus(['runAnalysis','runDuplicationAnalysis','runAnalysisSchedule'].concat(privilege.checkstyle,'editProjectTypeMapping'));
                }else{
                    menu.disableMenus(['runAnalysis','runDuplicationAnalysis','runAnalysisSchedule'].concat(privilege.analysis,privilege.checkstyle));
                }

            }

            //transformation 为true 时, 初始化一次
            var isInit = data.operateMap.transformation = true;
            if(isInit){
                menu.enableMenus(['runTransformationInit','runTransformationImmediately']);
            }else{
                menu.enableMenus(['runTransformationInit','runTransformationImmediately']);
                menu.disableMenus(['runTransformationInit']);
            }

        }else{
            //非根节点
            var foldRightNav = ['newFile','newFolder'];
            var commRightNav = ['editFileFolder','deleteFileOrFolder'];
            //非跟节点,快捷菜单upload不可用
            menu.disableMenus(['uploadSourceCode']);

            if(data.isParent){
                //是文件夹时
                menu.enableMenus(foldRightNav);
                //是源码时
                //是ftp时,才有team commit 与 upload to mainframe菜单
                if(_root.operateMap.MainframeProject && data.structureType == '1'){
                    menu.enableMenus(['teamCommit','uploadToMainframe']);
                }

                if(data.pId != data.projectId){
                    //不是根节点文件夹时
                    menu.enableMenus(commRightNav);
                }
            }else{
                //是文件时
                commRightNav = ['editFileFolder','deleteFileOrFolder']
                menu.enableMenus(commRightNav);
                if(_root.operateMap.MainframeProject && data.structureType == '1'){
                    menu.enableMenus(['teamCommit','teamShowHistory']);
                }
                if(data.structureType == '1'){
                    menu.enableMenus(['updateFileType']);
                }
                //判断 是否有 run test 菜单
                if(data.fileType === 'RULE'){
                    menu.enableMenus(['runTest']);
                }
                //判断 是否是job文件类型,是就显示 run菜单
                if(data.fileType == 'JOB'){
                    menu.enableMenus(['runJob']);
                }else{
                    menu.disableMenus(['runJob']);
                }

                if(data.fileType=="PGM" || data.fileType=="PL1"){
                    menu.enableMenus(["compile"]);
                }else{
                    menu.disableMenus(["compile"]);
                }
            }

        }
    }

    //扩展右键菜单
    function _extendOptions(options){
        //右键或点击树节点,设置主菜单项
        options.beforeRightClick = options.beforeClick = function(data){
         //单选处理
            console.log(data);

            sourceCode.selectItem(data,false);
            _initMenus(data);
         };

        options.rightClick = function(e,data){
            var height = common.getMainWindowHeight();
            repository.getContextMenu().data("data",data);

            //显示菜单位置
            var contextMenuHeight = common.getContextMenuHeight(repository.getContextMenu()) + 50;
            repository.setContextMenuPosition(e.pageX+10, common.getContextMenuTop(e.pageY+10 , contextMenuHeight, height));
            repository.showContextMenu();
            return false;

        };

        //双击
        options.DBclick = function(e,data){
            repository.getContextMenu().data('data', data);
            if(data && data.role > 99){
                repositoryService.getMore(data);
            }else{
                if(data && !data.isParent){
                    _openItem(data);
                }
            }
        }

    }
    //打开选择的节点
    function _openItem(data,params){
        if(typeof data != 'undefined'){
            var OpenItemURL = common.config.codeUrl;
            OpenItemURL += "/?codeFileId=" + data.id;
            OpenItemURL += "&structureType=" + data.structureType;
            OpenItemURL += "&fileType=" + data.fileType;
            OpenItemURL += "&projectId=" + data.projectId;
            OpenItemURL += "&parentId=" + data.pId;


            if(data.isSharedProjectForCurrentUser){
                if(!data.isCreateByAdmin){
                    OpenItemURL += "&readOnly=" +1;
                }else{
                    OpenItemURL += "&readOnly=" +0;
                }
            }
            

            if(!data.isParent){
                //文件时
                if(params){
                    for(var key in params){
                        OpenItemURL += "&" + key + "=" + params[key];
                    }
                }
                if(data.target == '_tab'){
                    OpenItemURL = common.config.rootUrl + data.path;
                }
                var fileTitle;
                if(data.isSharedProjectForCurrentUser){
                    fileTitle = data.name + ' [S]';
                }else{
                    fileTitle = data.name;
                }
                var opt = {
                    id: data.id,
                    href: OpenItemURL,
                    pId: data.pId,
                    projectId: data.projectId,
                    title: fileTitle,
                    domTitle:data.filePath,
                    readOnly:data.isSharedProjectForCurrentUser&&!data.isCreateByAdmin?true:false
                }

                main.addCodeTab(opt);
            }
        }else{
            ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
        }
    }

    //得到节点的父节点
    function _getNodesByParentNode(treeNode,inputPageNo, inputPageSize, callback){
        var postData = {
            userId: treeNode.userId,
            projectId: treeNode.projectId,
            pageSize: inputPageSize,
            pageNo: inputPageNo,
            nodeId: treeNode.moreId || treeNode.id
        };

        var href = common.config.rootUrl + 'loadNodesByParentId';
        $.ajax({
           type:'POST',
            url:href,
            contentType: 'application/json',
            dataType:'json',
            data: JSON.stringify(postData)
        }).done(function(rs){
            callback && callback.call(this,rs);
        });

    }

    //请求 nodes
    function _ajaxGetNodes(treeNode, inputPageNo, inputPageSize){
        _getNodesByParentNode(treeNode,inputPageNo,inputPageSize,function(nodes){
            if(nodes.nodes){
                if(nodes.pageNo + 1 < nodes.totalPageSize){
                    var clickMore = {
                        "name":"more...",
                        "id": nodes.nodes[0].id + 123,
                        "pageNo":nodes.pageNo + 1,
                        "pageSize": nodes.pageSize,
                        "userId": nodes.nodes[0].userId,
                        "projectId": nodes.nodes[0].projectId,
                        "role": 200,
                        "moreId":nodes.nodes[0].pId,
                        "icon":ide.config.icon.more
                    };
                    nodes.nodes.push(clickMore);
                }

                if(treeNode.role){
                    sourceCode.addItem(treeNode.getParentNode(), nodes.nodes);
                    sourceCode.deleteItem(treeNode);
        }else{
            sourceCode.addItem(treeNode, nodes.nodes, false);
        }

    }

});
}

function _getRootNode(node) {
    //返回根节点
    var root = false;
    if (!node) {
        node = sourceCode.getSelectedItems()[0];
        }
        if (node) {
            while (!node.operateMap) {
                node = node.getParentNode();
            }
            root = node;
        }
        return root;
    }

    function _getRootNodes(nodes){
        //返回根节点列表
        var roots = [];
        if(nodes){
            for(var i = 0; i <  root.length; i++){
                var root = _getRootNode(nodes[i]);
                roots.push(root)
            }
        }else{
            return false
        }
        return roots;
    }

    function _getFolderByParentNode(node) {
        // 获取文件的父节点id
        var foldersId = [];
        if (node.children && node.children.length > 0) {
            foldersId.push(node.id);
            for(var i =0;i<node.children.length; i++){
                if(node.children[i].isParent){
                    //console.log(foldersId);
                    foldersId=foldersId.concat(_getFolderByParentNode(node.children[i]));
                    //console.log(foldersId);
                }
            }
            return foldersId;
        }

    }

    function _deleteNode(node,flag){
        // flag : 是否删除树上节点。
        // flag true 删除树上节点
        // flag false 不删除树上节点。
        // node is a project node
        // ndoe.operateMap无法判断是项目文件夹
        // node.id===node.projectId

        if(node && node.id == node.projectId){
            var href = common.config.rootUrl + 'ide/delete_project?projectId=' + node.projectId;
            $.ajax({
                dataType:'text',
                url:href,
                type:'POST',
                success:function(rs){
                    var rsd = {
                        responseText: rs
                    }
                    if(rsd.responseText == 'success'){
                        if(flag){
                            sourceCode.deleteItem(node);
                        }
                        //删除项目打开的文件
                        main.closeCodeTabsByParams({
                            projectId: node.projectId
                        },true)
                    }else{
                        ide.util.alert(ide.i18n.repository.delProjectFailed, null, 2);
                    }
                }
            });
            return ;
        }

        //node is a folder
        if(node && node.isParent){
            ide.util.ajax({
               url:common.config.rootUrl + 'codefiles/deleteCodefiles/' + node.id,
                type:'GET',
                success:function(rs){
                    if(flag){
                        sourceCode.deleteItem(node);
                    }
                    var folderIds = _getFolderByParentNode(node);
                    if(!folderIds){
                        return false;
                    }
                    for(var i = 0; i< folderIds.length; i++){
                        main.closeCodeTabsByParams({
                            pId: folderIds[i]
                        },true);
                    }
                }
            });
            return ;
        }

        // node is a file
        if(node){
            ide.util.ajax({
               url: common.config.rootUrl + 'codefiles/deleteCodefiles/' + node.id,
                type:'GET',
                success: function(rs){
                    if(flag){
                        sourceCode.deleteItem(node);
                    }
                    main && main.closeCodeTabById(node.id, true);
                }
            });
            return ;
        }

    }

    function _deleteNodeById (id){
        var node = sourceCode.getItemById(id)[0];
        //debugger;
        if(node){
            //if the repository tree  contain this node
            _deleteNode(node,true);
        }
        else{
            //if the repository tree not contain this node find it from database
            var flag = false;
            var href = common.config.rootUrl + "ide/findFileById/" + id;
            $.ajax({
                dataType: 'json',
                url: href,
                type: 'GET',
                success: function(rs) {
                   if (rs != "") {
                       _deleteNode(rs, false);
                       e.data.dialog.close();
                   } else {
                       ide.util.alert(ide.i18n.repository.deleteFileNo, null, 2);
                   }
                }
            });

        }

    }
    //点击节点,发送是否打开节点,true ,false
    function _updateNodeOpenStatus(treeNode){
        var postData={}
        postData.isOpen = (treeNode.open === true ? false : true);
        postData.projectId =treeNode.projectId;
        postData.id=treeNode.id;
        var href = common.config.rootUrl + 'loadNodesByParentId';
        $.ajax({
            dataType: 'json',
            url: href,
            contentType: 'application/json',
            type: 'POST',
            data: JSON.stringify(postData)
        }).done(function(data, textStatus, jqXHR) {
            //callback && callback.call(this, data);
            if(!data.status ==  200){
                ide.util.alert(data.msg,null,3);
            }
        });
    }

    repositoryService = {
        /*
        * 初始化项目
        * element jquery Dom 节点
        * arg ztree 参数
        * */
        init:function(element, arg, flag){
            var self = this;
            options = arg;
            if(!repository.getContextMenu().data('initialize')){
                _initContextMenu(options.type);
                //_initSearch();此方法好像没有用
                repository.getContextMenu().data('initialize',true);
            }
            _extendOptions(options);

            //如果 flag != true get all projects
            //如果 flag == true add a new projects into empty tree
            //debugger;
            if(!flag){
                var href = common.config.rootUrl + "loadProjectFileStructure";
                if(options.userId){
                    href+="/"+options.userId;
                }
                $.ajax({
                    type:'GET',
                    url: href,
                    dataType: 'json'
                }).done(function(rs,textStatus,jqXHR){
                    //console.log(rs);
                    options.nodes = rs;
                    sourceCode = new ide.repository.SourceCode(element,options);

                    self.beforeUnload();

                    ide.status.repositorycompleted=true;
                    $(window).trigger("repositorycompleted");

                    var _userId = element.attr("data-user");
                    sourceCodeCache[_userId]=sourceCode;
                    optionsCache[_userId]=options;
                });
            }

            //console.log(element);
            //储存当前操作的窗口
            $(element).on('focusin',function(){
                main.setFocusObject(repositoryService);
            });


        },
        changeRepository:function(id){

            sourceCode = sourceCodeCache[id];
            options = optionsCache[id];
        },
        addDiyDom:function(treeId,treeNode){
            //在节点上固定显示自定义控件
            var self = this;
            var aObj = $('#' + treeNode.tId + '_a');

            if(treeNode.id != treeNode.projectId){
                return false;
            }
            //ftp的图标 [F]
            /*if(treeNode.operateMap.MainframeProject){
                aObj.append(ide.config.icon.ftp);
            }*/
            // Analysis 的图标 [A]
            if(treeNode.operateMap.SystemAnalysis){
                aObj.append(ide.config.icon.analysis);
            }
            // translation 的图标 [T]
            if(treeNode.operateMap.Translation){
                aObj.append(ide.config.icon.translation);
            }
            //share 的 图标 [S]
            if(treeNode.operateMap.ShareToUser){
                aObj.append(ide.config.icon.share);
            }

        },
        beforeUnload:function(){
            //页面重载前事件,获取打开的节点状态
            var self = this;
            self.getNodeOpenStatus();
        },
        getNodeOpenStatus:function(){
            //获取已经打开的树的节点状态
            var self = this;
            var node = sourceCode.tree.getNodes(),
                nodes = sourceCode.getOpenItemsByFilter(function(node){
                    return node.open === true;
                });
            var openNodes = [];
            for(var i = 0; i < nodes.length; i++){
                var openId = {
                    id: nodes[i].id
                }
                openNodes.push(openId);
            }
            return openNodes;
        },
        getSourceCode:function(){
            //return sourceCode for other service
            if(typeof sourceCode == 'undefined'){
                return null;
            }else{
                return sourceCode;
            }

        },
        getSelectedItems:function(){
            //获取选中的节点的数据,返回一个JSON对象
            return sourceCode.getSelectedItems();
        },
        getMore:function(node){
            //动态加载节点
            _ajaxGetNodes(node, node.pageNo, node.pageSize, node.userId, node.projectId);
        },
        openItem:function(item, params){
            //打开树节点
            //params 双击时,触发 url 参数
            if(item && item.length > 0){
                _openItem(item,params);
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
            }
        },
        openItems:function(item,params){
            // 打开树节点
            // item 为数组
            // params 双击时候 触发的URL 参数
            var self = this;
           if(item && item.length >0){
               for(var i = 0; i< item.length; i++){
                   _openItem(item[i],params);
               }
           }else{
                var items = self.getSelectedFiles();
               if(items.length > 0){
                   for(var i = 0; i < items.length; i++){
                       _openItem(items[i],params);
                   }
               }else{
                   ide.util.alert(ide.i18n.repository.needSelectFile,null,3);
               }
           }
        },
        openItemById:function(id, params){
            //通过 id 获取节点,打开树节点
            var self = this;
            if(typeof id != 'undefined'){
                var node = sourceCode.getItemById(id);
                if(node.length > 0){
                    _openItem(node[0],params);
                }else{
                    var flag = false;
                    var href = common.config.rootUrl + "ide/findFileById/" + id;
                    $.ajax({
                       type:'Get',
                        url:href,
                        dataType:'json',
                        success:function(rs){
                            if(rs){
                                _openItem(rs,params);
                            }else{
                                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
                            }
                        }

                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null,3);
            }
        },
        getSelectedFiles:function(){
            // 获取选中的文件
            var self = this;
            var tree = self.getSourceCode(),
                files = tree.getSelectedItems();
            return _.filter(files,function(data,index){
                return !data.isParent;
            })
        },
        getSelectedFileIds:function(){
            //返回选中文件的Id
            var self = this;
            var files = self.getSelectedFiles(),
                ids = [];
            for(var i = 0; i < files.length; i++){
                ids.push(files[i].id);
            }
            return ids;
        },
        getSelectedFolders:function(){
            //返回选中的文件夹
            var self = this;
            var tree = self.getSourceCode(),
                files = tree.getSelectedItems();
            return _.filter(files,function(data,index){
               return data.isParent;
            });
        },
        getSelectedFolderIds:function(){
            //返回选中文件夹的 id
            var self = this;
            var folders = self.getSelectedFolders(),
                ids = [];
            for(var i = 0; i < folders.length; i++){
                ids.push(folders[i].id);
            }
            return ids;
        },
        getAllItems:function(){
            //返回树中的所有项目
            var self = this;
            return sourceCode.getAllItems();
        },
        beforeExpand:function(treeId, treeNode){
            //扩展节点打开前事件
            if(!treeNode.isExpanded){
                _ajaxGetNodes(treeNode, pageNo,pageSize);
                treeNode.isExpanded = true;
                sourceCode.updateItem(treeNode);
            }
            return true;

        },
        beforeCollapse:function(treeId, treeNode){
          //节点关闭前事件
            var self = this;
            if(treeNode.isExpanded){
                treeNode.isExpanded = false;
                sourceCode.updateItem(treeNode);
            }
        },
        onAsyncSuccess:function(event, treeId, treeNode, msg){
            // 异步加载成功后，弹出提示信息
            _ajaxGetNodes(treeNode, pageNo,pageSize);
            ide.util.alert(msg, null, 3);
            return true;

        },
        onAsyncError:function(){

        },
        addProject:function(node){
            // add a project;
            var self = this;
            var tree = self.getSourceCode(),
                _reopsitory = repository;
            if(!sourceCode){
                self.init(_reopsitory.getUI().treeId,{
                    nodes: node.nodes,
                    setting:{
                        view: {
                            fontCss: self.getFontCss(),
                            nameIsHTML: true
                        },
                        callback:{
                            beforeExpand: self.beforeExpand,
                            onAsyncSuccess: self.onAsyncSuccess,
                            onAsyncError: self.onAsyncError
                        }
                    },
                    type:1

                },true);
            }else{
                repository.addFolder(null, node.nodes[0], sourceCode);
                var nodes = sourceCode.getAllItems();
                sourceCode.moveItem(nodes[0], nodes[nodes.length-1],'prev');
                //新建project 时,选中project 节点
                tree.selectItem(tree.getItemsByParam('id',node.nodes[0].id,null)[0],false);
            }
        },
        updateProject:function(node){
            // update project
            var self = this;
            if(typeof node != 'undefined'){
                var selector = sourceCode.getSelectedItems();
                var nodes = _getRootNode(selector[0]);
                if(!node){
                    ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                    return false;
                }
                nodes.name = node.nodes[0].name;
                sourceCode.updateItem(nodes);
            }
        },
        newProject:function(){
            // new project
            var self = this;
            var dialog = self.newProject.dialog = ide.util.dialog({
               title: 'New Project',
                href: common.config.rootUrl + "page/main_newProject.html",
                iframe:false,
                width:830,
                height:620,
                modal:true,
                buttons:[{
                    text:'Save',
                    handler: function(e){
                        if(self.newProject.submit){
                            self.newProject.submit();
                        }
                    }
                },{
                    text: ide.i18n.dialogCancelButtonText,
                    handler:function(e){
                        e.data.dialog.close();
                    }
                }],
                success:function(){
                    require(['newProject'],function(newProject){
                        newProject.init();
                        self.newProject.initProject();
                    })

                }
            });
        },
        editProject:function(){
            //edit project
            var self = this;
            var item  = sourceCode.getSelectedItem(),
                projectId;
            if(item && item.length){
                projectId = item[0].projectId;
                if(projectId){
                    var dialog = self.editProject.dialog = ide.util.dialog({
                        title:'Edit Project',
                        href: common.config.rootUrl + 'page/edit_Project.html',
                        iframe: false,
                        width: 830,
                        height: 620,
                        modal:true,
                        buttons:[{
                            text:'Save',
                            handler:function(e){
                                if(self.editProject.submit){
                                    self.editProject.submit();
                                }
                            }
                        },{
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                           // self.editProject.initProject();
                            require(['editProject'],function(editProject){
                                editProject.init();
                                self.editProject.initProject();
                            });
                        }
                    });
                }

            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject,null, 3);
            }

        },
        uploadSourceCode:function(node){
            //upload source code
            var self = this;
            var id;
            //console.log(node);
            if(typeof node === 'string'){
                id = node;
            }else{
                node = _getRootNode(node);
                if(!node){
                    ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                }
                id = node.projectId;
            }

            if(!id){
                return ;
            }

            var dialog = self.uploadSourceCode.dialog = ide.util.dialog({
                title:'Upload',
                href:common.config.rootUrl + 'ide/projects/upload/' + id,
                width:498,
                height: 433,
                //height: 316,
                modal:true,
                iframe:false
            });
        },
        updateProjectStatus:function(projectId){
            //update project status
            var self = this;
            if(projectId){
                var href = common.config.rootUrl + 'ide/getProgetcOperateStatus/' + projectId;
                $.ajax({
                    type:'GET',
                    url:href,
                    dataType:'json',
                    success:function(rs){
                        var root = sourceCode.getItemById(rs.id, null);
                        root = $.extend(root[0], rs);
                        sourceCode.updateItem(root);
                    }
                });
            }
        },
        editProjectTypeMapping:function(node){
            //edit file type mapping
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if(node && node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject)){
                var dialog = self.editProjectTypeMapping.dialog = ide.util.dialog({
                    title: 'File Type Mapping',
                    iframe:false,
                    href:common.config.rootUrl + 'ide/fileTypeMapping/' + node.projectId + '/' + node.id,
                    width:500,
                    height: 400,
                    modal:true,
                    closable: true,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler: function(e){
                            //var win = dialog.getIframeWindow();
                            //console.log(e);
                            //if(win && win.jQuery){
                            self.editProjectTypeMapping.submit && self.editProjectTypeMapping.submit();
                            //}
                        }
                    },{
                        text: ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }]
                });
            }else{
                ide.util.alert(ide.i18n.repository.needUploadorCheckout,null,3);
            }

        },
        checkout:function(node){
            // checkout code
            var self = this;
            if(!node){
                ide.util.alert(ide.i18n.needSelectProject,null,2);
                return false;
            }
            var href = common.config.rootUrl + 'checkOutProject/' + node.projectId;
            $.ajax({
                type:'GET',
                dataType:'json',
                url:href,
                success:function(rs){
                    if(rs.status != 200){
                        ide.util.alert(rs.message,null,2);
                    }else{
                        self.updateProjectStatus(node.projectId);
                        //edit file type mapping
                        var dialog = self.editProjectTypeMapping.dialog = ide.util.dialog({
                            title:'File Type Mapping',
                            iframe: true,
                            href: common.config.rootUrl + 'ide/fileTypeMapping/' + node.projectId + '/' + node.id,
                            width: 500,
                            height:400,
                            modal:true,
                            closable:true,
                            buttons:[{
                                text: ide.i18n.dialogOkButtonText,
                                handler:function(){
                                    var win = dialog.getIframeWindow();
                                    if(win && win.jQuery){

                                        self.editProjectTypeMapping.submit();
                                    }
                                }
                            },{
                                text: ide.i18n.dialogCancelButtonText,
                                handler: function(e){
                                    e.data.dialog.close();
                                }
                            }]
                        });
                    }
                }
            });
        },
        deleteProject:function(node){
            //delete project
            var self = this;

            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }

            

            if(typeof node != 'undefined'){
                var tips="";
                //如果此项目是通过ftp下载，而且还没下载完成
                if(node.operateMap&&node.operateMap.MainframeProject&&!node.operateMap.SourceCodeComplete){
                    tips= ide.i18n.repository.projectDownloaded;
                }
                tips += ide.i18n.repository.deleteProjectConfirm;
                ide.util.confirm(tips,function(e){
                    var href = common.config.rootUrl + 'ide/delete_project?projectId=' + node.projectId;
                    $.ajax({
                        type:'POST',
                        url:href,
                        dataType:'text',
                        success:function(rs){
                            if(rs == 'success'){
                                sourceCode.deleteItem(node);
                                main.closeCodeTabsByParams({
                                    projectId:node.projectId
                                },true);
                                e.data.dialog.close();
                            }else{
                                ide.util.alert(ide.i18n.repository.delProjectFailed,null,2);
                            }
                        }
                    });
                });
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject,null,3);
            }

        },
        deleteFileOrFolder:function(node){
            //delete file or folder
            var self = this;

            //右键删除多个文件
            /*var confirmContent = deleteConfirm;
             var selectItems = sourceCode.getSelectedItems();
             console.log(selectItems);
             if(selectItems.length>0){
             ide.util.confirm(confirmContent, function(e){
             for (var i = 0; i<selectItems.length;i++){
             sourceCode.deleteItem(selectItems[i]);
             }
             e.data.dialog.close();
             });
             }else{
             ide.util.alert(ide.i18n.needSelectFile,null,3);
             }*/

            var confirmContent = ide.i18n.repository.deleteConfirm;
            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }
            if(node){
                if(node.id === node.projectId){
                    confirmContent = ide.i18n.repository.deleteProjectConfirm;
                }
                ide.util.confirm(confirmContent, function(e){
                    _deleteNode(node,true);
                    e.data.dialog.close();
                });

            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile, null, 3);
            }


        },
        deleteItemById: function(id){
            //delete item by id
            var self = this;
            if(typeof id != 'undefined'){
                ide.util.confirm(ide.i18n.repository.deleteConfirm,function(e){
                   _deleteNodeById(id);
                });
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
            }
        },
        deleteItemsByIds:function(ids){
            //通过id数组删除文件
            var self = this;
            if(ids){
                ide.util.confirm(ide.i18n.repository.deleteConfirm, function(e){
                   for(var i=0; i < ids.length; i++){
                       var node = sourceCode.getItemById(ids[i]);
                       var href = common.config.rootUrl + 'codefiles/deleteCodefiles/' + ids[i];
                       if (node.length > 0){
                           ide.util.ajax({
                                url:href,
                               type:'GET',
                               success:function(rs){
                                   var nodes = sourceCode.getSelectedItems();
                                   sourceCode.deleteItem(nodes);
                               }
                           });
                       }else{
                           var flag = false;
                           var href = common.config.rootUrl + 'ide/findFileById' + ids[i];
                           $.ajax({
                              type:'GET',
                               url:href,
                               dataType:'json',
                               success:function(rs){
                                   if(rs){
                                       var delHref = common.config.rootUrl + 'codefiles/deleteCodefiles/' + rs.id;
                                       ide.util.ajax({
                                          url:delHref,
                                          type:'GET',
                                          success:function(){
                                              var node = sourceCode.getSelectedItems();
                                              sourceCode.deleteItem(node);
                                          }
                                       });
                                   }else{
                                       ide.util.alert(ide.i18n.repository.deleteFileNo,null, 3);
                                   }
                               }
                           });
                       }
                   }
                });
            }else{
                ide.util.alert(ide.i18n.repository.fileNo,null,3);
            }


        },
        deleteItems:function(item){
            //source code deleteItem 删除多个item
            var self = this;
            var confirmStr = ide.i18n.repository.deleteConfirm;
            if(item && item.length > 0){
                if(item[0].id === item[0].projectId){
                    confirmStr = ide.i18n.repository.deleteProjectConfirm
                }
                ide.util.confirm(confirmStr, function(e){
                    for(var i = 0; i < item.length; i++){
                        _deleteNodeById(item[i].id);
                    }
                    e.data.dialog.close();
                });
            }else{
                var node = sourceCode.getSelectedItems();

                if(!node.length){
                    ide.util.alert(ide.i18n.repository.needSelectFile,null, 3);
                    return false;
                }
                if(node && node[0].id === node[0].projectId){
                    var tips="";
                    if(node[0].operateMap&&node[0].operateMap.MainframeProject&&!node[0].operateMap.SourceCodeComplete){
                        tips=ide.i18n.repository.projectDownloaded;
                    }
                    confirmStr = tips+ide.i18n.repository.deleteProjectConfirm;
                }
                if(node.length>0){
                    ide.util.confirm(confirmStr, function(e){
                        for(var i = 0; i < node.length; i++){
                            _deleteNodeById(node[i].id);
                        }
                        e.data.dialog.close();
                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needSelectFile, null, 3);
                }
            }
        },
        addFolderByNodes:function(node){
            // 通过节点添加文件夹
            //  this function is for translation and transformation
            //  when translation/transformation finished the tree will add root folder
            var self = this;
            if(node && node.name){
                var pNode = sourceCode.getItemsByParam('name', node.name);
                if(pNode){
                    sourceCode.updateItem(node);
                }else{
                    sourceCode.addItem(node.pId,node);
                }
            }else{
                sourceCode.addItem(node.nodes.parentId,node.nodes);
            }
        },
        openItemByIds: function(ids,params){
            //通过 id数组 搜索文件
            var self = this;
            var len;
            if(ids && (len = ids.length)){
                for(var i = 0; i < len; i++){
                    self.openItemById(ids[i], params);
                }
            }else{
                ide.util.alert(ide.i18n.repository.fileNo, null, 3);
            }
        },
        updateFileType:function(node){
          //更新 file type;
            var self = this;

            if(typeof node == 'undefined'){ 
                node = sourceCode.getSelectedItems()[0];
            }

            if(typeof node == 'undefined'){ 
                ide.util.alert(ide.i18n.repository.needSelectFile, null, 3);
                return ;
            }

           
            

            var codeObj= main.getCodeById(node.id);

            if(codeObj && codeObj.isModified()){
                codeObj.saveModifiedFile();
                return;
            }
           
            var href = common.config.rootUrl + 'ide/updateFileType/' + node.id;
            var dialog = self.updateFileType.dialog = ide.util.dialog({
                title:'Update File Type',
                iframe: false,
                href: href,
                width: 800,
                height:300,
                modal:true,
                closeable:true,
                buttons:[{
                    text: ide.i18n.dialogOkButtonText,
                    handler:function(){
                        self.updateFileType.submit &&  self.updateFileType.submit();
                    }
                },{
                    text:ide.i18n.dialogCancelButtonText,
                    handler: function(e){
                        e.data.dialog.close();
                    }
                }]
            });


        },
        newFile: function(parentNode){
            //add new file
            var self = this;
            if(typeof parentNode == 'undefined'){
                parentNode = sourceCode.getSelectedItems()[0];
            }
            if(parentNode && !parentNode.isExpanded){
                sourceCode.expand(parentNode);
            }
            if(parentNode){
                //根节点不允许添加文件
                if(parentNode.id == parentNode.projectId){
                    ide.util.alert(ide.i18n.repository.disableAddFile,null,3);
                    return false;
                }

                var href = common.config.rootUrl + 'ide/newFile';
                var dialog = self.newFile.dialog = ide.util.dialog({
                    title:'New File',
                    iframe: false,
                    href: href,
                    width: 800,
                    height:300,
                    modal:true,
                    closeable:true,
                    buttons:[{
                        text: ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFile.submit &&  self.newFile.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }]
                })
            }else{
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
            }
        },
        newFolder:function(node,flag){
            // add new folder
            //input : flag = true -> edit folder /
            // flag = false -> new folder
            var self = this;
            if(typeof node == 'undefined'){
                node = sourceCode.getSelectedItems()[0];
            }
            if(node && node.isExpanded){
                sourceCode.expand(node);
            }
            
            if(node){

                var href=common.config.rootUrl + "ide/newFolder",title="New Folder";

                //flag == true 时 修改文件夹
                if(typeof flag =="boolean" && flag){
                    href=common.config.rootUrl + "ide/editFolder/"+node.id+"/"+node.name;
                    title="Rename Folder";
                }
                var dialog =  self.newFolder.dialog = ide.util.popupDialog({
                    title: title,
                    iframe: false,
                    href: href,
                    width:400,
                    height:150,
                    modal:true,
                    closable:false,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFolder.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }]
                });

            }else{
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
            }
        },
        addNewFolder:function(p, src, message, type, time, callback){
                var self = this;
                var pg = main.progress(message, {
                    defaultProgress: 60,
                    defaultTimes: time
                });
                ide.util.log.i(message);
                main.showProgress();
                var node;
                $.ajax({
                    url: src,
                    dataType: "json",
                    type: "get",
                    success: function(data) {
                        showMessage(message, type);
                        pg.complete(time - 2000);
                        setTimeout(function() {
                            node = repository.addFolder(p, data)[0];
                            repository.expand(node);
                            ide.util.log.i("Generate files completed");
                            if (message == "Run Bre") {
                                $("#" + node.children[0].children[0].tId + "_a").trigger("click");
                            }

                            if (callback) {
                                callback.call(this);
                            }
                        }, time - 4000);

                    }
                });
                return node;
        },
        editFileFolder:function(node){
            //编辑文件或文件夹
            var self = this;
            if(typeof node == 'undefined'){
                ide.util.alert(ide.i18n.repository.needSelectFolder, null, 3);
                return ;
            }
            if(!node.isParent){
                var dialog = self.newFile.dialog = ide.util.popupDialog({
                   title:'Rename',
                    iframe:false,
                    href:common.config.rootUrl + 'ide/editFile/' + node.id + '/' + node.name,
                    width: 400,
                    height: 150,
                    modal: true,
                    closable:false,
                    buttons:[{
                        text: ide.i18n.dialogOkButtonText,
                        handler:function(){
                            self.newFile.submit();
                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                        }
                    }]
                });
            }else{
                self.newFolder(node,true);
            }

        },
        selectFiles:function(options,callback){
            /**
             * 选择文件，点击Ok 按钮获取选中的文件
             * @param  {[Object]}   options 配置参数 pId必填 为父节点目录
             * @param  {Function} callback 点击ok按钮的回调函数
             */
            var self = this;
            options = options || {};

            if(typeof options.pId != 'undefined'){
                self.selectFiles.dialog = ide.util.dialog({
                    title:'Select File',
                    width:800,
                    height: options.height||540,
                    iframe: false,
                    modal: true,
                    href: common.config.rootUrl + 'page/select_file.html',
                    buttons:[{
                        text:'OK',
                        handler: function(e){
                            console.log(callback);
                            callback && $.isFunction(callback) && callback.call(this,e,self.selectFiles.getSelectedFiles());
                        }
                    },{
                        text: ide.i18n.dialogCancelButtonText,
                        handler: function(e){
                            e.data.dialog.close();
                        }
                    }],
                    success:function(){

                        require(['selectFile'],function(selectFile){

                            selectFile.init();
                            self.selectFiles.init({
                                pId:options.pId,
                                max:options.max,
                                searchable:options.searchable,
                                columns:options.columns,
                                url:options.url,
                                params:options.params,
                                customParams:options.customParams
                            });

                        });

                    }
                })
            }

        },
        runTranslationInit:function(node){
           // run init translation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            var href = common.config.rootUrl + 'translation/init/' + node.projectId;
            $.ajax({
                dataType: 'json',
                url: href,
                type: 'POST',
                success:function(rs) {

                    if (rs.length) {
                        for (var i = 0; i < rs.length; i++) {
                            //if node exits , updata this nodes.
                            var pNode = sourceCode.getItemsByParam("name", rs[i].name, node);
                            if (pNode.length > 0) {
                                sourceCode.deleteItem(pNode[0]);
                                sourceCode.addItem(node, rs[i]);
                            } else {
                                sourceCode.addItem(node, rs[i]);
                            }
                        }
                    } else {
                        var pNode = sourceCode.getItemsByParam("name", rs.name, node);
                        if (pNode.length > 0) {
                            sourceCode.deleteItem(pNode[0]);
                            sourceCode.addItem(node, rs);
                        } else {
                            sourceCode.addItem(node, rs);
                        }
                    }
                }
            });

        },
        runTranslationImmediately:function(node){
            //run translation immediately
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            if(node){
                if(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject){
                    var projectId = node.projectId;
                    var progress = new ide.util.progress("translating", {
                            type: 1,
                            complete: function() {
                                var href = common.config.rootUrl + 'codetranslation/getTranslatedCode/' + projectId;
                                $.ajax({
                                    url: href,
                                    type: "GET",
                                    success: function(rs) {
                                        //ide.util.log.i(data.msg);
                                        rs = $.parseJSON(rs);
                                        if (rs.length) {
                                            for (var i = 0; i < rs.length; i++) {
                                                //if node exits , updata this nodes.
                                                var pNode = sourceCode.getItemsByParam("name", rs[i].name, node);
                                                if (pNode.length>0) {
                                                    sourceCode.deleteItem(pNode[0]);
                                                    sourceCode.addItem(node, rs[i]);
                                                } else {
                                                    sourceCode.addItem(node, rs[i]);
                                                }
                                            }
                                        } else {
                                            var pNode = sourceCode.getItemsByParam("name", rs.name, node);
                                            if (pNode.length>0) {
                                                sourceCode.deleteItem(pNode[0]);
                                                sourceCode.addItem(node, rs);
                                            } else {
                                                sourceCode.addItem(node, rs);
                                            }
                                        }

                                        self.updateProjectStatus(projectId);
                                    },
                                    error:function(data){
                                        //to do
                                    }
                                })
                            }
                        }),
                        progressId = progress.getId();

                    $.ajax({
                        url: common.config.rootUrl + 'codetranslation/start/' + projectId + "/" + progressId,
                        type: "GET",
                        success: function(data) {                            
                            data = $.parseJSON(data);
                            if(data && data.status == "200") {
                                main.showProgress();
                                ide.util.log.i(data.msg);
                                if (data.result) {
                                }
                            } else if(data && data.status == "1002") {
                                //current task is working
                                var progress = ide.util.getProgress(progressId);
                                progress && progress.remove();
                                ide.util.alert(ide.i18n.repository.runTranslation, null, 3);
                            }
                        }
                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needUploadorCheckout + "\n", null, 3);
                }
            }

        },
        runTranslationSchedule: function(node){
            //run translation schedule
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
            if(node&&node.operateMap&&(node.operateMap.CheckoutProject||node.operateMap.UploadProject||node.operateMap.MainframeProject)){
                var dialog= self.runTranslationSchedule.dialog = ide.util.dialog({
                    title:"Schedule",
                    iframe:false,
                    href: common.config.rootUrl + "ide/runTranslationSchedule/"+node.projectId,
                    width:350,
                    height:250,
                    modal:true,
                    buttons:[{
                        text:ide.i18n.dialogOkButtonText,
                        handler:function(){

                            self.runTranslationSchedule.submit && self.runTranslationSchedule.submit();
                            $('.bootstrap-datetimepicker-widget').hide();

                        }
                    },{
                        text:ide.i18n.dialogCancelButtonText,
                        handler:function(e){
                            e.data.dialog.close();
                            $('.bootstrap-datetimepicker-widget').hide();
                        }
                    }]
                });
            }
        },
        mergeTranslation:function(node){
           // merge translation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }
        },
        runTransformationInit:function(node){
            //run init transformation
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return ;
            }

            var selector = repository.getSelectors();
            //需要在operateMap 中加transformation,用来判断 transformation 是否可点击.
            // true 为可点, false 为不可点
            // node.operateMap.transformation = true;
            var isInit = node.operateMap.transformation;
            var arr = [];
            arr[0] = contextMenu.find(selector.initTransformation).closest('li').attr('data-service');
            //点击设置init不可用
            if(isInit){

                //repository.disableMenus(arr);

                menu.disableMenus(arr);

                var tfInitData = {
                    projectId: node.projectId,
                    transformation: false
                };
                ide.util.ajax({
                    type:'get',
                    url: common.config.rootUrl + "transformationConfig/initDirectory",
                    //'assets/data/repository/iniTransformation/tree.json',
                    dataType: 'json',
                    data:tfInitData,
                    success:function(rs){
                        var items = rs.data.json.nodes;
                        var zTree = sourceCode.getTree();
                        zTree.addNodes(node,items, false);
                        for(var i = 0; i < items.length; i++){
                            zTree.updateNode(items[i]);
                        }
                    }
                });

            }else{
                menu.enableMenus(arr);
            }
        },
        runTransformationImmediately:function(node){
            //run transformation immediately
            var self = this;
            node = _getRootNode(node);
            var data = {
                projectId: node.projectId
            };
            ide.util.ajax({
                type:'get',
                dataType:'json',
                url: common.config.rootUrl + "transformationConfig/scriptFileList/validate",
                // 'assets/data/repository/runTransformation/file.json',
                data:data,
                success:function(rs){
                    if(rs.status == 200){
                        self.runTransformationImmediately.dialog = ide.util.dialog({
                           title:'Script Files',
                            width:600,
                            height:480,
                            iframe:false,
                            modal:true,
                            href: common.config.rootUrl + 'page/list_files.html',
                            buttons:[{
                                text:'OK',
                                handler: function(e){
                                    var arrId = self.runTransformationImmediately.getSelectedFiles();
                                    if(!arrId.length){
                                        ide.util.tips(ide.i18n.repository.needSelectFile,1500,3);
                                        return false;
                                    }
                                    var createOutputArg = {
                                        projectId: arrId[0].projectId,
                                        fileId: arrId[0].id
                                    };
                                    self.runTransformationOutput(createOutputArg);
                                }
                            },{
                                text: ide.i18n.dialogCancelButtonText,
                                handler:function(e){
                                    e.data.dialog.close();
                                }
                            }],
                            success:function(){
                                require(['runTransformationImmediately'],function(runTransformationImmediately){
                                    runTransformationImmediately.init();
                                    self.runTransformationImmediately.init(node.projectId);

                                })
                            }
                        });
                    }else{
                        ide.util.alert(rs.message,null,2)
                    }
                }
            })
        },
        runTransformationOutput: function(data){
            //生成output 节点
            var self = this;
            ide.util.ajax({
                type:'get',
                dataType:'json',
                url: common.config.rootUrl + "ide/transformation/runScript" + "?projectId="+data.projectId+"&fileId="+data.fileId,
                //'assets/data/repository/runTransformation/Output.json'
                success:function(rs){
                    //console.log(rs);
                    var items = rs.data.json.nodes;
                    var zTree = sourceCode.getTree();
                    var nodes = sourceCode.getSelectedItems();
                    if(nodes&&nodes.length){
                        zTree.addNodes(nodes[0], items,false);
                        for(var i = 0, len = items.length; i < len; i++){
                            zTree.updateNode(items[i]);
                        }
                        self.runTransformationImmediately.dialog.close();
                    }
                }
            })
        },
        runTransformationSchedule:function(node){
            //run transformation schedule
            var self = this;
            node = _getRootNode(node);
            if(!node){
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            if(node.operateMap.CheckoutProject||node.operateMap.UploadProject){
                ide.util.popupDialog({
                href: common.config.rootUrl + "ide/runSchedule ",
                width: 350,
                height: 250
                });
            }else{
                var alertContent = '';
                alertContent += ide.i18n.repository.needUploadorCheckout+"<br>";
                ide.util.alert(alertContent, null, 3);
            }

        },
        mergeTransformation:function(node) {
            //merge transformation
            var self = this;
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            var alertContent="" ;
            if(node.operateMap && (node.operateMap.CheckoutProject||node.operateMap.UploadProject)){
                if(node.operateMap.Transformation){
                    var src = common.config.rootUrl + "assets/data/repository/merageTransform/project_tree.json";
                    self.addNewFolder(sourceCode.getNodesByParam("id", "0102")[0], src, "Merge Transformation ", "run", 20000);
                    }else{
                        alertContent+=ide.i18n.repository.needTransformation+"<br>";
                        ide.util.alert(alertContent, null, 3);
                    }
                }else{
                alertContent+=ide.i18n.repository.needUploadorCheckout+"<br>";
                alertContent+=ide.i18n.repository.needTransformation+"<br>";
                ide.util.alert(alertContent, null, 3);
            }

        },
        runBreSchedule: function (node) {
            // run bre schedule
            var self = this;
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            ide.util.popupDialog({
                href: common.config.rootUrl + "ide/runSchedule",
                width: 350,
                height: 320
            });
        },
        breConfigration: function (node) {
            // run configuration
            var self = this;
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }
            ide.util.popupDialog({
                href: common.config.rootUrl + "/ide/bre"
            });
        },
        runBreImmediately: function (node) {
            //run bre immediately
            var self = this;
            var height = top.document.body.clientHeight - 80;
            var width = top.window.document.body.clientWidth - 40;
            var alertContent = "";
            node = _getRootNode(node)
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }

            if (node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject)) {
                //if(node.operateMap.SystemAnalysis){
                var dialog = repositoryService.runBreImmediately.dialog = ide.util.popupDialog({
                    href: common.config.rootUrl + "ide/patternanalysis/" + node.projectId,
                    width: width,
                    height: height
                });
            } else {

                alertContent = ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);

            }

        },
        runDuplicationAnalysis: function (node, isToolbar) {
            //isToolbar : 是否是toolbar单击
            var self = this;
            var win = $(parent.window), height = win.height() - 40,
                width = win.width() - 40,
                alertContent = "";
            node = _getRootNode(node);
            //console.log(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return;
            }
            if (node && node.operateMap && (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject)) {
                //if(node.operateMap.SystemAnalysis){
                var dialog;
                if ((dialog = self.runDuplicationAnalysis.dialog) && dialog.projectId == node.projectId) {
                    dialog.ui.dialog.show();
                    dialog.ui.dialogOverlay.ui.overlay.fadeIn(250);
                    dialog.ui.dialog.animate(dialog.uiStatus, 300, function () {
                        dialog.ui.closeHandler.show();
                    });
                    return;
                }
                self.runDuplicationAnalysis.closeDialog = function (e) {
                    //console.log(this);
                    var dialog = self.runDuplicationAnalysis.dialog, btn = $("#runDuplicationAnalysisBtn .btn");

                    //缓存dialog状态
                    dialog.uiStatus = {
                        width: dialog.ui.dialog.width(),
                        height: dialog.ui.dialog.height(),
                        top: parseInt(dialog.ui.dialog.css("top")),
                        left: parseInt(dialog.ui.dialog.css("left"))
                    }
                    dialog.ui.closeHandler.hide();
                    dialog.ui.dialogOverlay.ui.overlay.fadeOut(250);

                    dialog.ui.dialog.animate({
                        left: btn.offset().left,
                        top: 70,
                        width: 0,
                        height: 0
                    }, 450, function () {
                        dialog.ui.dialog.hide();
                        btn.addClass("active");
                        setTimeout(function () {
                            btn.removeClass("active");
                            //setInterval(function(){
                            //btn.removeClass("bounce animated").addClass("bounce animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                            //  $(this).removeClass("bounce animated");
                            //});
                            //btn.removeClass("bounce animated").addClass("bounce animated");
                            //},3000);
                        }, 160);
                    });
                    return false;

                }
                dialog = self.runDuplicationAnalysis.dialog = ide.util.dialog({
                    title: "Business Rule Extraction",
                    href: common.config.rootUrl + "ide/patternanalysis/" + node.projectId+"?share="+node.isSharedProjectForCurrentUser,
                    width: width,
                    height: height,
                    modal: true,
                    closeHandler: self.runDuplicationAnalysis.closeDialog
                });
                dialog.projectId = node.projectId;
                //}else{
                //  alertContent+=ide.i18n.repository.needAnalysis;
                //  ide.util.alert(alertContent, null, 3);
                //}
            } else {
                alertContent = ide.i18n.repository.needUploadorCheckout + "<br>";
                ide.util.alert(alertContent, null, 3);
            }
        },
        runAnalysis: function (node) {
            //run analysis
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                alertContent += ide.i18n.repository.needSelectProject;
                ide.util.alert(alertContent, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runAnalysis";
                /*调用 WEB-INF/views/ide/module/analysisOptions.jsp*/
                var dialog = self.runAnalysis.dialog = ide.util.dialog({
                    title: "Analysis Options",
                    iframe: false,
                    href: href,
                    width: 500,
                    height:255,
                    modal: true,
                    closable: true,
                    buttons: [
                        {
                            text: "Run",
                            handler: function () {
                                self.runAnalysis.submit();
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                            }
                        }
                    ]
                });
            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runAnalysisSchedule: function (node) {
            //run analysis schedule
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runAnalysisSchedule";
                var dialog = repositoryService.runAnalysisSchedule.dialog = ide.util.dialog({
                    title: "Schedule",
                    iframe: false,
                    href: href,
                    width: 350,
                    height: 320,
                    modal: true,
                    buttons: [
                        {
                            text: ide.i18n.dialogOkButtonText,
                            handler: function () {
                                //var win = dialog.getIframeWindow();
                                //if (win && win.jQuery) {
                                    repositoryService.runAnalysisSchedule.submit();
                                    $('.bootstrap-datetimepicker-widget').hide();
                               // }
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                                $('.bootstrap-datetimepicker-widget').hide();
                            }
                        }
                    ]
                });

            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runCheckstyle: function (node) {
            //run analysis
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                alertContent += ide.i18n.repository.needSelectProject;
                ide.util.alert(alertContent, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                //禁用service
                menu.disableMenus(["runCheckstyle"]);
                ide.util.showTips("Run Code Audit");
                //$("#J-code-audit").addClass("icon-loading").find(".fa").removeClass("fa-user-md").width(11);
                
                ide.util.ajax({
                    url:common.config.rootUrl+"checkstyle/start",
                    type:"get",
                    data:{
                        projectId:node.projectId
                    },
                    success:function(data){
                        if(data&&data.status==200){

                           // menu.enableMenus(["runCheckstyle"]);
                           // $("#J-code-audit").removeClass("icon-loading").find(".fa").addClass("fa-user-md").removeAttr("style");
                        }
                        //ide.util.tips("check");
                    }
                });
            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        runCheckstyleSchedule: function (node) {
            //run Checkstyle schedule
            var self = this;
            var alertContent = "";
            node = _getRootNode(node);
            if (!node) {
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
                return false;
            }
            if (node.operateMap.CheckoutProject || node.operateMap.UploadProject || node.operateMap.MainframeProject) {
                var href = common.config.rootUrl + "ide/runCheckstyleSchedule";
                var dialog = repositoryService.runCheckstyleSchedule.dialog = ide.util.dialog({
                    title: "Schedule",
                    iframe: false,
                    href: href,
                    width: 350,
                    height: 250,
                    modal: true,
                    closable: true,
                    buttons: [
                        {
                            text: ide.i18n.dialogOkButtonText,
                            handler: function () {

                                repositoryService.runCheckstyleSchedule.submit();
                                $('.bootstrap-datetimepicker-widget').hide();
                            }
                        },
                        {
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function (e) {
                                e.data.dialog.close();
                                $('.bootstrap-datetimepicker-widget').hide();
                            }
                        }
                    ]
                });

            } else {
                alertContent += ide.i18n.repository.needUploadorCheckout;
                ide.util.alert(alertContent, null, 3);
            }
        },
        openFileById:function(id,params){
            //通过 id 打开文件
            var self = this;
            if(id){
                var node = sourceCode.getItemById(id);
                if(node.length > 0){
                    _openItem(node[0], params);
                }else{
                    var flag = false,
                        href = common.config.rootUrl + 'ide/findFileById/' + id;
                    $.ajax({
                        url: href,
                        type: 'GET',
                        dataType: 'json',
                        success:function(rs){
                            if(rs){
                                _openItem(rs,params);
                            }else{
                                ide.util.alert(ide.i18n.repository.fileNo,null,3);
                            }

                        }
                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.fileNo,null,3);
            }
        },
        openFilesByIds: function (ids, params) {
            //通过ID数组打开文件
            var self = this;
            var length;
            if (ids && (length = ids.length)) {
                for (var i = 0; i < length; i++) {
                    self.openFileById(ids[i], params);
                }
            } else {
                ide.util.alert(ide.i18n.repository.fileNo, null, 3);
            }
        },
        openFiles: function (files, params) {
            //通过items数组打开files
            var self = this;
            var length;
            if (files && (length = files.length)) {
                for (var i = 0; i < length; i++) {
                    _openItem(files[i], params);
                }
            } else {
                ide.util.alert(ide.i18n.repository.fileNo, null, 3);
            }
        },
        tabSelect: function (ele) {
            //     tabSelect();
            //     tab切换
            //     ele最外层节点
            //     eg:
            //     <div class='J_IT'>
            //         <ul class='J_tabNav tab-nav'>
            //            <li class='active'>tab1</li>
            //            <li>tab2</li>
            //         </ul>
            //         <div class='J_tabCont tab-content'>
            //             <div class='tab-pane active'>cont1</div>
            //             <div class='tab-pane'>cont2</div>
            //         </div>
            //     </div>
            var self = this;
            var tabBox;
            if (typeof ele == 'object') {
                tabBox = ele
            } else if (typeof ele == 'string') {
                tabBox = $(ele)
            }
            var tabNav = tabBox.find('.J_tabNav').children(),
                tabCont = tabBox.find('.J_tabCont .tab-pane'),
                ACTIVE = 'active';
            $.each(tabNav, function (idx, ele) {
                $(ele).on('click', function (e) {
                    e.preventDefault();
                    $(this).addClass(ACTIVE).siblings().removeClass(ACTIVE);
                    $(tabCont).eq(idx).addClass(ACTIVE).siblings('.tab-pane').removeClass(ACTIVE);
                })
            })
        },
        runTest:function(){
            //run  run test
            var self = this;
            var node = sourceCode.getSelectedItem();
            if(node && node.length){
                self.selectFiles({
                    pId:node[0].projectId,
                    max:1
                },function(e,files){
                   var arrId = [];
                    if(files && files.length>0){
                        for(var i = 0; i < files.length; i++){
                            arrId.push(files[i].id);
                        }
                    }else{
                        ide.util.tips(ide.i18n.repository.needSelectFile,1500,2);
                        return false;
                    }
                    var runTestArg = {
                        projectId:node[0].projectId,
                        filesId:arrId,
                        id:node[0].id
                    }
                    ide.util.ajax({
                        type:'post',
                        dataType:'json',
                        //data:JSON.stringify(runTestArg),
                        url: common.config.rootUrl + 'ide/transformation/runRule?projectId='+node[0].projectId+'&sourcefileid='+arrId+'&rulefileid='+node[0].id,
                        success:function(rs){
                            //console.log(rs);
                        }
                    });
                    self.selectFiles.dialog.close();
                });
            }
        },
        runJob:function(node){
            //运行job类型的文件,通过节点 fileType来显示右键菜单的 run 菜单;
            var self = this;
            var node = node || sourceCode.getSelectedItem()[0],
                jobProgress = null,
                jobUrl ;
            if(node === undefined){
                ide.util.alert(ide.i18n.repository.runTipInfo,null,2);
                return;
            }

            if(node && node.fileType != 'JOB'){
                ide.util.alert(ide.i18n.repository.runTipInfo,null,2);
                return;
            }

            var codeObj = main.getCodeById(node.id);
            if(codeObj && codeObj.isModified()){
                codeObj.saveModifiedFile();
                return;
            }

            jobUrl = common.config.rootUrl + 'submitexecjob/' + node.projectId+ '/'+ node.id;
            jobProgress = main.progress("Run " + node.name ,{
                type: 2
            });

            main.showProgress();

            ide.util.ajax({
                type:'get',
                url:jobUrl,
                success:function(data){
                    if(data.status == 200){
                        main.clearConsole();
                        main.showConsole();
                        data.data && main.console('<pre style="color:#26B047">' + data.data.text + '</pre>');
                        jobProgress.complete();
                    }
                },
                error:function(data){
                    main.clearConsole();
                    main.showConsole();
                    jobProgress.error();
                    if(data){
                        data.message && main.console('<pre style="color:#f01818">' + data.message + '</pre>');
                    }

                }
            })

        },
        //compile 文件
        compile:function(node) {

            var self = this,
                node = node || sourceCode.getSelectedItem()[0];
            
            if(node == undefined){                
                return;
            }

            if(node.fileType!=="PGM" && node.fileType!=="PL1"){
                return;
            }

            var codeObj = main.getCodeById(node.id);
            if(codeObj && codeObj.isModified()){
                codeObj.saveModifiedFile();
                return;
            }

            /*if (self.getActiveEditor() !== self.editorObject) {
                return;
            }*/
            main.searchFile({
                pId:node.projectId,             
                title: "Select Compile JOB",
                okButtonText: "Ok",
                max:1,
                handler: function(e, files) {

                    var p = main.progress("compile " + node.name, {
                        type: 2
                    });

                    main.showProgress();
                    e.data.dialog.hide();

                    var f = function() {
                        ide.util.ajax({
                            url: common.config.rootUrl + "compilelog/" + node.projectId + "/" + node.id + "/" + files[0].id,
                            type: "get",
                            success: function(data) {
                                main.clearConsole();
                                main.showConsole();
                                if (data && data.status == 200) {
                                    data.data && main.console('<pre style="color:#26B047">' + data.data.text + "</pre>");
                                    p.complete();
                                }

                                var _consolePanel=$("#J_console_panel");

                                _consolePanel.scrollTop(0);

                                var _pos=_consolePanel.find("#J_compile_tag").position(),
                                    _top=_pos&&_pos.top;

                                if(_top !== void 0){
                                    _consolePanel.scrollTop(_top-50);
                                }

                            },
                            error: function(data) {
                                main.clearConsole();
                                main.showConsole();
                                p.error();
                                if (data) {
                                    data.message && main.console('<pre style="color:#f01818">' +data.message+ '</pre>');
                                }
                                
                            }
                        });
                    }
                    f();                    
                }
            });         
        },
        teamUpdate: function(){
            //team update
            //team更新代码
            /*逻辑:
             * 1.本地新建文件,新文件加入数据库,不加入版本库,
             *   本地删除后,数据库中删除. 相当于文件的删除新建的操作.
             *
             *   在commit后,数据库,版本库都会被加入,
             *   本地文件删除时,执行upddte操作,树节点中还会有此文件.
             *
             * 2.删除后,执行commit操作,数据库,版本库都会被删除.
             * */
            var self = this;
            var node = sourceCode.getSelectedItem(),
                postData = [],
                href = common.config.rootUrl + 'assets/data/repository/team/team_update_file.json';
            for(var i = 0; i < node.length; i++){
                var arrData = {
                    projectId: node[i].projectId,
                    isParent: node[i].isParent,
                    id: node[i].id//,
//                    isRevert: node[i].operateMap.isRevert
                }
                postData.push(arrData);
            }
            //调用接口
            var isSaverFullFiles = main.hasModifiedFiles();

            if(isSaverFullFiles){
            //文件没有保存
                main.saveAll(function(){
                   ide.util.ajax({
                      url:href,
                       type:'get',
                       data:JSON.stringify(postData),
                       success: function(rs){
                           if(rs.status === 200){
                               ide.util.tips(rs.message,1500);
                           }else{
                               ide.util.alert(rs.message, null, 2);
                           }
                       }
                   });
                });
            }else{
                ide.util.ajax({
                    url:href,
                    type:'get',
                    data: JSON.stringify(postData),
                    success:function(rs){
                        if(rs.status === 200){
                            sourceCode.updateItem(node);
                            ide.util.alert(rs.message,null);
                        }else{
                            ide.util.alert(rs.message,null,2);
                        }
                    }
                });
            }
        },
        teamCommit: function(){
            //team commit
            //team提交代码
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamCommit.dialog = ide.util.dialog({
                        title: 'Commit',
                        href: common.config.rootUrl + 'page/team_commit.html',
                        iframe: false,
                        width:600,
                        height:500,
                        modal:true,
                        buttons:[{
                                text:"Commit",
                                handler:function(e){
                                    if(self.teamCommit.submit){
                                        self.teamCommit.submit();
                                    }
                                }
                            },{
                                text:ide.i18n.dialogCancelButtonText,
                                handler:function(e){
                                    e.data.dialog.close();
                                }
                            }],
                        success:function(){
                            require(['teamCommit'],function(teamCommit){
                                teamCommit.init();
                                self.teamCommit.initCommit(node);

                            })
                        }
                    });
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }

        },
        teamRevert: function(){
            //team revert
            //team 还原代码
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamRevert.dialog = ide.util.dialog({
                        title:'Revert',
                        href: common.config.rootUrl + "page/team_revert.html",
                        iframe:false,
                        width: 700,
                        height: 480,
                        modal: true,
                        buttons:[{
                            text:"Revert",
                            handler:function(e){
                                if(self.teamRevert.submit){
                                    self.teamRevert.submit();
                                }
                            }
                        },{
                            text:ide.i18n.dialogCancelButtonText,
                            handler:function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            require(['teamRevert'],function(teamRevert){
                                teamRevert.init();
                                self.teamRevert.initRevert(node);
                            })
                        }
                    })
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }

        },
        teamShowHistory: function(){
            //team show history
            //显示历史信息
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.teamShowHistory.dialog = ide.util.dialog({
                        title:'Show History',
                        href: common.config.rootUrl + "page/team_showHistory.html",
                        iframe:false,
                        width: 700,
                        height: 480,
                        modal: true,
                        success:function(){
                            require(['teamShowHistory'],function(teamShowHistory){
                                teamShowHistory.init();
                                self.teamShowHistory.initShowHistory(node);
                            })
                        }
                    })
                }
            }else{
                ide.util.alert(ide.i18n.repository.needSelectProject, null, 3);
            }
        },
        shareProject:function(){
            //share project
            var self = this;
            var node = sourceCode.getSelectedItem(),
                projectId;
            if(node && node.length){
                projectId = node[0].projectId;
                if(projectId){
                    var dialog = self.shareProject.dialog =ide.util.dialog({
                       title:'Share / UnShare',
                        href: common.config.rootUrl + 'page/share_project.html',
                        iframe: false,
                        width:600,
                        height: 400,
                        modal: true,
                        buttons:[{
                            text:'Save',
                            handler:function(e){
                                if(self.shareProject.submit){
                                    self.shareProject.submit();
                                }
                            }
                        },{
                            text: ide.i18n.dialogCancelButtonText,
                            handler: function(e){
                                e.data.dialog.close();
                            }
                        }],
                        success:function(){
                            require(['shareProject'],function(shareProject){
                                shareProject.init();
                                self.shareProject.initShareProject(node);
                            });
                        }
                    });
                }else{
                    ide.util.alert(ide.i18n.repository.needSelectProject);
                }
            }
        },
        uploadToMainframe:function(node,$this){
            var self=this;
            //console.log(node);
            if(node){
                self.selectFiles({
                    pId:node.id,
                    url:common.config.rootUrl+"git/getUploadFileStatus",         
                    params:{
                        projectId:node.projectId,
                        ids:[node.id]
                    },
                    height:450,
                    customParams:true,
                    searchable:false,
                    columns:[{                       
                        data:"fileName",
                        title:"fileName"
                    },{
                        title:"path",
                        data:"filePath"
                    },{
                        title:"changeType",
                        data:"changeType"
                    }]
                },function(e,files){
                    var length,paths=[];
                    if(files&&(length=files.length)){
                        for(var i=0;i<length;i++){
                            paths.push(files[i].filePath);
                        }                       
                        ide.util.ajax({
                            url:common.config.rootUrl+"git/uploadFileItem",
                            type:"post",
                            data:JSON.stringify({
                                projectId:node.projectId,
                                filePaths:paths
                            }),
                            success:function(data){
                                if(data){
                                    if(data.status==200){
                                        require(['selectFile'],function(selectFile){
                                            selectFile.init();
                                            ide.util.tips(data.message);
                                            self.selectFiles.dialog.close();
                                        })

                                    }else{
                                        ide.util.alert(data.message,null,2);
                                    }                                   
                                }
                            }
                        });
                    }else{
                        ide.util.alert(ide.i18n.repository.needSelectFile,null,2);
                    }
                    
                });
            }
        },
        downloadSourcecode:function(node,$this){
            //下载代码到本地
            var self = this;
            var _node = node ||  sourceCode.getSelectedItem()[0];

            if(_node){
                if($this){

                    $this.find("a").attr("href",common.config.rootUrl+'ide/download?codeFileId='+ _node.id);
                }else{
                    $('#J_smart_menu li[data-service="downloadSourcecode"]').find('a').attr("href",common.config.rootUrl+'ide/download?codeFileId='+ _node.id);
                }
            }else{
                ide.util.alert(ide.i18n.analysis.itemed,null,3);
            }
        },
        saveLoading:function(){
            //保存时加载loading
            var self = this;
            var loadingSrc = common.config.rootUrl + 'assets/img/loading1.gif';
            var styleStr = ' z-index: 201; position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); overflow:hidden';
            var styleImg = 'z-index: 202; position: fixed; width: 60px; height: 60px; left: 50%; top:50%;';
            var loadingHtml = '<div id="J_saveLoading" style="'+ styleStr +'"><img src="'+ loadingSrc +'" style="'+ styleImg +'"></div>'

            $('body').append(loadingHtml);
        },
        closleSaveLoading:function(){
            //关闭loading
            var self = this;
            $('body').find('#J_saveLoading').remove();
        }




    };
    //repositoryService.saveLoading();
    return window.repositoryService = repositoryService;


//})(window.repositoryService || {}, ide, repository, jQuery, common);

});